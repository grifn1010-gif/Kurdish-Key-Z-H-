package com.kurdkey.keyboard.core;

/** What kind of text box we are typing into (derived from EditorInfo on Android). */
public final class FieldInfo {
    public static final int K_TEXT = 0, K_EMAIL = 1, K_URL = 2, K_NUMBER = 3, K_PHONE = 4, K_DATETIME = 5, K_PASSWORD = 6, K_NONE = 7;
    public static final int ACT_NONE = 1, ACT_GO = 2, ACT_SEARCH = 3, ACT_SEND = 4, ACT_NEXT = 5, ACT_DONE = 6, ACT_PREVIOUS = 7;

    public int kind = K_TEXT;
    public int inputType;
    public boolean noSuggest;
    public boolean multiLine;
    public int imeAction;           // ACT_* or 0 when Enter should insert a new line
    public String actionLabel;
    public boolean decimal, signed;
    public String pkg = "";

    public boolean secret() { return kind == K_PASSWORD; }

    public static FieldInfo from(int inputType, int imeOptions, String actionLabel, String pkg) {
        FieldInfo f = new FieldInfo();
        f.inputType = inputType;
        f.pkg = pkg == null ? "" : pkg;
        f.actionLabel = actionLabel == null ? null : actionLabel.toString();
        int cls = inputType & 0xF, var = inputType & 0xFF0;
        if (cls == 1) {
            f.kind = K_TEXT;
            if (var == 0x20 || var == 0xD0) f.kind = K_EMAIL;
            else if (var == 0x10) f.kind = K_URL;
            else if (var == 0x80 || var == 0x90 || var == 0xE0) f.kind = K_PASSWORD;
            f.noSuggest = (inputType & 0x80000) != 0 || var == 0xB0 || var == 0xC0;
            f.multiLine = (inputType & 0x20000) != 0;
        } else if (cls == 2) {
            f.kind = (var & 0x10) != 0 ? K_PASSWORD : K_NUMBER;
            f.decimal = (inputType & 0x2000) != 0;
            f.signed = (inputType & 0x1000) != 0;
        } else if (cls == 3) f.kind = K_PHONE;
        else if (cls == 4) f.kind = K_DATETIME;
        else f.kind = (inputType == 0) ? K_NONE : K_TEXT;
        if (f.kind == K_PASSWORD || f.kind == K_EMAIL || f.kind == K_URL) f.noSuggest = true;
        int act = imeOptions & 0xFF;
        boolean noEnterAction = (imeOptions & 0x40000000) != 0;
        if (act == 0 || (f.multiLine && noEnterAction) || act == ACT_NONE) f.imeAction = 0;
        else f.imeAction = act;
        if (f.multiLine && act != 0 && act != ACT_NONE && noEnterAction) f.imeAction = 0;
        return f;
    }
}
