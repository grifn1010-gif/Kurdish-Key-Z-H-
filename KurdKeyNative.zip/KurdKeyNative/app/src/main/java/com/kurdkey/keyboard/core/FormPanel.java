package com.kurdkey.keyboard.core;

import java.util.ArrayList;
import java.util.List;

/** Scrolling settings form: section titles, segmented choices, switches, steppers, colour swatches, buttons, info text. */
abstract class FormPanel extends Panel {
    static final int SEG = 0, TOG = 1, STEP = 2, SWATCH = 3, BTN = 4, HEAD = 5, INFO = 6, STATUS = 7, HERO = 8;

    static final class Row {
        int type;
        String title, sub, key;
        String[] labels;
        Object[] vals;
        int min, max, step, lines = 1, id;
        String suffix = "", zeroLabel;
        boolean danger;
        float y, hgt;
    }

    protected final List<Row> rows = new ArrayList<Row>();
    private float total;

    FormPanel(Host h) { super(h); }

    // ---- row builders
    protected final Row head(String t) { Row r = new Row(); r.type = HEAD; r.title = t; rows.add(r); return r; }
    protected final Row seg(String t, String k, String[] l, Object[] v) { Row r = new Row(); r.type = SEG; r.title = t; r.key = k; r.labels = l; r.vals = v; rows.add(r); return r; }
    protected final Row tog(String t, String k) { Row r = new Row(); r.type = TOG; r.title = t; r.key = k; rows.add(r); return r; }
    protected final Row step(String t, String k, int mn, int mx, int st, String suffix) { Row r = new Row(); r.type = STEP; r.title = t; r.key = k; r.min = mn; r.max = mx; r.step = st; r.suffix = suffix; rows.add(r); return r; }
    protected final Row swatch(String t, String k) { Row r = new Row(); r.type = SWATCH; r.title = t; r.key = k; rows.add(r); return r; }
    protected final Row btn(String t, int id) { Row r = new Row(); r.type = BTN; r.title = t; r.id = id; rows.add(r); return r; }
    protected final Row info(String t, int lines) { Row r = new Row(); r.type = INFO; r.title = t; r.lines = lines; rows.add(r); return r; }
    protected final Row status(String t, String sub, int id) { Row r = new Row(); r.type = STATUS; r.title = t; r.sub = sub; r.id = id; rows.add(r); return r; }

    protected boolean statusOk(Row r) { return false; }
    protected void onAction(Row r) {}

    /** Current value of a setting. */
    protected Object val(String k) {
        Cfg c = h.cfg;
        if (k.equals("theme")) return c.theme;
        if (k.equals("accent")) return c.accent;
        if (k.equals("keyStyle")) return c.keyStyle;
        if (k.equals("keyHeight")) return c.keyHeight;
        if (k.equals("keyText")) return c.keyText;
        if (k.equals("keyRadius")) return c.keyRadius;
        if (k.equals("hand")) return c.hand;
        if (k.equals("startLang")) return c.startLang;
        if (k.equals("tone")) return c.tone;
        if (k.equals("numRow")) return c.numRow;
        if (k.equals("numRowLand")) return c.numRowLand;
        if (k.equals("hints")) return c.hints;
        if (k.equals("kuDigits")) return c.kuDigits;
        if (k.equals("font")) return c.font;
        if (k.equals("haptic")) return c.haptic;
        if (k.equals("hapticMs")) return c.hapticMs;
        if (k.equals("sound")) return c.sound;
        if (k.equals("soundVol")) return c.soundVol;
        if (k.equals("preview")) return c.preview;
        if (k.equals("autoCap")) return c.autoCap;
        if (k.equals("dblSpace")) return c.dblSpace;
        if (k.equals("spaceSwipe")) return c.spaceSwipe;
        if (k.equals("longPress")) return c.longPress;
        if (k.equals("typeOnPress")) return c.typeOnPress;
        if (k.equals("suggest")) return c.suggest;
        if (k.equals("translit")) return c.translit;
        if (k.equals("emojiSuggest")) return c.emojiSuggest;
        if (k.equals("learn")) return c.learn;
        if (k.equals("copyAll")) return c.copyAll;
        if (k.equals("clipHistory")) return c.clipHistory;
        if (k.equals("clipMax")) return c.clipMax;
        if (k.equals("translateDir")) return c.translateDir;
        return null;
    }

    protected void put(String k, Object v) { h.setPref(k, v); }

    private float rowHeight(Row r, float dp) {
        switch (r.type) {
            case HERO: return 132f * dp;
            case HEAD: return 46f * dp;
            case SEG: case SWATCH: return 76f * dp;
            case TOG: return (r.sub != null ? 64f : 54f) * dp;
            case STEP: return 54f * dp;
            case BTN: return 62f * dp;
            case STATUS: return 70f * dp;
            default: return (14f + 20f * r.lines) * dp;
        }
    }

    private void calc() {
        float dp = dp(), y = 4 * dp;
        for (Row r : rows) { r.hgt = rowHeight(r, dp); r.y = y; y += r.hgt; }
        total = y + 14 * dp;
    }

    protected float contentH() { calc(); return total; }

    protected void drawBody(Gfx g, float vt, float vb) {
        calc();
        Theme t = h.theme;
        float dp = g.dp();
        for (Row r : rows) {
            if (r.y + r.hgt < vt || r.y > vb) continue;
            float y = r.y;
            switch (r.type) {
                case HEAD:
                    g.text(r.title, W - 16 * dp, y + r.hgt * 0.62f, 14f * dp, t.accent, Gfx.BOLD, Gfx.RIGHT);
                    g.fillRect(16 * dp, y + r.hgt - 5 * dp, W - 16 * dp, y + r.hgt - 4 * dp, t.line);
                    break;
                case SEG: {
                    g.text(r.title, W - 16 * dp, y + 16 * dp, 13f * dp, t.muted, Gfx.BOLD, Gfx.RIGHT);
                    float x0 = 14 * dp, w = W - 28 * dp, hh = 38 * dp, cy = y + 30 * dp;
                    g.fillRound(x0, cy, x0 + w, cy + hh, 13 * dp, t.keyAlt);
                    int n = r.labels.length;
                    float sw = w / n;
                    Object cur = val(r.key);
                    for (int i = 0; i < n; i++) {
                        boolean on = r.vals[i].equals(cur);
                        if (on) g.fillRound(x0 + i * sw + 3 * dp, cy + 3 * dp, x0 + (i + 1) * sw - 3 * dp, cy + hh - 3 * dp, 10 * dp, t.accent);
                        Ui.drawFit(g, r.labels[i], x0 + i * sw + sw / 2f, cy + hh / 2f, 13.5f * dp, 9.5f * dp, sw - 10 * dp, on ? t.accentFg : t.fg, on ? Gfx.BOLD : Gfx.NORMAL, Gfx.CENTER);
                    }
                    break;
                }
                case TOG: {
                    boolean on = Boolean.TRUE.equals(val(r.key));
                    float cy = y + r.hgt / 2f;
                    Ui.drawFit(g, r.title, W - 16 * dp, r.sub != null ? cy - 9 * dp : cy, 15f * dp, 11.5f * dp, W - 100 * dp, t.fg, Gfx.NORMAL, Gfx.RIGHT);
                    if (r.sub != null) Ui.drawFit(g, r.sub, W - 16 * dp, cy + 11 * dp, 11.5f * dp, 9.5f * dp, W - 100 * dp, t.muted, Gfx.NORMAL, Gfx.RIGHT);
                    float sx = 16 * dp, sy = cy - 13 * dp;
                    g.fillRound(sx, sy, sx + 48 * dp, sy + 26 * dp, 13 * dp, on ? t.accent : t.keyDown);
                    g.fillCircle(on ? sx + 48 * dp - 13 * dp : sx + 13 * dp, sy + 13 * dp, 10 * dp, on ? t.accentFg : t.key);
                    g.fillRect(14 * dp, y + r.hgt - dp, W - 14 * dp, y + r.hgt, t.line);
                    break;
                }
                case STEP: {
                    Ui.drawFit(g, r.title, W - 16 * dp, y + r.hgt / 2f, 15f * dp, 11.5f * dp, W - 16 * dp - 176 * dp, t.fg, Gfx.NORMAL, Gfx.RIGHT);
                    int v = (Integer) val(r.key);
                    float cy = y + r.hgt / 2f;
                    Ui.button(g, 16 * dp, cy - 18 * dp, 38 * dp, 36 * dp, 11 * dp, t.keyAlt, null, "−", t.fg, 20f * dp, true);
                    String vs = v == 0 && r.zeroLabel != null ? r.zeroLabel : v + r.suffix;
                    Ui.drawFit(g, vs, 16 * dp + 38 * dp + 34 * dp, cy, 14.5f * dp, 9.5f * dp, 62 * dp, t.fg, Gfx.BOLD, Gfx.CENTER);
                    Ui.button(g, 16 * dp + 38 * dp + 68 * dp, cy - 18 * dp, 38 * dp, 36 * dp, 11 * dp, t.keyAlt, null, "+", t.fg, 20f * dp, true);
                    g.fillRect(14 * dp, y + r.hgt - dp, W - 14 * dp, y + r.hgt, t.line);
                    break;
                }
                case SWATCH: {
                    g.text(r.title, W - 16 * dp, y + 16 * dp, 13f * dp, t.muted, Gfx.BOLD, Gfx.RIGHT);
                    String[] ac = Cfg.ACCENTS;
                    float sw = (W - 28 * dp) / ac.length, cy = y + 50 * dp;
                    for (int i = 0; i < ac.length; i++) {
                        float cx = 14 * dp + i * sw + sw / 2f;
                        g.fillCircle(cx, cy, Math.min(14 * dp, sw * 0.38f), Theme.accentSwatch(ac[i]));
                        if (ac[i].equals(h.cfg.accent)) g.strokeRound(cx - 18 * dp, cy - 18 * dp, cx + 18 * dp, cy + 18 * dp, 18 * dp, 2.5f * dp, t.fg);
                    }
                    break;
                }
                case BTN: {
                    int bg = r.danger ? 0xFFD64545 : t.accent;
                    g.fillRound(14 * dp, y + 8 * dp, W - 14 * dp, y + r.hgt - 8 * dp, 14 * dp, bg);
                    Ui.drawFit(g, r.title, W / 2f, y + r.hgt / 2f, 16f * dp, 11.5f * dp, W - 28 * dp - 24 * dp, r.danger ? 0xFFFFFFFF : t.accentFg, Gfx.BOLD, Gfx.CENTER);
                    break;
                }
                case STATUS: {
                    boolean ok = statusOk(r);
                    g.fillRound(12 * dp, y + 4 * dp, W - 12 * dp, y + r.hgt - 4 * dp, 16 * dp, t.key);
                    float cy = y + r.hgt / 2f;
                    g.fillCircle(W - 38 * dp, cy, 15 * dp, ok ? t.accent : t.keyAlt);
                    g.icon(ok ? Icons.CHECK : Icons.CLOSE, W - 38 * dp, cy, 16 * dp, ok ? t.accentFg : t.muted);
                    Ui.drawFit(g, r.title, W - 64 * dp, cy - (r.sub != null ? 9 * dp : 0), 15f * dp, 11.5f * dp, W - 64 * dp - 110 * dp, t.fg, Gfx.BOLD, Gfx.RIGHT);
                    if (r.sub != null) g.text(Ui.fit(g, r.sub, 11.5f * dp, W - 64 * dp - 110 * dp, Gfx.NORMAL), W - 64 * dp, cy + 12 * dp, 11.5f * dp, t.muted, Gfx.NORMAL, Gfx.RIGHT);
                    Ui.button(g, 22 * dp, cy - 18 * dp, 84 * dp, 36 * dp, 12 * dp, ok ? t.keyAlt : t.accent, null, ok ? "گۆڕین" : "ئێستا", ok ? t.fg : t.accentFg, 14f * dp, true);
                    break;
                }
                case INFO: {
                    List<String> ls = Ui.wrap(g, r.title, 13f * dp, W - 32 * dp, r.lines);
                    for (int i = 0; i < ls.size(); i++) {
                        boolean ar = Ui.rtl(ls.get(i));
                        g.text(ls.get(i), ar ? W - 16 * dp : 16 * dp, y + 17 * dp + i * 20 * dp, 13f * dp, t.muted, Gfx.NORMAL, ar ? Gfx.RIGHT : Gfx.LEFT);
                    }
                    break;
                }
                default: drawHero(g, r);
            }
        }
    }

    protected void drawHero(Gfx g, Row r) {}

    protected void onTap(float x, float cy) {
        calc();
        float dp = dp();
        for (Row r : rows) {
            if (cy < r.y || cy >= r.y + r.hgt) continue;
            switch (r.type) {
                case SEG: {
                    if (cy < r.y + 26 * dp) return;
                    int n = r.labels.length;
                    int i = (int) ((x - 14 * dp) / ((W - 28 * dp) / n));
                    if (i >= 0 && i < n) { h.p.feedback(4); put(r.key, r.vals[i]); }
                    return;
                }
                case TOG: h.p.feedback(4); put(r.key, !Boolean.TRUE.equals(val(r.key))); return;
                case STEP: {
                    int v = (Integer) val(r.key);
                    if (x >= 16 * dp && x < 16 * dp + 46 * dp) v -= r.step;
                    else if (x >= 16 * dp + 38 * dp + 62 * dp && x < 16 * dp + 150 * dp) v += r.step;
                    else return;
                    h.p.feedback(4);
                    put(r.key, Math.max(r.min, Math.min(r.max, v)));
                    return;
                }
                case SWATCH: {
                    String[] ac = Cfg.ACCENTS;
                    int i = (int) ((x - 14 * dp) / ((W - 28 * dp) / ac.length));
                    if (i >= 0 && i < ac.length) { h.p.feedback(4); put(r.key, ac[i]); }
                    return;
                }
                case BTN: case STATUS: h.p.feedback(4); onAction(r); return;
                default: return;
            }
        }
    }
}
