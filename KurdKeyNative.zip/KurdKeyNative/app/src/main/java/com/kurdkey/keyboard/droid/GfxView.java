package com.kurdkey.keyboard.droid;

import android.content.Context;
import android.graphics.Canvas;
import android.os.Build;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;

import com.kurdkey.keyboard.core.Platform;
import com.kurdkey.keyboard.core.Screen;

/** A View that shows one core Screen (the keyboard or the settings). All drawing and touch logic lives in the core. */
final class GfxView extends View {
    private final Screen root;
    private final AndroidGfx gfx;
    private final Platform plat;

    GfxView(Context ctx, Screen root, float density, Platform plat) {
        super(ctx);
        this.root = root;
        this.plat = plat;
        this.gfx = new AndroidGfx(density);
        setFocusable(false);
        setHapticFeedbackEnabled(false);
    }

    @Override protected void onMeasure(int ws, int hs) {
        int w = MeasureSpec.getSize(ws);
        if (w <= 0) w = getResources().getDisplayMetrics().widthPixels;
        int mode = MeasureSpec.getMode(hs);
        int h;
        if (mode == MeasureSpec.EXACTLY) h = MeasureSpec.getSize(hs);
        else {
            h = 300;
            try { h = Math.round(root.desiredHeight(w)); } catch (Throwable t) { plat.log("measure", t); }
            int cap = Math.round(getResources().getDisplayMetrics().heightPixels * 0.6f);
            if (cap > 0) h = Math.min(h, cap);
            if (mode == MeasureSpec.AT_MOST) h = Math.min(h, MeasureSpec.getSize(hs));
        }
        setMeasuredDimension(w, Math.max(1, h));
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        try { root.layout(w, h); } catch (Throwable t) { plat.log("layout", t); }
    }

    @Override protected void onDraw(Canvas canvas) {
        try {
            if (root.animating()) root.tick(SystemClock.uptimeMillis());
            gfx.begin(canvas);
            root.draw(gfx);
            if (root.animating()) postInvalidateOnAnimation();
        } catch (Throwable t) {
            plat.log("draw", t);
        }
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        try {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    if (Build.VERSION.SDK_INT >= 21) requestUnbufferedDispatch(e);
                    root.touch(Screen.DOWN, e.getPointerId(0), e.getX(0), e.getY(0));
                    break;
                case MotionEvent.ACTION_POINTER_DOWN: {
                    int i = e.getActionIndex();
                    root.touch(Screen.DOWN, e.getPointerId(i), e.getX(i), e.getY(i));
                    break;
                }
                case MotionEvent.ACTION_MOVE: {
                    int n = e.getPointerCount();
                    for (int i = 0; i < n; i++) root.touch(Screen.MOVE, e.getPointerId(i), e.getX(i), e.getY(i));
                    break;
                }
                case MotionEvent.ACTION_POINTER_UP:
                case MotionEvent.ACTION_UP: {
                    int i = e.getActionIndex();
                    root.touch(Screen.UP, e.getPointerId(i), e.getX(i), e.getY(i));
                    break;
                }
                case MotionEvent.ACTION_CANCEL: {
                    int n = e.getPointerCount();
                    for (int i = 0; i < n; i++) root.touch(Screen.CANCEL, e.getPointerId(i), e.getX(i), e.getY(i));
                    break;
                }
                default: break;
            }
        } catch (Throwable t) {
            plat.log("touch", t);
        }
        if (root.animating()) postInvalidateOnAnimation();
        return true;
    }
}
