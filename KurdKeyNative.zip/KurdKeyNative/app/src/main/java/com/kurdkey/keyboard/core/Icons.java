package com.kurdkey.keyboard.core;

/** All icons used by the keyboard, drawn on a 24x24 grid. */
public final class Icons {
    private Icons() {}

    private static final String SHIFT_D = "M12 4 L4 12.5 H8.5 V19 H15.5 V12.5 H20 Z";
    public static final Icon SHIFT = Icon.stroked(SHIFT_D, 1.8f);
    public static final Icon SHIFT_ON = new Icon().add(SHIFT_D, true, 0f).add(SHIFT_D, false, 1.8f);
    public static final Icon CAPS = new Icon().add(SHIFT_D, true, 0f).add(SHIFT_D, false, 1.8f).add("M8.5 21.8 H15.5", false, 2f);

    public static final Icon BACKSPACE = new Icon()
            .add("M9.5 5.5 H19.5 Q21.2 5.5 21.2 7.2 V16.8 Q21.2 18.5 19.5 18.5 H9.5 L2.8 12 Z", false, 1.8f)
            .add("M12.7 9.5 L17.3 14.5 M17.3 9.5 L12.7 14.5", false, 1.8f);
    public static final Icon ENTER = Icon.stroked("M19 5.5 V10.5 Q19 12.5 17 12.5 H5.5 M9.5 8.5 L5.5 12.5 L9.5 16.5", 2f);
    public static final Icon SEARCH = new Icon().add("O 10.5 10.5 6", false, 2f).add("M15 15 L20 20", false, 2f);
    public static final Icon SEND = Icon.stroked("M3.5 11.5 L20.5 4 L15 20.5 L11.5 13.5 Z M11.5 13.5 L20.5 4", 1.8f);
    public static final Icon CHECK = Icon.stroked("M5 12.5 L10 17.5 L19 7", 2.2f);
    public static final Icon ARROW_RIGHT = Icon.stroked("M5 12 H19 M13 6 L19 12 L13 18", 2f);
    public static final Icon GLOBE = new Icon().add("O 12 12 9", false, 1.7f).add("E 12 12 4 9", false, 1.7f).add("M3 12 H21", false, 1.7f);
    public static final Icon SMILE = new Icon()
            .add("O 12 12 9", false, 1.8f)
            .add("M8 14.3 Q12 19 16 14.3", false, 1.8f)
            .add("O 9 9.8 1.2", true, 0f).add("O 15 9.8 1.2", true, 0f);
    public static final Icon CHEV_DOWN = Icon.stroked("M6 9.5 L12 15.5 L18 9.5", 2.2f);
    public static final Icon CHEV_UP = Icon.stroked("M6 14.5 L12 8.5 L18 14.5", 2.2f);
    public static final Icon CHEV_LEFT = Icon.stroked("M14.5 6 L8.5 12 L14.5 18", 2.2f);
    public static final Icon CHEV_RIGHT = Icon.stroked("M9.5 6 L15.5 12 L9.5 18", 2.2f);
    public static final Icon CLOSE = Icon.stroked("M6 6 L18 18 M18 6 L6 18", 2.2f);
    public static final Icon PLUS = Icon.stroked("M12 5 V19 M5 12 H19", 2.2f);
    public static final Icon MORE = new Icon().add("O 5 12 1.9", true, 0f).add("O 12 12 1.9", true, 0f).add("O 19 12 1.9", true, 0f);
    public static final Icon CLIPBOARD = new Icon()
            .add("R 5 5.2 14 16.8 2.2", false, 1.8f).add("R 8.5 3 7 4.4 1.6", false, 1.8f)
            .add("M8.7 11.5 H15.3 M8.7 15 H13.5", false, 1.8f);
    public static final Icon COPY = new Icon()
            .add("R 9 9 11 12 2", false, 1.8f)
            .add("M15.5 9 V6.5 Q15.5 5 14 5 H6.5 Q5 5 5 6.5 V14.5 Q5 16 6.5 16 H9", false, 1.8f);
    public static final Icon PASTE = new Icon()
            .add("R 5 5.2 14 16.8 2.2", false, 1.8f).add("R 8.5 3 7 4.4 1.6", false, 1.8f)
            .add("M12 10.5 V16.5 M9.2 13.8 L12 16.6 L14.8 13.8", false, 1.8f);
    public static final Icon CUT = new Icon()
            .add("O 7 17 2.6", false, 1.8f).add("O 17 17 2.6", false, 1.8f)
            .add("M8.8 15 L16.5 4 M15.2 15 L7.5 4", false, 1.8f);
    public static final Icon SELECT_ALL = new Icon()
            .add("M4 9 V5.8 Q4 4 5.8 4 H9 M15 4 H18.2 Q20 4 20 5.8 V9 M20 15 V18.2 Q20 20 18.2 20 H15 M9 20 H5.8 Q4 20 4 18.2 V15", false, 1.8f)
            .add("R 8.5 8.5 7 7 1.2", true, 0f);
    public static final Icon UNDO = Icon.stroked("M9.5 6.5 L4.5 11 L9.5 15.5 M5 11 H14.5 Q19.5 11 19.5 15.5 Q19.5 19 15.5 19 H11", 2f);
    public static final Icon REDO = Icon.stroked("M14.5 6.5 L19.5 11 L14.5 15.5 M19 11 H9.5 Q4.5 11 4.5 15.5 Q4.5 19 8.5 19 H13", 2f);
    public static final Icon TRANSLATE = Icon.stroked("M4 8 H17 M13 4 L17 8 L13 12 M20 16 H7 M11 12 L7 16 L11 20", 2f);
    public static final Icon PIN = Icon.stroked("M9 4 H15 L14.2 10 L17.5 13.2 H6.5 L9.8 10 Z M12 13.2 V20.5", 1.8f);
    public static final Icon PIN_ON = new Icon().add("M9 4 H15 L14.2 10 L17.5 13.2 H6.5 L9.8 10 Z", true, 0f).add("M12 13.2 V20.5", false, 1.8f);
    public static final Icon TRASH = Icon.stroked("M4.5 7 H19.5 M9.5 7 V4.5 H14.5 V7 M6.8 7 L7.8 19.5 H16.2 L17.2 7 M10.5 10.5 V16 M13.5 10.5 V16", 1.8f);
    public static final Icon EDIT = Icon.stroked("M4.5 19.5 L5.3 15 L15.8 4.5 Q17 3.5 18.2 4.5 L19.5 5.8 Q20.5 7 19.5 8.2 L9 18.7 Z M13.5 6.8 L17.2 10.5", 1.8f);
    public static final Icon HIDE_KB = new Icon()
            .add("R 3 4 18 11 2", false, 1.7f)
            .add("M7 8 H7.1 M11 8 H11.1 M15 8 H15.1 M17.5 8 H17.6 M8 11.5 H16", false, 1.9f)
            .add("M9 18.5 L12 21.2 L15 18.5", false, 1.9f);
    public static final Icon HAND_LEFT = Icon.stroked("M15 5 L8 12 L15 19 M20 5 V19", 2f);
    public static final Icon HAND_RIGHT = Icon.stroked("M9 5 L16 12 L9 19 M4 5 V19", 2f);
    public static final Icon FIX = Icon.stroked("M5 12.5 L9.5 17 L19 7.5 M4 20 H20", 2f);
    public static final Icon TEXT = Icon.stroked("M5 7 V5 H19 V7 M12 5 V19 M9 19 H15", 2f);
    public static final Icon NUMBERS = new Icon().add("M8.5 4 L7 20 M16.5 4 L15 20 M4.5 9 H19.5 M3.5 15 H18.5", false, 1.8f);
    public static final Icon PHRASE = Icon.stroked("M4 5.5 H20 V16 H11 L6.5 20 V16 H4 Z M8 9.5 H16 M8 12.5 H13", 1.8f);
    public static final Icon GEAR = gear();
    public static final Icon KEYBOARD = new Icon()
            .add("R 3 5.5 18 13 2", false, 1.7f)
            .add("M7 9.5 H7.1 M11 9.5 H11.1 M15 9.5 H15.1 M7 13 H7.1 M17 13 H17.1 M10 15 H14", false, 1.9f);

    private static Icon gear() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 8; i++) {
            double a = Math.PI / 4 * i;
            float c = (float) Math.cos(a), s = (float) Math.sin(a);
            sb.append(String.format(java.util.Locale.US, "M %.2f %.2f L %.2f %.2f ", 12 + 7.6f * c, 12 + 7.6f * s, 12 + 10.2f * c, 12 + 10.2f * s));
        }
        return new Icon().add("O 12 12 3.2", false, 1.9f).add("O 12 12 7.4", false, 1.9f).add(sb.toString().trim(), false, 2.6f);
    }
}
