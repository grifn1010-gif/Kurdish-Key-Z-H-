package com.kurdkey.keyboard.droid;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import com.kurdkey.keyboard.core.Cfg;
import com.kurdkey.keyboard.core.Host;
import com.kurdkey.keyboard.core.Platform;

import org.json.JSONArray;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

/** Everything the core needs from Android. Used by the keyboard service and by the settings app. */
class AndroidPlatform implements Platform {
    final Context ctx;
    final Handler handler = new Handler(Looper.getMainLooper());
    volatile View view;
    volatile Host host;
    private Vibrator vib;
    private AudioManager am;
    private String lastLogTag = "";
    private long lastLogAt;

    AndroidPlatform(Context ctx) { this.ctx = ctx; }

    public long now() { return SystemClock.uptimeMillis(); }

    public Object post(Runnable r, long delayMs) {
        if (delayMs <= 0) handler.post(r); else handler.postDelayed(r, delayMs);
        return r;
    }

    public void cancel(Object token) {
        if (token instanceof Runnable) handler.removeCallbacks((Runnable) token);
    }

    public void invalidate() {
        View v = view;
        if (v != null) v.invalidate();
    }

    public void requestResize() {
        View v = view;
        if (v != null) { v.requestLayout(); v.invalidate(); }
    }

    public void feedback(int kind) {
        Host hs = host;
        if (hs == null) return;
        Cfg c = hs.cfg;
        try {
            if (c.haptic && c.hapticMs > 0) {
                if (vib == null) vib = (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
                if (vib != null) {
                    int ms = kind == 4 ? c.hapticMs + c.hapticMs / 2 : c.hapticMs;
                    if (Build.VERSION.SDK_INT >= 26) vib.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
                    else vib.vibrate(ms);
                }
            }
            if (c.sound && c.soundVol > 0) {
                if (am == null) am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
                if (am != null) {
                    int fx = kind == 1 ? AudioManager.FX_KEYPRESS_SPACEBAR : kind == 2 ? AudioManager.FX_KEYPRESS_DELETE
                            : kind == 3 ? AudioManager.FX_KEYPRESS_RETURN : AudioManager.FX_KEYPRESS_STANDARD;
                    am.playSoundEffect(fx, c.soundVol / 100f);
                }
            }
        } catch (RuntimeException e) {
            // feedback is optional
        }
    }

    public String asset(String name) {
        InputStream in = null;
        try {
            in = ctx.getAssets().open(name);
            ByteArrayOutputStream bo = new ByteArrayOutputStream(Math.max(1024, in.available()));
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return new String(bo.toByteArray(), "UTF-8");
        } catch (IOException e) {
            return null;
        } finally {
            if (in != null) try { in.close(); } catch (IOException ignore) { }
        }
    }

    public String readFile(String name) {
        File f = new File(ctx.getFilesDir(), name);
        if (!f.exists()) return null;
        FileInputStream in = null;
        try {
            in = new FileInputStream(f);
            byte[] b = new byte[(int) f.length()];
            int off = 0;
            while (off < b.length) {
                int n = in.read(b, off, b.length - off);
                if (n < 0) break;
                off += n;
            }
            return new String(b, 0, off, "UTF-8");
        } catch (IOException e) {
            return null;
        } finally {
            if (in != null) try { in.close(); } catch (IOException ignore) { }
        }
    }

    public void writeFile(String name, String content) {
        File f = new File(ctx.getFilesDir(), name);
        File tmp = new File(ctx.getFilesDir(), name + ".tmp");
        FileOutputStream out = null;
        try {
            out = new FileOutputStream(tmp);
            out.write(content.getBytes("UTF-8"));
            out.flush();
            out.close();
            out = null;
            if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f); }
        } catch (IOException e) {
            Log.e("KurdKey", "write " + name, e);
        } finally {
            if (out != null) try { out.close(); } catch (IOException ignore) { }
        }
    }

    public boolean fileExists(String name) { return new File(ctx.getFilesDir(), name).exists(); }

    public void deleteFile(String name) { new File(ctx.getFilesDir(), name).delete(); }

    public void hideKeyboard() { }

    public void showImePicker() {
        InputMethodManager imm = (InputMethodManager) ctx.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.showInputMethodPicker();
    }

    private void start(Intent i) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try { ctx.startActivity(i); } catch (RuntimeException e) { log("start", e); }
    }

    public void openSettings() { start(new Intent(ctx, SettingsActivity.class)); }

    public void openClipEditor(int id) {
        Intent i = new Intent(ctx, ClipEditActivity.class);
        i.putExtra("id", id);
        start(i);
    }

    public void openUrl(String url) {
        start(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
    }

    private ClipboardManager cm() { return (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE); }

    public String clipboardText() {
        try {
            ClipboardManager m = cm();
            if (m == null) return "";
            ClipData d = m.getPrimaryClip();
            if (d == null || d.getItemCount() == 0) return "";
            CharSequence cs = d.getItemAt(0).coerceToText(ctx);
            return cs == null ? "" : cs.toString();
        } catch (RuntimeException e) {
            return "";
        }
    }

    public void setClipboardText(String t) {
        try {
            ClipboardManager m = cm();
            if (m != null) m.setPrimaryClip(ClipData.newPlainText("kurdkey", t));
        } catch (RuntimeException e) {
            log("clip", e);
        }
    }

    public boolean landscape() {
        return ctx.getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
    }

    public boolean systemDark() {
        return (ctx.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
    }

    public void toast(String msg) {
        try { Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show(); } catch (RuntimeException ignore) { }
    }

    public void log(String tag, Throwable t) {
        Log.e("KurdKey", tag, t);
        long n = SystemClock.uptimeMillis();
        if (tag.equals(lastLogTag) && n - lastLogAt < 3000) return;
        lastLogTag = tag; lastLogAt = n;
        try {
            StackTraceElement[] st = t.getStackTrace();
            String line = tag + ": " + t + (st.length > 0 ? " @ " + st[0] : "") + "\n";
            String old = readFile("errors.log");
            String all = (old == null ? "" : old) + line;
            if (all.length() > 6000) all = all.substring(all.length() - 4000);
            writeFile("errors.log", all);
        } catch (Throwable ignore) { }
    }

    public void translate(final String text, final String from, final String to, final TranslateCb cb) {
        new Thread(new Runnable() {
            public void run() {
                String res = null, err = null;
                HttpURLConnection con = null;
                try {
                    String q = URLEncoder.encode(text, "UTF-8");
                    String base = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=" + from + "&tl=" + to + "&dt=t";
                    boolean post = q.length() > 1500;
                    URL u = new URL(post ? base : base + "&q=" + q);
                    con = (HttpURLConnection) u.openConnection();
                    con.setConnectTimeout(8000);
                    con.setReadTimeout(15000);
                    con.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) KurdKey");
                    if (post) {
                        con.setRequestMethod("POST");
                        con.setDoOutput(true);
                        con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
                        OutputStream os = con.getOutputStream();
                        os.write(("q=" + q).getBytes("UTF-8"));
                        os.close();
                    }
                    int code = con.getResponseCode();
                    if (code != 200) throw new IOException("HTTP " + code);
                    InputStream in = con.getInputStream();
                    ByteArrayOutputStream bo = new ByteArrayOutputStream();
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                    in.close();
                    JSONArray root = new JSONArray(new String(bo.toByteArray(), "UTF-8"));
                    JSONArray segs = root.getJSONArray(0);
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < segs.length(); i++) {
                        JSONArray s = segs.getJSONArray(i);
                        if (!s.isNull(0)) sb.append(s.getString(0));
                    }
                    res = sb.toString();
                } catch (Throwable t) {
                    err = String.valueOf(t.getMessage());
                } finally {
                    if (con != null) con.disconnect();
                }
                final String fr = res, fe = err == null && (res == null || res.length() == 0) ? "empty" : err;
                handler.post(new Runnable() { public void run() { cb.done(fr, fe); } });
            }
        }).start();
    }
}
