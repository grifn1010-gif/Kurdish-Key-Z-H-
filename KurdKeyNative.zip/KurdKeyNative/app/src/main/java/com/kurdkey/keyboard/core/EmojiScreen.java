package com.kurdkey.keyboard.core;

import java.util.ArrayList;
import java.util.List;

/** Emoji panel: category tabs, continuous scrolling grid, recents, skin-tone popup, search entry, backspace. */
final class EmojiScreen extends Panel {
    private static final int B_BACK = 1, B_SEARCH = 2, B_DEL = 3, B_TAB0 = 10;

    private static final class Sec {
        String title;
        List<String> raw = new ArrayList<String>();
        String[] disp;
        float top;
        int rows;
    }

    private final List<Sec> secs = new ArrayList<Sec>();
    private int cols;
    private float cell, secHead, total;
    private int activeTab;
    private int[] tabSec = new int[0];

    private boolean popup, popLive;
    private String[] popOpts = new String[0];
    private float popX, popY, popW, popH;
    private int popSel = -1;

    EmojiScreen(Host h) { super(h); }

    protected float headerH() { return 44f * dp(); }
    protected float footerH() { return 46f * dp(); }
    protected float contentH() { return total; }

    protected void onShown() {
        popup = false;
        float keep = scroll;
        build();
        scroll = Math.min(keep, maxScroll());
    }

    @Override public void layout(float w, float hh) {
        super.layout(w, hh);
        build();
        scroll = Math.min(scroll, maxScroll());
    }

    private void build() {
        float dp = dp();
        secs.clear();
        cols = Math.max(5, (int) (W / (44f * dp)));
        cell = W / cols;
        secHead = 30f * dp;
        EmojiData d = h.emoji;
        String[] names = d.groupNames;
        float y = 0;
        boolean hasRecent = !h.recents.isEmpty();
        List<Integer> ts = new ArrayList<Integer>();
        if (hasRecent) {
            Sec s = new Sec();
            s.title = names.length > 0 ? names[0] : "";
            s.raw = new ArrayList<String>(h.recents);
            s.disp = s.raw.toArray(new String[0]);
            finish(s, y);
            y = s.top + secHead + s.rows * cell;
            secs.add(s);
        }
        for (int g = 0; g < d.groups.size(); g++) {
            List<String> items = d.list(g, h.glyphs);
            if (items.isEmpty()) continue;
            Sec s = new Sec();
            s.title = g + 1 < names.length ? names[g + 1] : "";
            s.raw = items;
            s.disp = new String[items.size()];
            for (int i = 0; i < s.disp.length; i++) s.disp[i] = EmojiData.withTone(items.get(i), h.cfg.tone);
            finish(s, y);
            y = s.top + secHead + s.rows * cell;
            secs.add(s);
        }
        total = y + 10f * dp;
        // tabs: tab0 = recent (or first group), then one per group
        int nt = d.tabs.length;
        tabSec = new int[nt];
        for (int i = 0; i < nt; i++) {
            int si = hasRecent ? i : Math.max(0, i - 1);
            tabSec[i] = Math.min(si, Math.max(0, secs.size() - 1));
        }
    }

    private void finish(Sec s, float y) {
        s.top = y;
        s.rows = (s.disp.length + cols - 1) / cols;
    }

    protected void buildButtons() {
        float dp = dp();
        float hh = headerH(), fh = footerH();
        addBtn(B_SEARCH, 0, 0, 46 * dp, hh);
        int nt = h.emoji.tabs.length;
        float tx = 46 * dp, tw = (W - tx) / Math.max(1, nt);
        for (int i = 0; i < nt; i++) addBtn(B_TAB0 + i, tx + i * tw, 0, tw, hh);
        addBtn(B_BACK, 0, H - fh, 92 * dp, fh);
        addRepeatBtn(B_DEL, W - 80 * dp, H - fh, 80 * dp, fh);
    }

    protected void onBtn(int id) {
        if (id == B_BACK) { h.closePanel(); return; }
        if (id == B_SEARCH) { h.openSearch(); return; }
        if (id == B_DEL) { h.backspace(false); return; }
        if (id >= B_TAB0) {
            int i = id - B_TAB0;
            if (i >= 0 && i < tabSec.length && tabSec[i] < secs.size()) {
                scroll = clamp(secs.get(tabSec[i]).top);
                vel = 0;
                h.p.invalidate();
            }
        }
    }

    private boolean isPressed(int id) { return pressed != null && pressed.id == id; }

    protected void drawChrome(Gfx g) {
        Theme t = h.theme;
        float dp = g.dp(), hh = headerH(), fh = footerH();
        g.fillRect(0, 0, W, hh, t.kbd);
        g.fillRect(0, hh - dp, W, hh, t.line);
        g.fillRound(6 * dp, 5 * dp, 42 * dp, hh - 5 * dp, 12 * dp, isPressed(B_SEARCH) ? t.keyDown : t.keyAlt);
        g.icon(Icons.SEARCH, 24 * dp, hh / 2f, 20 * dp, t.fg);
        String[] tabs = h.emoji.tabs;
        float tx = 46 * dp, tw = (W - tx) / Math.max(1, tabs.length);
        // active tab from the scroll position
        int act = 0;
        float probe = scroll + 6 * dp;
        for (int i = 0; i < tabSec.length; i++) if (tabSec[i] < secs.size() && secs.get(tabSec[i]).top <= probe) act = i;
        activeTab = act;
        for (int i = 0; i < tabs.length; i++) {
            float x = tx + i * tw;
            if (i == activeTab) {
                g.fillRound(x + 2 * dp, 6 * dp, x + tw - 2 * dp, hh - 6 * dp, 10 * dp, Theme.withAlpha(t.accent, 56));
                g.fillRound(x + tw / 2f - 9 * dp, hh - 4.5f * dp, x + tw / 2f + 9 * dp, hh - 1.5f * dp, 1.5f * dp, t.accent);
            }
            g.text(tabs[i], x + tw / 2f, hh / 2f - 1 * dp, Math.min(20f * dp, tw * 0.62f), t.fg, Gfx.NORMAL, Gfx.CENTER);
        }
        g.fillRect(0, H - fh, W, H, t.kbd);
        g.fillRect(0, H - fh, W, H - fh + dp, t.line);
        Ui.button(g, 8 * dp, H - fh + 5 * dp, 80 * dp, fh - 10 * dp, 12 * dp, isPressed(B_BACK) ? t.keyDown : t.keyAlt, null,
                h.st.lang == KbState.KU ? "ئەب" : "ABC", t.fg, 15f * dp, true);
        Ui.button(g, W - 76 * dp, H - fh + 5 * dp, 68 * dp, fh - 10 * dp, 12 * dp, isPressed(B_DEL) ? t.keyDown : t.keyAlt, Icons.BACKSPACE, null, t.fg, 22f * dp, false);
    }

    protected void drawBody(Gfx g, float vt, float vb) {
        Theme t = h.theme;
        float dp = g.dp();
        float size = Math.min(cell * 0.62f, 34f * dp);
        for (Sec s : secs) {
            float bot = s.top + secHead + s.rows * cell;
            if (bot < vt || s.top > vb) continue;
            g.text(s.title, 12 * dp, s.top + secHead * 0.62f, 12f * dp, t.muted, Gfx.BOLD, Gfx.LEFT);
            int r0 = Math.max(0, (int) ((vt - s.top - secHead) / cell));
            int r1 = Math.min(s.rows - 1, (int) ((vb - s.top - secHead) / cell));
            for (int r = r0; r <= r1; r++) {
                float cy = s.top + secHead + r * cell + cell / 2f;
                for (int c = 0; c < cols; c++) {
                    int i = r * cols + c;
                    if (i >= s.disp.length) break;
                    g.text(s.disp[i], c * cell + cell / 2f, cy, size, t.fg, Gfx.NORMAL, Gfx.CENTER);
                }
            }
        }
    }

    private Sec hitSec(float cy, int[] idxOut, float x) {
        for (Sec s : secs) {
            float gt = s.top + secHead;
            if (cy >= gt && cy < gt + s.rows * cell) {
                int r = (int) ((cy - gt) / cell), c = (int) (x / cell);
                if (c >= cols) c = cols - 1;
                int i = r * cols + c;
                if (i < s.disp.length) { idxOut[0] = i; idxOut[1] = (int) (gt + r * cell); return s; }
            }
        }
        return null;
    }

    protected void onTap(float x, float cy) {
        int[] ix = new int[2];
        Sec s = hitSec(cy, ix, x);
        if (s == null) return;
        h.p.feedback(0);
        h.commitEmoji(s.raw.get(ix[0]));
    }

    protected boolean wantsLong(float x, float cy) {
        int[] ix = new int[2];
        Sec s = hitSec(cy, ix, x);
        return s != null && EmojiData.hasTone(s.raw.get(ix[0]));
    }

    protected void onLong(float x, float cy) {
        int[] ix = new int[2];
        Sec s = hitSec(cy, ix, x);
        if (s == null) return;
        String raw = s.raw.get(ix[0]);
        if (!EmojiData.hasTone(raw)) return;
        float dp = dp();
        popOpts = new String[6];
        popOpts[0] = EmojiData.base(raw);
        for (int i = 1; i <= 5; i++) popOpts[i] = EmojiData.withTone(raw, i);
        float cw = Math.min(46f * dp, W / 6.5f);
        popW = cw * 6 + 12 * dp;
        popH = cw + 10 * dp;
        float cellCx = x;
        popX = Math.max(4 * dp, Math.min(W - popW - 4 * dp, cellCx - popW / 2f));
        float cellTop = headerH() + ix[1] - scroll;
        popY = cellTop - popH - 4 * dp;
        if (popY < headerH() + 2 * dp) popY = cellTop + cell + 4 * dp;
        popup = true; popLive = true; popSel = -1;
        h.p.feedback(4);
    }

    private int popIndex(float x, float y) {
        float dp = dp();
        if (y < popY - 14 * dp || y > popY + popH + 14 * dp || x < popX || x > popX + popW) return -1;
        float cw = (popW - 12 * dp) / 6f;
        int i = (int) ((x - popX - 6 * dp) / cw);
        return i < 0 || i > 5 ? -1 : i;
    }

    @Override public boolean touch(int action, int id, float x, float y) {
        if (popup) {
            if (action == DOWN) {
                int i = popIndex(x, y);
                if (i >= 0) { h.commitEmoji(popOpts[i]); h.p.feedback(0); }
                popup = false; popLive = false;
                h.p.invalidate();
                return true;
            }
            if (action == MOVE) { popSel = popIndex(x, y); h.p.invalidate(); return true; }
            // UP / CANCEL of the finger that opened the popup
            if (popLive) {
                popLive = false;
                int i = action == UP ? popIndex(x, y) : -1;
                super.touch(CANCEL, id, x, y);
                if (i >= 0) { h.commitEmoji(popOpts[i]); h.p.feedback(0); popup = false; }
                popSel = -1;
                h.p.invalidate();
            }
            return true;
        }
        return super.touch(action, id, x, y);
    }

    @Override protected void drawOverlay(Gfx g) {
        if (!popup) return;
        Theme t = h.theme;
        float dp = g.dp();
        g.fillRound(popX, popY + 2 * dp, popX + popW, popY + popH + 2 * dp, 14 * dp, t.shadow);
        g.fillRound(popX, popY, popX + popW, popY + popH, 14 * dp, t.pop);
        float cw = (popW - 12 * dp) / 6f;
        for (int i = 0; i < 6; i++) {
            float cx = popX + 6 * dp + i * cw;
            if (i == popSel) g.fillRound(cx + 2 * dp, popY + 4 * dp, cx + cw - 2 * dp, popY + popH - 4 * dp, 10 * dp, Theme.withAlpha(t.accent, 90));
            g.text(popOpts[i], cx + cw / 2f, popY + popH / 2f, Math.min(cw * 0.66f, 30f * dp), t.popFg, Gfx.NORMAL, Gfx.CENTER);
        }
    }
}
