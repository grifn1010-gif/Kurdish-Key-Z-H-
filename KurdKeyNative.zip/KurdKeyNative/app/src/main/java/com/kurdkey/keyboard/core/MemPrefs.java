package com.kurdkey.keyboard.core;

import java.util.HashMap;
import java.util.Map;

public final class MemPrefs implements Prefs {
    public final Map<String, Object> m = new HashMap<String, Object>();
    public String getString(String k, String d) { Object o = m.get(k); return o instanceof String ? (String) o : d; }
    public int getInt(String k, int d) { Object o = m.get(k); return o instanceof Integer ? (Integer) o : d; }
    public boolean getBool(String k, boolean d) { Object o = m.get(k); return o instanceof Boolean ? (Boolean) o : d; }
    public void putString(String k, String v) { m.put(k, v); }
    public void putInt(String k, int v) { m.put(k, v); }
    public void putBool(String k, boolean v) { m.put(k, v); }
    public void remove(String k) { m.remove(k); }
}
