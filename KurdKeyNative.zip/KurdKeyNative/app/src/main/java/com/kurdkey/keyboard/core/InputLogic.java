package com.kurdkey.keyboard.core;

/** Typing behaviour: commits text, tracks the current word, learning, double-space, enter, backspace. No composing text. */
public final class InputLogic {
    public static final int KC_TAB = 61, KC_ENTER = 66, KC_DEL = 67, KC_DPAD_UP = 19, KC_DPAD_DOWN = 20,
            KC_DPAD_LEFT = 21, KC_DPAD_RIGHT = 22, KC_HOME = 122, KC_END = 123;

    private final Host h;
    public String word = "";
    public String prev = "";
    private long lastSpaceAt;
    private boolean afterWordSpace;
    private int expect = -1;

    InputLogic(Host h) { this.h = h; }

    private boolean ok() { return h.ed != null && h.ed.valid(); }

    private boolean hasSel() {
        Editor e = h.ed;
        return e != null && e.selStart() >= 0 && e.selEnd() >= 0 && e.selStart() != e.selEnd();
    }

    /** Called when a new field gets the keyboard. */
    public void reset(int selStart, int selEnd) {
        word = ""; prev = ""; afterWordSpace = false; lastSpaceAt = 0;
        expect = (selStart >= 0 && selStart == selEnd) ? selStart : -1;
        resync();
    }

    /** Re-read the text before the cursor. */
    public void resync() {
        if (!ok()) { word = ""; prev = ""; return; }
        split(h.ed.before(80));
    }

    private void split(String b) {
        if (b == null) b = "";
        if (hasSel()) { word = ""; prev = ""; return; }
        word = Grapheme.trailingWord(b);
        String rest = b.substring(0, b.length() - word.length());
        int i = rest.length(), skipped = 0;
        boolean stop = false;
        while (i > 0 && skipped < 3) {
            int cp = rest.codePointBefore(i);
            if (Grapheme.isWordCp(cp)) break;
            if (cp == '\n' || cp == '.' || cp == '!' || cp == '?' || cp == 0x061F) stop = true;
            i -= Character.charCount(cp);
            skipped++;
        }
        prev = (stop || skipped >= 3 || i == 0) ? "" : Grapheme.trailingWord(rest.substring(0, i));
    }

    /** The system reported a new selection. Returns true if it was an outside change (word state resynced). */
    public boolean onSelection(int newS, int newE) {
        if (newS == newE && newS == expect) return false;
        expect = (newS == newE) ? newS : -1;
        afterWordSpace = false;
        resync();
        return true;
    }

    private void moved(int delta) { if (expect >= 0) expect += delta; }

    private void finishWord(String sep) {
        if (word.length() > 0) {
            if (h.cfg.learn && h.canLearn()) h.learner.learn(word, prev);
            prev = word;
        }
        word = "";
        if (sep.length() > 0) {
            char c = sep.charAt(sep.length() - 1);
            if (c == '.' || c == '!' || c == '?' || c == '\n' || c == 0x061F) prev = "";
        }
    }

    /** Commit text typed from a key. */
    public void type(String text) {
        if (!ok() || text == null || text.length() == 0) return;
        Editor e = h.ed;
        boolean sel = hasSel();
        int base = sel ? Math.min(e.selStart(), e.selEnd()) : -1;
        e.commit(text);
        if (sel) { expect = base + text.length(); word = ""; prev = ""; } else moved(text.length());
        int cp = text.codePointAt(0);
        boolean single = text.length() == Character.charCount(cp);
        if (single && Grapheme.isLetterCp(cp)) {
            word = Grapheme.trailingWord(word + text);
        } else {
            finishWord(text);
        }
        afterWordSpace = false;
    }

    /** Commit text that is not typed by hand (emoji, clip paste, phrases). Splits huge text into chunks. */
    public void insert(String text) {
        if (!ok() || text == null || text.length() == 0) return;
        Editor e = h.ed;
        boolean sel = hasSel();
        int base = sel ? Math.min(e.selStart(), e.selEnd()) : -1;
        int i = 0, n = text.length();
        while (i < n) {
            int j = Math.min(n, i + 20000);
            if (j < n && Character.isHighSurrogate(text.charAt(j - 1))) j--;
            e.commit(text.substring(i, j));
            i = j;
        }
        if (sel) expect = base + n; else moved(n);
        finishWord("");
        afterWordSpace = false;
    }

    public void space() {
        if (!ok()) return;
        Editor e = h.ed;
        long now = h.p.now();
        if (h.cfg.dblSpace && !hasSel() && afterWordSpace && now - lastSpaceAt < 700) {
            String b = e.before(4);
            if (b != null && b.length() >= 2 && b.charAt(b.length() - 1) == ' ') {
                int cp = b.codePointBefore(b.length() - 1);
                if (Character.isLetterOrDigit(cp)) {
                    e.deleteBefore(1);
                    e.commit(". ");
                    moved(1);
                    word = ""; prev = ""; afterWordSpace = false; lastSpaceAt = 0;
                    return;
                }
            }
        }
        boolean wasWord = word.length() > 0;
        boolean sel = hasSel();
        int base = sel ? Math.min(e.selStart(), e.selEnd()) : -1;
        finishWord(" ");
        e.commit(" ");
        if (sel) expect = base + 1; else moved(1);
        afterWordSpace = wasWord;
        lastSpaceAt = now;
    }

    public void enter() {
        if (!ok()) return;
        finishWord("\n");
        FieldInfo f = h.field;
        if (f != null && f.imeAction != 0) h.ed.action(f.imeAction);
        else h.ed.sendKey(KC_ENTER, 0);
        word = ""; prev = ""; expect = -1; afterWordSpace = false;
    }

    public void backspace(boolean wordMode) {
        if (!ok()) return;
        Editor e = h.ed;
        afterWordSpace = false;
        if (hasSel()) {
            int base = Math.min(e.selStart(), e.selEnd());
            e.commit("");
            expect = base;
            resync();
            return;
        }
        String b = e.before(wordMode ? 64 : 48);
        if (b == null || b.length() == 0) {
            e.sendKey(KC_DEL, 0);
            expect = -1;
            return;
        }
        int n = wordMode ? Grapheme.lastWordLen(b) : Grapheme.lastLen(b);
        if (n < 1) n = 1;
        if (n > b.length()) n = b.length();
        e.deleteBefore(n);
        moved(-n);
        split(b.substring(0, b.length() - n));
    }

    /** Replace the word being typed by `s` (+ space) — used by suggestions. */
    public void replaceWord(String s, boolean addSpace) {
        if (!ok()) return;
        Editor e = h.ed;
        int n = word.length();
        if (n > 0) { e.deleteBefore(n); moved(-n); }
        String t = addSpace ? s + " " : s;
        e.commit(t);
        moved(t.length());
        if (h.cfg.learn && h.canLearn()) h.learner.learn(s, prev);
        prev = s;
        word = "";
        afterWordSpace = addSpace;
        lastSpaceAt = h.p.now();
    }

    /** Delete the word being typed (used to undo a suggestion / for the Latin->Kurdish chip). */
    public void clearWord() {
        if (!ok() || word.length() == 0) return;
        int n = word.length();
        h.ed.deleteBefore(n);
        moved(-n);
        word = "";
    }

    public void moveCursor(int dir) {
        if (!ok()) return;
        h.ed.sendKey(dir > 0 ? KC_DPAD_RIGHT : KC_DPAD_LEFT, 0);
        expect = -1;
    }

    /** All text of the field (best effort, bounded). */
    public String allText() {
        if (!ok()) return "";
        String b = h.ed.before(100000), a = h.ed.after(100000);
        return (b == null ? "" : b) + (a == null ? "" : a);
    }
}
