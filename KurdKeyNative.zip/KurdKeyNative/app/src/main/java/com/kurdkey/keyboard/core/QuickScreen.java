package com.kurdkey.keyboard.core;

/** Quick settings inside the keyboard (theme, colours, sizes, switches). Full settings live in the app. */
final class QuickScreen extends FormPanel {
    private static final int B_BACK = 1, A_FULL = 1;

    QuickScreen(Host h) {
        super(h);
        seg("ڕووکار", "theme", new String[]{"خۆکار", "ڕووناک", "تاریک", "ڕەش"}, new Object[]{"auto", "light", "dark", "black"});
        swatch("ڕەنگی سەرەکی", "accent");
        seg("شێوەی دوگمە", "keyStyle", new String[]{"سێ ڕەهەند", "تەخت", "هێڵکاری"}, new Object[]{0, 1, 2});
        step("بەرزی دوگمەکان", "keyHeight", 60, 150, 10, "%");
        step("قەبارەی نووسین", "keyText", 70, 140, 10, "%");
        seg("یەک دەست", "hand", new String[]{"نا", "چەپ", "ڕاست"}, new Object[]{0, 1, 2});
        seg("زمانی دەستپێک", "startLang", new String[]{"کوردی", "ئینگلیزی", "دوایین"}, new Object[]{"ku", "en", "last"});
        seg("ڕەنگی پێستی ئیمۆجی", "tone", new String[]{"—", "🏻", "🏼", "🏽", "🏾", "🏿"}, new Object[]{0, 1, 2, 3, 4, 5});
        tog("ڕیزی ژمارە", "numRow");
        tog("نیشاندانی هێما لەسەر دوگمە", "hints");
        tog("ژمارەی کوردی", "kuDigits");
        tog("لەرینەوە", "haptic");
        tog("دەنگی دوگمە", "sound");
        tog("گەورەکردنی پیت لەکاتی لێدان", "preview");
        tog("پیتی گەورەی خۆکار", "autoCap");
        tog("دوو جار بۆشایی = خاڵ", "dblSpace");
        tog("جوڵاندنی نیشانەدەر بە بۆشایی", "spaceSwipe");
        tog("پێشنیاری وشە", "suggest");
        tog("گۆڕینی لاتینی بۆ کوردی", "translit");
        tog("پێشنیاری ئیمۆجی", "emojiSuggest");
        tog("فێربوونی وشە", "learn");
        btn("هەموو ڕێکخستنەکان", A_FULL);
    }

    protected float headerH() { return 46f * dp(); }

    protected void buildButtons() { addBtn(B_BACK, 0, 0, 92 * dp(), headerH()); }

    protected void onBtn(int id) { if (id == B_BACK) h.closePanel(); }

    protected void onAction(Row r) { if (r.id == A_FULL) h.p.openSettings(); }

    protected void drawChrome(Gfx g) {
        Theme t = h.theme;
        float dp = g.dp(), hh = headerH();
        g.fillRect(0, 0, W, hh, t.kbd);
        g.fillRect(0, hh - dp, W, hh, t.line);
        Ui.button(g, 8 * dp, 5 * dp, 80 * dp, hh - 10 * dp, 12 * dp, pressed != null ? t.keyDown : t.keyAlt, null, h.st.lang == KbState.KU ? "ئەب" : "ABC", t.fg, 15f * dp, true);
        g.text("ڕێکخستنی خێرا", W / 2f, hh / 2f, 17f * dp, t.fg, Gfx.BOLD, Gfx.CENTER);
    }
}
