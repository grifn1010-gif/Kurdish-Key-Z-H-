package com.kurdkey.keyboard.core;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Latin-letter Kurdish -> Sorani Arabic script, and back. Port of the web keyboard tools (tested for parity). */
public final class Translit {
    private Translit() {}

    private static final Map<String, String> WORDS = new HashMap<String, String>();
    private static final Map<String, String> LT = new HashMap<String, String>();
    private static final Map<String, String> DG = new HashMap<String, String>();
    private static final Map<String, String> K2L = new HashMap<String, String>();
    private static final Map<String, String> PM = new HashMap<String, String>();
    static {
        WORDS.put("slaw", "\u0633\u06b5\u0627\u0648");
        WORDS.put("slaaw", "\u0633\u06b5\u0627\u0648");
        WORDS.put("bash", "\u0628\u0627\u0634");
        WORDS.put("bashe", "\u0628\u0627\u0634\u06d5");
        WORDS.put("bashm", "\u0628\u0627\u0634\u0645");
        WORDS.put("zor", "\u0632\u06c6\u0631");
        WORDS.put("bo", "\u0628\u06c6");
        WORDS.put("w", "\u0648");
        WORDS.put("be", "\u0628\u06d5");
        WORDS.put("ba", "\u0628\u06d5");
        WORDS.put("ka", "\u06a9\u06d5");
        WORDS.put("ke", "\u06a9\u06d5");
        WORDS.put("wak", "\u0648\u06d5\u06a9");
        WORDS.put("hamw", "\u0647\u06d5\u0645\u0648\u0648");
        WORDS.put("hamu", "\u0647\u06d5\u0645\u0648\u0648");
        WORDS.put("chon", "\u0686\u06c6\u0646");
        WORDS.put("choni", "\u0686\u06c6\u0646\u06cc");
        WORDS.put("xosh", "\u062e\u06c6\u0634");
        WORDS.put("spas", "\u0633\u0648\u067e\u0627\u0633");
        WORDS.put("na", "\u0646\u0627");
        WORDS.put("bale", "\u0628\u06d5\u06b5\u06ce");
        WORDS.put("kurdi", "\u06a9\u0648\u0631\u062f\u06cc");
        WORDS.put("kurd", "\u06a9\u0648\u0631\u062f");
        WORDS.put("kurdistan", "\u06a9\u0648\u0631\u062f\u0633\u062a\u0627\u0646");
        WORDS.put("min", "\u0645\u0646");
        WORDS.put("to", "\u062a\u06c6");
        WORDS.put("ew", "\u0626\u06d5\u0648");
        WORDS.put("aw", "\u0626\u06d5\u0648");
        WORDS.put("em", "\u0626\u06d5\u0645");
        WORDS.put("ema", "\u0626\u06ce\u0645\u06d5");
        WORDS.put("la", "\u0644\u06d5");
        WORDS.put("le", "\u0644\u06ce");
        WORDS.put("lagal", "\u0644\u06d5\u06af\u06d5\u06b5");
        WORDS.put("bas", "\u0628\u06d5\u0633");
        WORDS.put("balam", "\u0628\u06d5\u06b5\u0627\u0645");
        WORDS.put("agar", "\u0626\u06d5\u06af\u06d5\u0631");
        WORDS.put("yan", "\u06cc\u0627\u0646");
        WORDS.put("chi", "\u0686\u06cc");
        WORDS.put("ki", "\u06a9\u06ce");
        WORDS.put("kay", "\u06a9\u06d5\u06cc");
        WORDS.put("jwan", "\u062c\u0648\u0627\u0646");
        WORDS.put("dost", "\u062f\u06c6\u0633\u062a");
        WORDS.put("mal", "\u0645\u0627\u06b5");
        WORDS.put("kar", "\u06a9\u0627\u0631");
        WORDS.put("pare", "\u067e\u0627\u0631\u06d5");
        WORDS.put("rozh", "\u0695\u06c6\u0698");
        WORDS.put("shaw", "\u0634\u06d5\u0648");
        WORDS.put("nan", "\u0646\u0627\u0646");
        WORDS.put("chay", "\u0686\u0627");
        WORDS.put("datwanim", "\u062f\u06d5\u062a\u0648\u0627\u0646\u0645");
        WORDS.put("datwanit", "\u062f\u06d5\u062a\u0648\u0627\u0646\u06cc\u062a");
        WORDS.put("bkait", "\u0628\u06a9\u06d5\u06cc\u062a");
        WORDS.put("bka", "\u0628\u06a9\u06d5");
        WORDS.put("bkat", "\u0628\u06a9\u0627\u062a");
        WORDS.put("drust", "\u062f\u0631\u0648\u0633\u062a");
        WORDS.put("shtek", "\u0634\u062a\u06ce\u06a9");
        WORDS.put("shtakan", "\u0634\u062a\u06d5\u06a9\u0627\u0646");
        WORDS.put("hich", "\u0647\u06cc\u0686");
        WORDS.put("har", "\u0647\u06d5\u0631");
        WORDS.put("haya", "\u0647\u06d5\u06cc\u06d5");
        WORDS.put("nia", "\u0646\u06cc\u06cc\u06d5");
        WORDS.put("rek", "\u0695\u06ce\u06a9");
        WORDS.put("rukar", "\u0695\u0648\u0648\u06a9\u0627\u0631");
        WORDS.put("xomy", "\u062e\u06c6\u06cc");
        WORDS.put("sayr", "\u0633\u06d5\u06cc\u0631");
        WORDS.put("ama", "\u0626\u06d5\u0645\u06d5");
        WORDS.put("awa", "\u0626\u06d5\u0648\u06d5");
        WORDS.put("chaka", "\u0686\u0627\u06a9\u06d5");
        WORDS.put("rasta", "\u0695\u0627\u0633\u062a\u06d5");
        WORDS.put("pesh", "\u067e\u06ce\u0634");
        WORDS.put("bashtr", "\u0628\u0627\u0634\u062a\u0631");
        WORDS.put("zyad", "\u0632\u06cc\u0627\u062f");
        WORDS.put("nwe", "\u0646\u0648\u06ce");
        WORDS.put("ey", "\u0626\u06d5\u06cc");
        WORDS.put("kaka", "\u06a9\u0627\u06a9\u06d5");
        WORDS.put("way", "\u0648\u06d5\u06cc");
        WORDS.put("dwa", "\u062f\u0648\u0627");
        LT.put("b", "\u0628");
        LT.put("p", "\u067e");
        LT.put("t", "\u062a");
        LT.put("c", "\u062c");
        LT.put("j", "\u062c");
        LT.put("x", "\u062e");
        LT.put("d", "\u062f");
        LT.put("z", "\u0632");
        LT.put("s", "\u0633");
        LT.put("\u015f", "\u0634");
        LT.put("\u00e7", "\u0686");
        LT.put("g", "\u06af");
        LT.put("q", "\u0642");
        LT.put("f", "\u0641");
        LT.put("v", "\u06a4");
        LT.put("k", "\u06a9");
        LT.put("l", "\u0644");
        LT.put("m", "\u0645");
        LT.put("n", "\u0646");
        LT.put("h", "\u0647");
        LT.put("w", "\u0648");
        LT.put("y", "\u06cc");
        LT.put("'", "\u0639");
        DG.put("sh", "\u0634");
        DG.put("ch", "\u0686");
        DG.put("kh", "\u062e");
        DG.put("gh", "\u063a");
        DG.put("zh", "\u0698");
        DG.put("ll", "\u06b5");
        DG.put("rr", "\u0695");
        DG.put("ee", "\u06ce");
        DG.put("ii", "\u06cc");
        DG.put("uu", "\u0648\u0648");
        DG.put("oo", "\u06c6");
        K2L.put("\u0626", "'");
        K2L.put("\u0627", "a");
        K2L.put("\u0628", "b");
        K2L.put("\u067e", "p");
        K2L.put("\u062a", "t");
        K2L.put("\u062c", "j");
        K2L.put("\u0686", "ch");
        K2L.put("\u062d", "h");
        K2L.put("\u062e", "x");
        K2L.put("\u062f", "d");
        K2L.put("\u0631", "r");
        K2L.put("\u0695", "rr");
        K2L.put("\u0632", "z");
        K2L.put("\u0698", "zh");
        K2L.put("\u0633", "s");
        K2L.put("\u0634", "sh");
        K2L.put("\u0639", "'");
        K2L.put("\u063a", "gh");
        K2L.put("\u0641", "f");
        K2L.put("\u06a4", "v");
        K2L.put("\u0642", "q");
        K2L.put("\u06a9", "k");
        K2L.put("\u06af", "g");
        K2L.put("\u0644", "l");
        K2L.put("\u06b5", "ll");
        K2L.put("\u0645", "m");
        K2L.put("\u0646", "n");
        K2L.put("\u06be", "h");
        K2L.put("\u0647", "h");
        K2L.put("\u06d5", "e");
        K2L.put("\u0648", "w");
        K2L.put("\u06c6", "o");
        K2L.put("\u06cc", "y");
        K2L.put("\u06ce", "\u00ea");
        K2L.put("\u060c", ",");
        K2L.put("\u061f", "?");
        K2L.put("\u061b", ";");
        PM.put(",", "\u060c");
        PM.put("?", "\u061f");
        PM.put(";", "\u061b");
    }

    private static final Pattern LATIN_WORD = Pattern.compile("([A-Za-z\\u015F\\u00E7\\u00EA\\u00EE\\u00FB\\u015E\\u00C7\\u00CA\\u00CE\\u00DB']+)([,?;]?)");

    /** Convert one Latin Kurdish word. */
    public static String conv(String x) {
        String l = x.toLowerCase(Locale.ROOT);
        String w = WORDS.get(l);
        if (w != null) return w;
        StringBuilder r = new StringBuilder();
        int i = 0, n = l.length();
        while (i < n) {
            String c = l.substring(i, i + 1);
            String d = l.substring(i, Math.min(n, i + 2));
            boolean a = i == 0;
            String dg = d.length() == 2 ? DG.get(d) : null;
            if (dg != null) {
                r.append(a && "eiuo".indexOf(d.charAt(0)) >= 0 ? "\u0626" : "").append(dg);
                i += 2;
                continue;
            }
            i++;
            char ch = c.charAt(0);
            if (ch == '\u00EA') r.append(a ? "\u0626\u06CE" : "\u06CE");
            else if (ch == '\u00EE') r.append(a ? "\u0626\u06CC" : "\u06CC");
            else if (ch == '\u00FB') r.append(a ? "\u0626\u0648\u0648" : "\u0648\u0648");
            else if (ch == 'a') r.append(a ? "\u0626\u0627" : "\u0627");
            else if (ch == 'e') r.append(a ? "\u0626\u06D5" : "\u06D5");
            else if (ch == 'o') r.append(a ? "\u0626\u06C6" : "\u06C6");
            else if (ch == 'u') r.append(a ? "\u0626\u0648" : "\u0648");
            else if (ch == 'i') r.append(a ? "\u0626\u06CC" : (i >= n ? "\u06CC" : ""));
            else if (ch == 'r') r.append(a ? "\u0695" : "\u0631");
            else { String m = LT.get(c); r.append(m != null ? m : c); }
        }
        return r.toString();
    }

    /** Convert every Latin word of a text (capitalised words and common English words stay). */
    public static String convText(String t, java.util.Set<String> keepWords) {
        Matcher m = LATIN_WORD.matcher(t);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String w = m.group(1), p = m.group(2);
            String rep;
            if ((w.charAt(0) >= 'A' && w.charAt(0) <= 'Z') || (w.length() > 1 && keepWords != null && keepWords.contains(w.toLowerCase(Locale.ROOT)))) rep = m.group();
            else rep = conv(w) + (p.length() > 0 ? PM.get(p) : "");
            m.appendReplacement(sb, Matcher.quoteReplacement(rep));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    /** Sorani Arabic script -> Latin letters. */
    public static String toLatin(String t) {
        StringBuilder sb = new StringBuilder();
        int n = t.length();
        for (int i = 0; i < n; i++) {
            char c = t.charAt(i);
            if (c == '\u0648' && i + 1 < n && t.charAt(i + 1) == '\u0648') { sb.append('u'); i++; continue; }
            String k = K2L.get(String.valueOf(c));
            if (k != null) sb.append(k);
            else sb.append(c);
        }
        return sb.toString();
    }

    /** Fix Arabic letter variants typed by other keyboards. */
    public static String fixLetters(String t) {
        return t.replace('\u0643', '\u06A9').replace('\u064A', '\u06CC').replace('\u0649', '\u06CC').replace("\u0640", "")
                .replaceAll("\u06D5\u200C?\u06CC(?=\\s|$)", "\u06D5\u06CC");
    }

    /** Switch between Latin digits and Arabic-Indic digits. */
    public static String digits(String t) {
        String ar = "\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669\u0660", la = "1234567890";
        boolean has = false;
        for (int i = 0; i < t.length(); i++) { char c = t.charAt(i); if (c >= '0' && c <= '9') { has = true; break; } }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            if (has) { int k = la.indexOf(c); sb.append(k >= 0 ? ar.charAt(k) : c); }
            else { int k = ar.indexOf(c); sb.append(k >= 0 ? la.charAt(k) : c); }
        }
        return sb.toString();
    }
}
