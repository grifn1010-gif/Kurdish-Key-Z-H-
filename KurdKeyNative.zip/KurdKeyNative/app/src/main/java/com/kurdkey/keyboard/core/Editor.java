package com.kurdkey.keyboard.core;

/** The text box we are editing (wraps InputConnection on Android; a plain buffer in tests). */
public interface Editor {
    boolean valid();
    void commit(String text);
    void deleteBefore(int units);
    void deleteAfter(int units);
    String before(int maxUnits);
    String after(int maxUnits);
    String selected();
    void sendKey(int keyCode, int meta);
    void action(int imeAction);
    int capsMode(int inputType);
    void selectAll();
    void copy();
    void cut();
    void paste();
    /** Replace the whole text of the field. */
    void setAll(String text);
    int selStart();
    int selEnd();
    void setSelection(int start, int end);
}
