package com.kurdkey.keyboard.droid;

import android.graphics.Paint;
import android.os.Build;

import com.kurdkey.keyboard.core.EmojiData;

/** Hides emoji that this phone's font cannot draw (no empty boxes). */
final class GlyphCheck implements EmojiData.Glyphs {
    private final Paint paint = new Paint();

    public boolean has(String s) {
        if (Build.VERSION.SDK_INT < 23) return true;
        try { return paint.hasGlyph(s); } catch (RuntimeException e) { return true; }
    }
}
