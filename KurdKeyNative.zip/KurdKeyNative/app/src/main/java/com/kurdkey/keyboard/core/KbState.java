package com.kurdkey.keyboard.core;

/** Current typing state shared by screens and input logic. */
public final class KbState {
    public static final int KU = 0, EN = 1;
    public int lang = KU;
    public String layer = "l";     // l = letters, s1/s2 = symbols
    public int shift;              // 0 off, 1 once, 2 caps lock
    public boolean shiftAuto;      // one-shot shift was set by auto-capitalisation
    public boolean toolbar;        // tool icons shown instead of suggestions

    public String layoutId() {
        if (layer.equals("s1")) return Layouts.S1;
        if (layer.equals("s2")) return Layouts.S2;
        return lang == KU ? Layouts.KU : Layouts.EN;
    }
}
