package com.kurdkey.keyboard.core;

/** Immutable-ish snapshot of all user settings. Keys are the preference names. */
public final class Cfg {
    // appearance
    public String theme = "auto";        // auto | light | dark | black
    public String accent = "green";
    public int keyStyle = 0;             // 0 3D, 1 flat, 2 outline
    public int keyHeight = 100;          // percent
    public int keyText = 100;            // percent
    public int keyRadius = 11;           // dp
    public int hand = 0;                 // 0 both, 1 left, 2 right
    public boolean numRow = true;
    public boolean numRowLand = false;
    public boolean hints = true;
    public boolean kuDigits = false;     // number row shows Arabic-Indic digits in Kurdish layout
    public int font = 0;                 // 0 normal, 1 medium/bold
    // feedback
    public boolean haptic = true;
    public int hapticMs = 10;
    public boolean sound = false;
    public int soundVol = 50;
    public boolean preview = true;
    // typing
    public boolean autoCap = true;
    public boolean dblSpace = true;
    public boolean spaceSwipe = true;
    public int longPress = 300;
    public boolean typeOnPress = false;
    public String startLang = "ku";      // ku | en | last
    public String lastLang = "ku";
    // suggestions
    public boolean suggest = true;
    public boolean translit = true;
    public boolean emojiSuggest = true;
    public boolean learn = true;
    // clipboard / emoji
    public boolean copyAll = false;
    public boolean clipHistory = true;
    public int clipMax = 0;              // 0 = unlimited
    public int tone = 0;                 // 0 none, 1..5
    public boolean toolbarOpen = false;
    public String translateDir = "auto"; // auto | ku-en | en-ku

    public static final String[] KEYS = {"theme", "accent", "keyStyle", "keyHeight", "keyText", "keyRadius", "hand", "numRow", "numRowLand",
            "hints", "kuDigits", "font", "haptic", "hapticMs", "sound", "soundVol", "preview", "autoCap", "dblSpace", "spaceSwipe", "longPress",
            "typeOnPress", "startLang", "lastLang", "suggest", "translit", "emojiSuggest", "learn", "copyAll", "clipHistory", "clipMax", "tone",
            "toolbarOpen", "translateDir"};

    public static final String[] ACCENTS = {"green", "blue", "rose", "violet", "orange", "teal", "red", "gold", "graphite"};

    public static Cfg load(Prefs p) {
        Cfg c = new Cfg();
        c.theme = p.getString("theme", c.theme);
        c.accent = p.getString("accent", c.accent);
        c.keyStyle = clamp(p.getInt("keyStyle", c.keyStyle), 0, 2);
        c.keyHeight = clamp(p.getInt("keyHeight", c.keyHeight), 60, 150);
        c.keyText = clamp(p.getInt("keyText", c.keyText), 70, 140);
        c.keyRadius = clamp(p.getInt("keyRadius", c.keyRadius), 2, 24);
        c.hand = clamp(p.getInt("hand", c.hand), 0, 2);
        c.numRow = p.getBool("numRow", c.numRow);
        c.numRowLand = p.getBool("numRowLand", c.numRowLand);
        c.hints = p.getBool("hints", c.hints);
        c.kuDigits = p.getBool("kuDigits", c.kuDigits);
        c.font = clamp(p.getInt("font", c.font), 0, 1);
        c.haptic = p.getBool("haptic", c.haptic);
        c.hapticMs = clamp(p.getInt("hapticMs", c.hapticMs), 0, 40);
        c.sound = p.getBool("sound", c.sound);
        c.soundVol = clamp(p.getInt("soundVol", c.soundVol), 0, 100);
        c.preview = p.getBool("preview", c.preview);
        c.autoCap = p.getBool("autoCap", c.autoCap);
        c.dblSpace = p.getBool("dblSpace", c.dblSpace);
        c.spaceSwipe = p.getBool("spaceSwipe", c.spaceSwipe);
        c.longPress = clamp(p.getInt("longPress", c.longPress), 120, 800);
        c.typeOnPress = p.getBool("typeOnPress", c.typeOnPress);
        c.startLang = p.getString("startLang", c.startLang);
        c.lastLang = p.getString("lastLang", c.lastLang);
        c.suggest = p.getBool("suggest", c.suggest);
        c.translit = p.getBool("translit", c.translit);
        c.emojiSuggest = p.getBool("emojiSuggest", c.emojiSuggest);
        c.learn = p.getBool("learn", c.learn);
        c.copyAll = p.getBool("copyAll", c.copyAll);
        c.clipHistory = p.getBool("clipHistory", c.clipHistory);
        c.clipMax = Math.max(0, p.getInt("clipMax", c.clipMax));
        c.tone = clamp(p.getInt("tone", c.tone), 0, 5);
        c.toolbarOpen = p.getBool("toolbarOpen", c.toolbarOpen);
        c.translateDir = p.getString("translateDir", c.translateDir);
        return c;
    }

    public static int clamp(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }
}
