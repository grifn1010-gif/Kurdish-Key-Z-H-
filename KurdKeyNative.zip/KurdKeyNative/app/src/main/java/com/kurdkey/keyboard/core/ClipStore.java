package com.kurdkey.keyboard.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Clipboard history with pin / edit / delete. Unlimited by default. Stored in one private file. */
public final class ClipStore {
    public static final class Clip {
        public int id;
        public String text;
        public boolean pinned;
        public long time;
    }

    private static final String FILE = "clips.txt";
    private final Platform p;
    private final List<Clip> items = new ArrayList<Clip>();
    private int nextId = 1;
    private boolean dirty;
    private Object saveToken;
    public int maxItems;       // 0 = unlimited (pinned items are never dropped)
    private long lastTime;

    private long stamp() {
        long t = System.currentTimeMillis();
        if (t <= lastTime) t = lastTime + 1;
        lastTime = t;
        return t;
    }

    public ClipStore(Platform p) { this.p = p; load(); }

    public synchronized void load() {
        items.clear();
        nextId = 1;
        String t = p.readFile(FILE);
        if (t == null) return;
        int pos = 0, n = t.length();
        while (pos < n) {
            int nl = t.indexOf('\n', pos);
            if (nl < 0) nl = n;
            String line = t.substring(pos, nl);
            pos = nl + 1;
            String[] f = line.split("\t", 4);
            if (f.length < 4) continue;
            try {
                Clip c = new Clip();
                c.id = Integer.parseInt(f[0]);
                c.pinned = f[1].equals("1");
                c.time = Long.parseLong(f[2]);
                c.text = unesc(f[3]);
                items.add(c);
                if (c.id >= nextId) nextId = c.id + 1;
                if (c.time > lastTime) lastTime = c.time;
            } catch (NumberFormatException ignore) { }
        }
    }

    private static String esc(String s) {
        StringBuilder b = new StringBuilder(s.length() + 16);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\\') b.append("\\\\");
            else if (c == '\n') b.append("\\n");
            else if (c == '\r') b.append("\\r");
            else if (c == '\t') b.append("\\t");
            else b.append(c);
        }
        return b.toString();
    }

    private static String unesc(String s) {
        if (s.indexOf('\\') < 0) return s;
        StringBuilder b = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\\' && i + 1 < s.length()) {
                char d = s.charAt(++i);
                b.append(d == 'n' ? '\n' : d == 'r' ? '\r' : d == 't' ? '\t' : d);
            } else b.append(c);
        }
        return b.toString();
    }

    private synchronized void changed() {
        dirty = true;
        if (saveToken != null) return;
        saveToken = p.post(new Runnable() { public void run() { saveToken = null; flush(); } }, 700);
    }

    public synchronized void flush() {
        if (!dirty) return;
        dirty = false;
        StringBuilder sb = new StringBuilder();
        for (Clip c : items) sb.append(c.id).append('\t').append(c.pinned ? '1' : '0').append('\t').append(c.time).append('\t').append(esc(c.text)).append('\n');
        p.writeFile(FILE, sb.toString());
    }

    /** Newest first, pinned on top. */
    public synchronized List<Clip> list() {
        List<Clip> l = new ArrayList<Clip>(items);
        Collections.sort(l, new Comparator<Clip>() {
            public int compare(Clip a, Clip b) {
                if (a.pinned != b.pinned) return a.pinned ? -1 : 1;
                return a.time == b.time ? b.id - a.id : (b.time > a.time ? 1 : -1);
            }
        });
        return l;
    }

    public synchronized int size() { return items.size(); }

    public synchronized Clip get(int id) {
        for (Clip c : items) if (c.id == id) return c;
        return null;
    }

    /** Add (or bring to the top when the same text exists). Returns the clip, or null for empty text. */
    public synchronized Clip add(String text) {
        if (text == null || text.length() == 0 || text.trim().length() == 0) return null;
        for (Clip c : items) if (c.text.equals(text)) { c.time = stamp(); changed(); return c; }
        Clip c = new Clip();
        c.id = nextId++;
        c.text = text;
        c.time = stamp();
        items.add(c);
        trim();
        changed();
        return c;
    }

    private void trim() {
        if (maxItems <= 0) return;
        while (items.size() > maxItems) {
            Clip oldest = null;
            for (Clip c : items) if (!c.pinned && (oldest == null || c.time < oldest.time || (c.time == oldest.time && c.id < oldest.id))) oldest = c;
            if (oldest == null) break;
            items.remove(oldest);
        }
    }

    public synchronized void remove(int id) {
        for (int i = 0; i < items.size(); i++) if (items.get(i).id == id) { items.remove(i); changed(); return; }
    }

    public synchronized void setPinned(int id, boolean pin) {
        Clip c = get(id);
        if (c != null && c.pinned != pin) { c.pinned = pin; changed(); }
    }

    public synchronized void update(int id, String text) {
        Clip c = get(id);
        if (c == null) return;
        if (text == null || text.length() == 0) { remove(id); return; }
        c.text = text;
        changed();
    }

    public synchronized void clearUnpinned() {
        for (int i = items.size() - 1; i >= 0; i--) if (!items.get(i).pinned) items.remove(i);
        changed();
    }

    public synchronized void clearAll() { items.clear(); changed(); }
}
