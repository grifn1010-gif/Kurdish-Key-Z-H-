package com.kurdkey.keyboard.core;

/** Everything the pure keyboard code needs from the OS. Implemented by the Android service (and by fakes in tests). */
public interface Platform {
    /** Monotonic millisecond clock. */
    long now();

    /** Run r after delayMs on the UI thread; returns a token usable with cancel(). */
    Object post(Runnable r, long delayMs);
    void cancel(Object token);

    /** Request a redraw of the keyboard view. */
    void invalidate();
    /** The desired height changed (config, panel switch). */
    void requestResize();

    /** Haptic/sound feedback. kind: 0 key, 1 space, 2 delete, 3 enter, 4 special. */
    void feedback(int kind);

    /** Read a bundled text asset, or null. */
    String asset(String name);
    /** Private persistent text files. */
    String readFile(String name);
    void writeFile(String name, String content);
    boolean fileExists(String name);
    void deleteFile(String name);

    void hideKeyboard();
    void showImePicker();
    void openSettings();
    void openClipEditor(int id);
    void openUrl(String url);

    /** System clipboard text (may be empty) / set. */
    String clipboardText();
    void setClipboardText(String t);

    /** Whether the device is in landscape. */
    boolean landscape();
    boolean systemDark();
    /** Online translation (runs off the UI thread; the callback is always delivered on the UI thread). */
    interface TranslateCb { void done(String result, String error); }
    void translate(String text, String from, String to, TranslateCb cb);

    /** Toast-like short message. */
    void toast(String msg);
    void log(String tag, Throwable t);
}
