package com.kurdkey.keyboard.core;

/** Tiny key/value store (SharedPreferences on device, a map in tests). */
public interface Prefs {
    String getString(String key, String def);
    int getInt(String key, int def);
    boolean getBool(String key, boolean def);
    void putString(String key, String v);
    void putInt(String key, int v);
    void putBool(String key, boolean v);
    void remove(String key);
}
