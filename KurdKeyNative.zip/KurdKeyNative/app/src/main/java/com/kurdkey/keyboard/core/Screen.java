package com.kurdkey.keyboard.core;

/** A full-width piece of keyboard UI (keys, emoji grid, clipboard list...). Pure Java, drawn through Gfx. */
public interface Screen {
    int DOWN = 0, MOVE = 1, UP = 2, CANCEL = 3;

    /** Called with the final size before draw/touch. */
    void layout(float w, float h);
    /** Preferred height in px for the given width. */
    float desiredHeight(float w);
    void draw(Gfx g);
    /** One pointer event in this screen's coordinates. Return true if consumed. */
    boolean touch(int action, int id, float x, float y);
    /** True while an animation (fling) needs more frames. */
    boolean animating();
    void tick(long nowMs);
    void onShow();
    void onHide();
}
