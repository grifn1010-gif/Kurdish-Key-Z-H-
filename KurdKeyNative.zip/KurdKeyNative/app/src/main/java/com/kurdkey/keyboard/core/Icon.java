package com.kurdkey.keyboard.core;

import java.util.ArrayList;
import java.util.List;

/**
 * Vector icon on a 24x24 grid. Built from a tiny path language (absolute coordinates only):
 *  M x y | L x y | H x | V y | C x1 y1 x2 y2 x y | Q x1 y1 x y | Z
 *  O cx cy r (circle) | E cx cy rx ry (ellipse) | R x y w h r (rounded rect)
 * A path may contain several sub-paths. An icon is a list of parts, each filled or stroked.
 */
public final class Icon {
    public static final int OP_M = 0, OP_L = 1, OP_C = 2, OP_Q = 3, OP_Z = 4;

    public final List<float[]> cmds = new ArrayList<float[]>();
    public final List<Boolean> fill = new ArrayList<Boolean>();
    public final List<Float> stroke = new ArrayList<Float>();
    /** Platform cache (e.g. android.graphics.Path list). */
    public Object cache;

    public Icon add(String d, boolean fillIt, float strokeW) {
        cmds.add(parse(d));
        fill.add(fillIt);
        stroke.add(strokeW);
        return this;
    }

    public static Icon stroked(String d) { return new Icon().add(d, false, 2f); }
    public static Icon stroked(String d, float w) { return new Icon().add(d, false, w); }
    public static Icon filled(String d) { return new Icon().add(d, true, 0f); }

    private static final float K = 0.5522847498f;

    private static final java.util.regex.Pattern TOKEN = java.util.regex.Pattern.compile("[A-Za-z]|[-+]?(?:\\d+\\.?\\d*|\\.\\d+)");

    static float[] parse(String d) {
        List<String> tl = new ArrayList<String>();
        java.util.regex.Matcher m = TOKEN.matcher(d);
        while (m.find()) tl.add(m.group());
        String[] t = tl.toArray(new String[0]);
        List<Float> o = new ArrayList<Float>();
        int i = 0;
        float cx = 0, cy = 0, sx = 0, sy = 0;
        char ch = 'M';
        while (i < t.length) {
            String c = t[i];
            if (Character.isLetter(c.charAt(0))) { ch = c.charAt(0); i++; }
            else if (ch == 'M') ch = 'L';   // implicit repetition after a move is a line
            switch (ch) {
                case 'M': cx = f(t[i++]); cy = f(t[i++]); sx = cx; sy = cy; put(o, OP_M, cx, cy); break;
                case 'L': cx = f(t[i++]); cy = f(t[i++]); put(o, OP_L, cx, cy); break;
                case 'H': cx = f(t[i++]); put(o, OP_L, cx, cy); break;
                case 'V': cy = f(t[i++]); put(o, OP_L, cx, cy); break;
                case 'C': {
                    float a = f(t[i++]), b = f(t[i++]), c2 = f(t[i++]), d2 = f(t[i++]);
                    cx = f(t[i++]); cy = f(t[i++]);
                    put(o, OP_C, a, b, c2, d2, cx, cy);
                    break;
                }
                case 'Q': {
                    float a = f(t[i++]), b = f(t[i++]);
                    cx = f(t[i++]); cy = f(t[i++]);
                    put(o, OP_Q, a, b, cx, cy);
                    break;
                }
                case 'Z': put(o, OP_Z); cx = sx; cy = sy; break;
                case 'O': {
                    float x = f(t[i++]), y = f(t[i++]), r = f(t[i++]);
                    ellipse(o, x, y, r, r);
                    break;
                }
                case 'E': {
                    float x = f(t[i++]), y = f(t[i++]), rx = f(t[i++]), ry = f(t[i++]);
                    ellipse(o, x, y, rx, ry);
                    break;
                }
                case 'R': {
                    float x = f(t[i++]), y = f(t[i++]), w = f(t[i++]), h = f(t[i++]), r = f(t[i++]);
                    round(o, x, y, w, h, r);
                    break;
                }
                default: throw new IllegalArgumentException("bad icon op " + c + " in " + d);
            }
        }
        float[] r = new float[o.size()];
        for (int k = 0; k < r.length; k++) r[k] = o.get(k);
        return r;
    }

    private static float f(String s) { return Float.parseFloat(s); }

    private static void put(List<Float> o, float... v) { for (float x : v) o.add(x); }

    private static void ellipse(List<Float> o, float x, float y, float rx, float ry) {
        float kx = rx * K, ky = ry * K;
        put(o, OP_M, x + rx, y);
        put(o, OP_C, x + rx, y + ky, x + kx, y + ry, x, y + ry);
        put(o, OP_C, x - kx, y + ry, x - rx, y + ky, x - rx, y);
        put(o, OP_C, x - rx, y - ky, x - kx, y - ry, x, y - ry);
        put(o, OP_C, x + kx, y - ry, x + rx, y - ky, x + rx, y);
        put(o, OP_Z);
    }

    private static void round(List<Float> o, float x, float y, float w, float h, float r) {
        float k = r * K;
        put(o, OP_M, x + r, y);
        put(o, OP_L, x + w - r, y);
        put(o, OP_C, x + w - r + k, y, x + w, y + r - k, x + w, y + r);
        put(o, OP_L, x + w, y + h - r);
        put(o, OP_C, x + w, y + h - r + k, x + w - r + k, y + h, x + w - r, y + h);
        put(o, OP_L, x + r, y + h);
        put(o, OP_C, x + r - k, y + h, x, y + h - r + k, x, y + h - r);
        put(o, OP_L, x, y + r);
        put(o, OP_C, x, y + r - k, x + r - k, y, x + r, y);
        put(o, OP_Z);
    }
}
