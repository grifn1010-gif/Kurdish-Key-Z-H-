package com.kurdkey.keyboard.core;

/** Grid of all tools. */
final class ToolsScreen extends Panel {
    private static final int B_BACK = 1;
    private int cols;
    private float tileW, tileH;

    ToolsScreen(Host h) { super(h); }

    protected float headerH() { return 46f * dp(); }

    private void calc() {
        float dp = dp();
        cols = Math.max(3, (int) (W / (86f * dp)));
        tileW = (W - 8 * dp) / cols;
        tileH = 82f * dp;
    }

    protected float contentH() {
        calc();
        int rows = (Host.ALL_TOOLS.length + cols - 1) / cols;
        return 8f * dp() + rows * tileH + 8f * dp();
    }

    protected void buildButtons() { addBtn(B_BACK, 0, 0, 92 * dp(), headerH()); }

    protected void onBtn(int id) { if (id == B_BACK) h.closePanel(); }

    protected void drawChrome(Gfx g) {
        Theme t = h.theme;
        float dp = g.dp(), hh = headerH();
        g.fillRect(0, 0, W, hh, t.kbd);
        g.fillRect(0, hh - dp, W, hh, t.line);
        Ui.button(g, 8 * dp, 5 * dp, 80 * dp, hh - 10 * dp, 12 * dp, pressed != null ? t.keyDown : t.keyAlt, null, h.st.lang == KbState.KU ? "ئەب" : "ABC", t.fg, 15f * dp, true);
        g.text("ئامرازەکان", W / 2f, hh / 2f, 17f * dp, t.fg, Gfx.BOLD, Gfx.CENTER);
    }

    protected void drawBody(Gfx g, float vt, float vb) {
        calc();
        Theme t = h.theme;
        float dp = g.dp();
        int[] tools = Host.ALL_TOOLS;
        for (int i = 0; i < tools.length; i++) {
            int r = i / cols, c = i % cols;
            float x = 4 * dp + c * tileW, y = 8 * dp + r * tileH;
            if (y + tileH < vt || y > vb) continue;
            g.fillRound(x + 4 * dp, y + 3 * dp, x + tileW - 4 * dp, y + tileH - 3 * dp, 16 * dp, t.key);
            g.icon(Host.toolIcon(tools[i]), x + tileW / 2f, y + tileH * 0.38f, 28 * dp, t.accent);
            Ui.drawFit(g, Host.toolName(tools[i]), x + tileW / 2f, y + tileH * 0.76f, 11.5f * dp, 8.5f * dp, tileW - 10 * dp, t.fg, Gfx.NORMAL, Gfx.CENTER);
        }
    }

    protected void onTap(float x, float cy) {
        calc();
        float dp = dp();
        int c = (int) ((x - 4 * dp) / tileW), r = (int) ((cy - 8 * dp) / tileH);
        if (c < 0 || c >= cols || r < 0) return;
        int i = r * cols + c;
        if (i >= Host.ALL_TOOLS.length) return;
        h.p.feedback(4);
        h.runTool(Host.ALL_TOOLS[i]);
    }
}
