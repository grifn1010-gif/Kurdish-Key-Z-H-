package com.kurdkey.keyboard.droid;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;

import com.kurdkey.keyboard.core.Gfx;
import com.kurdkey.keyboard.core.Icon;

import java.util.ArrayList;
import java.util.List;

/** Gfx on top of android.graphics.Canvas. One instance per view; allocation-free while drawing. */
final class AndroidGfx implements Gfx {
    private Canvas c;
    private final float dp;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint.FontMetrics fm = new Paint.FontMetrics();
    private final RectF rf = new RectF();
    private final Typeface bold = Typeface.create(Typeface.DEFAULT, Typeface.BOLD);
    private final Typeface normal = Typeface.DEFAULT;

    AndroidGfx(float dp) {
        this.dp = dp;
        tp.setTypeface(normal);
    }

    void begin(Canvas canvas) { c = canvas; }

    public float dp() { return dp; }
    public void save() { c.save(); }
    public void restore() { c.restore(); }
    public void clip(float l, float t, float r, float b) { c.clipRect(l, t, r, b); }
    public void translate(float dx, float dy) { c.translate(dx, dy); }

    public void fillRect(float l, float t, float r, float b, int argb) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(argb);
        c.drawRect(l, t, r, b, paint);
    }

    public void fillRound(float l, float t, float r, float b, float rad, int argb) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(argb);
        rf.set(l, t, r, b);
        float m = Math.min(rf.width(), rf.height()) / 2f;
        if (rad > m) rad = m;
        c.drawRoundRect(rf, rad, rad, paint);
    }

    public void strokeRound(float l, float t, float r, float b, float rad, float sw, int argb) {
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(sw);
        paint.setColor(argb);
        rf.set(l, t, r, b);
        float m = Math.min(rf.width(), rf.height()) / 2f;
        if (rad > m) rad = m;
        c.drawRoundRect(rf, rad, rad, paint);
        paint.setStyle(Paint.Style.FILL);
    }

    public void fillCircle(float cx, float cy, float r, int argb) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(argb);
        c.drawCircle(cx, cy, r, paint);
    }

    public void line(float x1, float y1, float x2, float y2, float sw, int argb) {
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(sw);
        paint.setColor(argb);
        c.drawLine(x1, y1, x2, y2, paint);
        paint.setStyle(Paint.Style.FILL);
    }

    private void setText(float size, int style) {
        tp.setTextSize(size);
        tp.setTypeface(style == BOLD ? bold : normal);
    }

    public void text(String s, float x, float cy, float size, int argb, int style, int align) {
        if (s == null || s.length() == 0) return;
        setText(size, style);
        tp.setColor(argb);
        tp.setTextAlign(align == LEFT ? Paint.Align.LEFT : (align == RIGHT ? Paint.Align.RIGHT : Paint.Align.CENTER));
        tp.getFontMetrics(fm);
        c.drawText(s, x, cy - (fm.ascent + fm.descent) / 2f, tp);
    }

    public float textWidth(String s, float size, int style) {
        if (s == null || s.length() == 0) return 0f;
        setText(size, style);
        return tp.measureText(s);
    }

    @SuppressWarnings("unchecked")
    private List<Path> paths(Icon ic) {
        Object o = ic.cache;
        if (o instanceof List) return (List<Path>) o;
        List<Path> l = new ArrayList<Path>();
        for (float[] cmd : ic.cmds) {
            Path p = new Path();
            int i = 0;
            while (i < cmd.length) {
                int op = (int) cmd[i++];
                if (op == Icon.OP_M) { p.moveTo(cmd[i], cmd[i + 1]); i += 2; }
                else if (op == Icon.OP_L) { p.lineTo(cmd[i], cmd[i + 1]); i += 2; }
                else if (op == Icon.OP_C) { p.cubicTo(cmd[i], cmd[i + 1], cmd[i + 2], cmd[i + 3], cmd[i + 4], cmd[i + 5]); i += 6; }
                else if (op == Icon.OP_Q) { p.quadTo(cmd[i], cmd[i + 1], cmd[i + 2], cmd[i + 3]); i += 4; }
                else p.close();
            }
            l.add(p);
        }
        ic.cache = l;
        return l;
    }

    public void icon(Icon icon, float cx, float cy, float size, int argb) {
        List<Path> ps = paths(icon);
        float s = size / 24f;
        c.save();
        c.translate(cx - size / 2f, cy - size / 2f);
        c.scale(s, s);
        paint.setColor(argb);
        for (int i = 0; i < ps.size(); i++) {
            if (icon.fill.get(i)) {
                paint.setStyle(Paint.Style.FILL);
            } else {
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(icon.stroke.get(i));
                paint.setStrokeCap(Paint.Cap.ROUND);
                paint.setStrokeJoin(Paint.Join.ROUND);
            }
            c.drawPath(ps.get(i), paint);
        }
        c.restore();
        paint.setStyle(Paint.Style.FILL);
        paint.setStrokeCap(Paint.Cap.BUTT);
        paint.setStrokeJoin(Paint.Join.MITER);
    }
}
