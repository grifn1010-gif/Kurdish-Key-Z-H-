package com.kurdkey.keyboard.core;

/** Full settings + setup wizard, drawn with the same engine as the keyboard (used by the settings app). */
public final class SettingsScreen extends FormPanel {
    public interface Env {
        boolean imeEnabled();
        boolean imeSelected();
        void openImeSettings();
        void pickIme();
        void clearLearned();
        void unbanAll();
        void clearClips();
        String errorLog();
        void clearErrorLog();
        String version();
    }

    private static final int A_ENABLE = 1, A_PICK = 2, A_CLEAR_LEARN = 3, A_UNBAN = 4, A_CLEAR_CLIPS = 5, A_RESET = 6, A_CLEAR_LOG = 7;

    private final Env env;
    private boolean en, sel;
    private Row armed;
    private Object armToken;

    public SettingsScreen(Host h, Env env) {
        super(h);
        this.env = env;
        Row hero = new Row(); hero.type = HERO; rows.add(hero);
        head("دامەزراندن");
        status("١. چالاککردنی کیبۆرد", "«کیبۆردی کوردی» لە لیستەکەدا چالاک بکە", A_ENABLE);
        status("٢. هەڵبژاردنی کیبۆرد", "کیبۆردی کوردی وەک کیبۆردی ئێستا هەڵبژێرە", A_PICK);
        info("٣. لە خانەی خوارەوە بنووسە و کیبۆردەکە تاقی بکەرەوە. ئەگەر دەرنەکەوت، هەنگاوی ١ و ٢ دووبارە بکەرەوە.", 2);

        head("ڕووکار");
        seg("ڕووکار", "theme", new String[]{"خۆکار", "ڕووناک", "تاریک", "ڕەش"}, new Object[]{"auto", "light", "dark", "black"});
        swatch("ڕەنگی سەرەکی", "accent");
        seg("شێوەی دوگمە", "keyStyle", new String[]{"سێ ڕەهەند", "تەخت", "هێڵکاری"}, new Object[]{0, 1, 2});
        step("بەرزی دوگمەکان", "keyHeight", 60, 150, 5, "%");
        step("قەبارەی نووسین", "keyText", 70, 140, 5, "%");
        step("گۆشەی دوگمەکان", "keyRadius", 2, 24, 1, "");
        seg("ئەستووری نووسین", "font", new String[]{"ئاسایی", "ئەستوور"}, new Object[]{0, 1});
        tog("ڕیزی ژمارە", "numRow");
        tog("ڕیزی ژمارە لە دۆخی لاکێشەیی", "numRowLand");
        tog("نیشاندانی هێما لەسەر دوگمە", "hints");
        tog("ژمارەی کوردی (١٢٣) لە کیبۆردی کوردی", "kuDigits");

        head("هەستپێکردن");
        tog("لەرینەوە", "haptic");
        step("هێزی لەرینەوە", "hapticMs", 0, 40, 2, " ms");
        tog("دەنگی دوگمە", "sound").sub = "پێویستە دەنگی لێدانی ئەندرۆید چالاک بێت";
        step("بەرزی دەنگ", "soundVol", 0, 100, 10, "%");
        tog("گەورەکردنی پیت لەکاتی لێدان", "preview");

        head("نووسین");
        seg("یەک دەست", "hand", new String[]{"نا", "چەپ", "ڕاست"}, new Object[]{0, 1, 2});
        seg("زمانی دەستپێک", "startLang", new String[]{"کوردی", "ئینگلیزی", "دوایین"}, new Object[]{"ku", "en", "last"});
        tog("پیتی گەورەی خۆکار", "autoCap");
        tog("دوو جار بۆشایی = خاڵ", "dblSpace");
        tog("جوڵاندنی نیشانەدەر بە بۆشایی", "spaceSwipe");
        step("کاتی دانەگرتن بۆ هێماکان", "longPress", 120, 800, 20, " ms");
        tog("لێدان لەکاتی دانانی پەنجە", "typeOnPress").sub = "خێراترە، بەڵام هێماکانی ژێر دوگمە کار ناکەن";

        head("پێشنیار");
        tog("پێشنیاری وشە", "suggest");
        tog("گۆڕینی لاتینی بۆ کوردی", "translit").sub = "بۆ نموونە slaw دەبێتە سڵاو";
        tog("پێشنیاری ئیمۆجی", "emojiSuggest");
        tog("فێربوونی وشە", "learn");
        Row b1 = btn("سڕینەوەی وشە فێربووەکان", A_CLEAR_LEARN); b1.danger = true;
        btn("گەڕاندنەوەی وشە لابراوەکان", A_UNBAN);

        head("کلیپبۆرد");
        tog("پاشەکەوتکردنی کلیپبۆرد", "clipHistory");
        tog("کۆپی هەموو دەق", "copyAll").sub = "ئەگەر هیچ هەڵنەبژێردرابێت، دوگمەی کۆپی هەموو دەقەکە کۆپی دەکات";
        Row cm = step("زۆرترین ژمارەی کلیپ", "clipMax", 0, 2000, 50, ""); cm.zeroLabel = "بێ سنوور";
        Row b2 = btn("سڕینەوەی هەموو کلیپەکان (جگە لە سنجکراو)", A_CLEAR_CLIPS); b2.danger = true;

        head("ئیمۆجی");
        seg("ڕەنگی پێستی ئیمۆجی", "tone", new String[]{"—", "🏻", "🏼", "🏽", "🏾", "🏿"}, new Object[]{0, 1, 2, 3, 4, 5});

        head("وەرگێڕان");
        seg("ئاراستەی وەرگێڕان", "translateDir", new String[]{"خۆکار", "کوردی بۆ ئینگلیزی", "ئینگلیزی بۆ کوردی"}, new Object[]{"auto", "ku-en", "en-ku"});

        head("دەربارە");
        info("کیبۆردی کوردی " + env.version() + "\nوشە و کلیپەکانت تەنها لەسەر مۆبایلەکەت دەمێننەوە. تەنها وەرگێڕان ئینتەرنێت بەکاردەهێنێت.", 3);
        info(" ", 4).key = "log";
        btn("پاککردنەوەی تۆماری هەڵە", A_CLEAR_LOG);
        Row b3 = btn("گەڕاندنەوەی هەموو ڕێکخستنەکان", A_RESET); b3.danger = true;
        refresh();
    }

    /** Re-check the setup state (call from onResume). */
    public void refresh() {
        en = env.imeEnabled();
        sel = env.imeSelected();
        String log = env.errorLog();
        for (Row r : rows) if ("log".equals(r.key)) {
            if (log == null || log.trim().length() == 0) r.title = "هیچ هەڵەیەک تۆمار نەکراوە ✓";
            else {
                String[] ls = log.trim().split("\n");
                StringBuilder sb = new StringBuilder();
                for (int i = Math.max(0, ls.length - 3); i < ls.length; i++) sb.append(ls[i]).append('\n');
                r.title = sb.toString();
            }
        }
        h.p.invalidate();
    }

    @Override protected boolean statusOk(Row r) { return r.id == A_ENABLE ? en : sel; }

    protected float headerH() { return 0f; }
    protected void buildButtons() {}
    protected void drawChrome(Gfx g) {}

    @Override protected void drawHero(Gfx g, Row r) {
        Theme t = h.theme;
        float dp = g.dp();
        g.fillRound(12 * dp, r.y + 8 * dp, W - 12 * dp, r.y + r.hgt - 6 * dp, 24 * dp, t.accent);
        float cy = r.y + r.hgt / 2f + dp;
        g.fillCircle(W - 56 * dp, cy, 30 * dp, Theme.withAlpha(t.accentFg, 46));
        g.icon(Icons.KEYBOARD, W - 56 * dp, cy, 34 * dp, t.accentFg);
        g.text("کیبۆردی کوردی", W - 98 * dp, cy - 14 * dp, 25f * dp, t.accentFg, Gfx.BOLD, Gfx.RIGHT);
        Ui.drawFit(g, "کوردی و ئینگلیزی  •  ئیمۆجی  •  کلیپبۆرد  •  وەرگێڕان", W - 98 * dp, cy + 18 * dp, 12.5f * dp, 9f * dp, W - 98 * dp - 26 * dp,
                Theme.withAlpha(t.accentFg, 225), Gfx.NORMAL, Gfx.RIGHT);
    }

    @Override protected void onAction(Row r) {
        if (r.type == STATUS) {
            if (r.id == A_ENABLE || !en) env.openImeSettings(); else env.pickIme();
            return;
        }
        if (r.danger && armed != r) {
            armed = r;
            h.p.toast("دووبارە دابگرە بۆ دڵنیابوونەوە");
            if (armToken != null) h.p.cancel(armToken);
            armToken = h.p.post(new Runnable() { public void run() { armed = null; armToken = null; } }, 3500);
            return;
        }
        armed = null;
        switch (r.id) {
            case A_CLEAR_LEARN: env.clearLearned(); h.p.toast("سڕایەوە"); break;
            case A_UNBAN: env.unbanAll(); h.p.toast("گەڕایەوە"); break;
            case A_CLEAR_CLIPS: env.clearClips(); h.p.toast("سڕایەوە"); break;
            case A_CLEAR_LOG: env.clearErrorLog(); refresh(); break;
            case A_RESET:
                for (String k : Cfg.KEYS) h.prefs.remove(k);
                h.reloadPrefs();
                h.p.toast("گەڕایەوە بۆ بنەڕەت");
                break;
            default: break;
        }
    }
}
