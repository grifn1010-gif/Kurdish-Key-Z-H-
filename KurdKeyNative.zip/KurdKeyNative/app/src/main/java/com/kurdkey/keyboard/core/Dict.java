package com.kurdkey.keyboard.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Frequency-ordered word list with fast prefix search. One word per line, most frequent first. */
public final class Dict {
    private final String[] words;
    private final String[] keys;   // sorted normalised keys
    private final int[] rank;      // rank of keys[i] (index into words)
    private final Set<String> set = new HashSet<String>();
    private final java.util.Map<String, Integer> rankOf = new java.util.HashMap<String, Integer>();
    /** Number of leading words that are really common (header line "#common N"); 0 when unknown. */
    public int common;

    public static String norm(String s) {
        StringBuilder b = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == 'ك') c = 'ک';
            else if (c == 'ي' || c == 'ى') c = 'ی';
            else if (c == 'ـ' || c == '‌' || c == '‍') continue;
            else if (c == '’') c = '\'';
            b.append(c);
        }
        return b.toString().toLowerCase(Locale.ROOT);
    }

    public Dict(String text) {
        List<String> w = new ArrayList<String>();
        if (text != null) {
            for (String line : text.split("\n")) {
                line = line.trim();
                if (line.length() == 0) continue;
                if (line.charAt(0) == '#') {
                    if (line.startsWith("#common ")) { try { common = Integer.parseInt(line.substring(8).trim()); } catch (NumberFormatException ignore) { } }
                    continue;
                }
                w.add(line);
            }
        }
        words = w.toArray(new String[0]);
        Integer[] idx = new Integer[words.length];
        final String[] nk = new String[words.length];
        for (int i = 0; i < words.length; i++) { idx[i] = i; nk[i] = norm(words[i]); set.add(nk[i]); if (!rankOf.containsKey(nk[i])) rankOf.put(nk[i], i); }
        Arrays.sort(idx, new java.util.Comparator<Integer>() {
            public int compare(Integer a, Integer b) {
                int c = nk[a].compareTo(nk[b]);
                return c != 0 ? c : a - b;
            }
        });
        keys = new String[words.length];
        rank = new int[words.length];
        for (int i = 0; i < idx.length; i++) { keys[i] = nk[idx[i]]; rank[i] = idx[i]; }
    }

    public int size() { return words.length; }

    public boolean contains(String w) { return set.contains(norm(w)); }

    /** Position in the frequency list (0 = most common) or -1 when unknown. */
    public int rank(String w) { Integer r = rankOf.get(norm(w)); return r == null ? -1 : r; }

    /** True for the really common words (the web-frequency head of the list). */
    public boolean isCommon(String w) { int r = rank(w); return r >= 0 && r < common; }

    /** Adds up to `limit` words that start with `prefix` (and are longer), best ranked first. */
    public void prefix(String prefix, int limit, List<String> out, Set<String> skip) {
        String p = norm(prefix);
        if (p.length() == 0 || words.length == 0) return;
        int lo = 0, hi = keys.length;
        while (lo < hi) {
            int mid = (lo + hi) >>> 1;
            if (keys[mid].compareTo(p) < 0) lo = mid + 1; else hi = mid;
        }
        int[] best = new int[limit];
        int n = 0;
        for (int i = lo; i < keys.length && keys[i].startsWith(p); i++) {
            if (keys[i].length() <= p.length()) continue;
            String w = words[rank[i]];
            if (skip != null && skip.contains(norm(w))) continue;
            int r = rank[i];
            int pos = n;
            while (pos > 0 && best[pos - 1] > r) pos--;
            if (pos >= limit) continue;
            if (n < limit) n++;
            for (int k = n - 1; k > pos; k--) best[k] = best[k - 1];
            best[pos] = r;
        }
        for (int i = 0; i < n; i++) {
            String w = words[best[i]];
            if (!out.contains(w)) out.add(w);
        }
    }
}
