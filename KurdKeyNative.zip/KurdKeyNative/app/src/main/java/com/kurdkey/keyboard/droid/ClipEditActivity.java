package com.kurdkey.keyboard.droid;

import android.app.Activity;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.kurdkey.keyboard.core.ClipStore;
import com.kurdkey.keyboard.core.Host;
import com.kurdkey.keyboard.core.Theme;

/** Edit or add one clipboard item. Opened from the keyboard's clipboard panel. */
public class ClipEditActivity extends Activity {
    private Host host;
    private EditText et;
    private int id;
    private float dp;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        KeyboardService s = KeyboardService.instance;
        if (s == null || s.host == null) {
            Toast.makeText(this, "کیبۆرد ئامادە نییە، دووبارە هەوڵبدەرەوە", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        host = s.host;
        id = getIntent().getIntExtra("id", 0);
        dp = getResources().getDisplayMetrics().density;
        Theme t = host.theme;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        if (Build.VERSION.SDK_INT >= 17) root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackgroundColor(t.kbd);
        int pad = Math.round(14 * dp);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText(id == 0 ? "کلیپی نوێ" : "دەستکاریکردنی کلیپ");
        title.setTextColor(t.fg);
        title.setTextSize(20f);
        title.setPadding(0, 0, 0, Math.round(10 * dp));
        root.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        et = new EditText(this);
        et.setGravity(Gravity.TOP | Gravity.START);
        et.setTextColor(t.fg);
        et.setHintTextColor(t.muted);
        et.setHint("دەقەکە لێرە بنووسە…");
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(t.key);
        gd.setCornerRadius(14 * dp);
        gd.setStroke(Math.round(dp), t.line);
        et.setBackground(gd);
        int ep = Math.round(12 * dp);
        et.setPadding(ep, ep, ep, ep);
        if (id != 0) {
            ClipStore.Clip c = host.clips.get(id);
            if (c != null) et.setText(c.text);
        }
        root.addView(et, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rp.topMargin = Math.round(10 * dp);
        root.addView(row, rp);
        row.addView(button("پاشەکەوت", t.accent, t.accentFg, new View.OnClickListener() {
            public void onClick(View v) { save(); }
        }), btnLp());
        row.addView(button("پاشگەزبوونەوە", t.keyAlt, t.fg, new View.OnClickListener() {
            public void onClick(View v) { finish(); }
        }), btnLp());
        if (id != 0) {
            row.addView(button("سڕینەوە", 0xFFD64545, 0xFFFFFFFF, new View.OnClickListener() {
                public void onClick(View v) {
                    host.clips.remove(id);
                    host.clips.flush();
                    host.clipsChanged();
                    finish();
                }
            }), btnLp());
        }
        setContentView(root);
        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(t.kbd);
            getWindow().setNavigationBarColor(t.kbd);
        }
        if (Build.VERSION.SDK_INT >= 23) {
            getWindow().getDecorView().setSystemUiVisibility(t.dark ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
    }

    private LinearLayout.LayoutParams btnLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        int m = Math.round(4 * dp);
        lp.setMargins(m, 0, m, 0);
        return lp;
    }

    private TextView button(String label, int bg, int fg, View.OnClickListener l) {
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextColor(fg);
        tv.setTextSize(15f);
        tv.setGravity(Gravity.CENTER);
        int p = Math.round(14 * dp);
        tv.setPadding(p / 2, p, p / 2, p);
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(bg);
        gd.setCornerRadius(14 * dp);
        tv.setBackground(gd);
        tv.setOnClickListener(l);
        return tv;
    }

    private void save() {
        String text = et.getText().toString();
        if (text.trim().length() == 0) {
            Toast.makeText(this, "دەقەکە بەتاڵە", Toast.LENGTH_SHORT).show();
            return;
        }
        if (id == 0) host.clips.add(text); else host.clips.update(id, text);
        host.clips.flush();
        host.clipsChanged();
        finish();
    }
}
