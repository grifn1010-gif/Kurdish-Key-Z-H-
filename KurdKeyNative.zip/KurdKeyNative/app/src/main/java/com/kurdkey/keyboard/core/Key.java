package com.kurdkey.keyboard.core;

/** One key. Geometry fields are filled by Layout.place(). */
public final class Key {
    public static final int CHAR = 0, SHIFT = 1, BACKSPACE = 2, ENTER = 3, SPACE = 4, MODE = 5, SYM2 = 6, LANG = 7, EMOJI = 8,
            HAND_EXPAND = 9, HAND_SWAP = 10;
    public static final int ST_LETTER = 0, ST_FUNC = 1, ST_ACCENT = 2;
    public static final String[] NONE = new String[0];

    public final int type;
    public String label = "";
    public String text = "";
    public String[] alts = NONE;
    public String hint = "";
    public float weight = 1f;
    public int style = ST_LETTER;
    public boolean letter;         // Latin letter: follows shift state
    public boolean small;          // draw label smaller (number row, mode keys)
    public Icon icon;
    public int row;

    // geometry in px (visual rect + hit rect)
    public float x, y, w, h;
    public float hx0, hy0, hx1, hy1;

    public Key(int type) { this.type = type; }

    public static Key chr(String label, String text) {
        Key k = new Key(CHAR);
        k.label = label; k.text = text;
        return k;
    }

    /** "a|b|c": text a, alternates b,c; hint is b. */
    public static Key spec(String spec) {
        if (spec.length() == 0 || spec.equals("|")) return chr(spec.length() == 0 ? " " : "|", spec.length() == 0 ? " " : "|");
        String[] p = spec.split("\\|");
        Key k = chr(p[0], p[0]);
        if (p.length > 1) {
            k.alts = new String[p.length - 1];
            System.arraycopy(p, 1, k.alts, 0, p.length - 1);
        }
        return k;
    }

    public boolean contains(float px, float py) { return px >= x && px < x + w && py >= y && py < y + h; }
}
