package com.kurdkey.keyboard.core;

import java.util.ArrayList;
import java.util.Locale;

/** Suggestion/tool strip + key rows: drawing and all touch handling for typing. */
public final class KeyboardScreen implements Screen {
    private static final int MAXP = 6;
    private static final int S_TOGGLE = 0, S_SUG = 1, S_EMOJI = 2, S_TOOL = 3;

    private static final class Item {
        int type, idx;
        float x, y, w, h;
        String text = "";
        Icon icon;
        int tool;
    }

    private static final class Ptr {
        int id;
        boolean active;
        int zone;             // 0 keys, 1 strip, 2 side keys
        Key key;
        Item item;
        float downX, downY, lastX, stepAcc;
        boolean popup, swiped, longFired, done, shiftHeld, shiftUsed;
        Object lpToken, repToken;
        int repN;
    }

    private static final class Popup {
        Key key;
        String[] items;
        String[] shown;
        float x, y, w, h, cw, pad;
        boolean rev;
        int sel;
        int owner;
    }

    private final Host h;
    private Layout layout;
    private float W, H, stripH;
    private boolean land;
    private final Ptr[] ptrs = new Ptr[MAXP];
    private Popup popup;
    private final ArrayList<Item> strip = new ArrayList<Item>();
    private final Key[] side = new Key[2];
    private float sideX, sideW;
    private float xOff, usableW;
    public boolean stripVisible = true;

    public KeyboardScreen(Host h) {
        this.h = h;
        for (int i = 0; i < MAXP; i++) ptrs[i] = new Ptr();
    }

    // ---------------------------------------------------------------- layout

    public void invalidateLayout() { layout = null; }

    /** The page currently shown (for tests and previews). */
    public Layout currentLayout() { ensureLayout(); return layout; }

    public float stripHeightNow() { return stripH; }

    /** Centre of the i-th popup cell (kb coordinates) or null when no popup is open. */
    public float[] popupCellCenter(int i) {
        Popup p = popup;
        if (p == null || i < 0 || i >= p.shown.length) return null;
        return new float[]{cellCenter(p, i), p.y + p.h / 2f};
    }

    private void ensureLayout() {
        if (layout != null) return;
        land = h.p.landscape();
        FieldInfo fi = h.field;
        String id = h.st.layoutId();
        if (fi != null) {
            if (fi.kind == FieldInfo.K_NUMBER || fi.kind == FieldInfo.K_DATETIME) id = Layouts.NUM;
            else if (fi.kind == FieldInfo.K_PHONE) id = Layouts.PHONE;
        }
        layout = Layouts.build(id, fi, h.cfg, land, h.st.lang == KbState.KU);
        if (W > 0) placeKeys();
    }

    private float baseKeyH() {
        float dp = h.dp();
        float pct = land ? Math.max(80, Math.min(h.cfg.keyHeight, 100)) : h.cfg.keyHeight;
        float kh = (land ? (h.cfg.numRowLand ? 29f : 34f) : 50f) * dp * pct / 100f;
        if (layout != null && layout.numeric) kh *= land ? 1.0f : 1.05f;
        return kh;
    }

    private float stripHeight() {
        if (layout != null && layout.numeric) return 0f;
        if (!stripVisible) return 0f;
        return (land ? 36f : 46f) * h.dp();
    }

    private float padTop() { return (land ? 3f : 5f) * h.dp(); }
    private float padBottom() { return (land ? 3f : 6f) * h.dp(); }
    private float gapX() { return (land ? 4f : 5f) * h.dp(); }
    private float gapY() { return (land ? 4f : 6f) * h.dp(); }

    public float desiredHeight(float w) {
        land = h.p.landscape();
        ensureLayout();
        float rows = layout.totalRel() * baseKeyH();
        float gaps = (layout.rows.size() - 1) * gapY();
        return stripHeight() + padTop() + rows + gaps + padBottom();
    }

    public void layout(float w, float hh) {
        W = w; H = hh;
        land = h.p.landscape();
        ensureLayout();
        placeKeys();
    }

    private void placeKeys() {
        float dp = h.dp();
        stripH = stripHeight();
        boolean oneHand = h.cfg.hand != 0 && !layout.numeric && W > 300 * dp && !land;
        usableW = oneHand ? W * 0.86f : W;
        xOff = (oneHand && h.cfg.hand == 2) ? W - usableW : 0f;
        float padX = 3f * dp;
        float left = xOff + padX, width = usableW - 2 * padX;
        float top = stripH + padTop();
        float height = H - top - padBottom();
        float oL = xOff, oR = xOff + usableW;
        layout.place(left, top, width, height, gapX(), gapY(), oL, stripH, oR, H);
        if (oneHand) {
            sideW = W - usableW;
            sideX = h.cfg.hand == 1 ? usableW : 0f;
            for (int i = 0; i < 2; i++) {
                Key k = new Key(i == 0 ? Key.HAND_EXPAND : Key.HAND_SWAP);
                k.style = Key.ST_FUNC;
                k.icon = i == 0 ? Icons.KEYBOARD : (h.cfg.hand == 1 ? Icons.HAND_RIGHT : Icons.HAND_LEFT);
                float kh = (H - top - padBottom() - gapY()) / 2f;
                k.x = sideX + 3 * dp; k.w = sideW - 6 * dp;
                k.y = top + i * (kh + gapY()); k.h = kh;
                k.hx0 = sideX; k.hx1 = sideX + sideW; k.hy0 = i == 0 ? stripH : k.y - gapY() / 2; k.hy1 = i == 0 ? k.y + k.h + gapY() / 2 : H;
                side[i] = k;
            }
        } else { side[0] = null; side[1] = null; sideW = 0; }
        rebuildStrip();
    }

    /** Rebuild the strip items (call after suggestions/toolbar state change). */
    public void rebuildStrip() {
        strip.clear();
        if (stripH <= 0 || W <= 0) return;
        float dp = h.dp();
        float tw = (land ? 40f : 44f) * dp;
        float x0 = xOff, total = usableW;
        Item t = new Item();
        t.type = S_TOGGLE; t.x = x0; t.y = 0; t.w = tw; t.h = stripH;
        t.icon = h.st.toolbar ? Icons.CHEV_UP : Icons.CHEV_DOWN;
        strip.add(t);
        float rest = total - tw;
        if (h.st.toolbar) {
            int[] tools = Host.TOOLBAR;
            float w = rest / tools.length;
            for (int i = 0; i < tools.length; i++) {
                Item it = new Item();
                it.type = S_TOOL; it.tool = tools[i]; it.idx = i;
                it.x = x0 + tw + i * w; it.y = 0; it.w = w; it.h = stripH;
                it.icon = Host.toolIcon(tools[i]);
                strip.add(it);
            }
        } else {
            Suggest.Result r = h.sug;
            int ne = r == null ? 0 : r.emoji.length;
            float ew = 46f * dp;
            float sw = (rest - ne * ew) / 3f;
            for (int i = 0; i < 3; i++) {
                Item it = new Item();
                it.type = S_SUG; it.idx = i;
                it.x = x0 + tw + i * sw; it.y = 0; it.w = sw; it.h = stripH;
                it.text = r == null ? "" : r.slot[i];
                strip.add(it);
            }
            for (int i = 0; i < ne; i++) {
                Item it = new Item();
                it.type = S_EMOJI; it.idx = i;
                it.x = x0 + tw + 3 * sw + i * ew; it.y = 0; it.w = ew; it.h = stripH;
                it.text = r.emoji[i];
                strip.add(it);
            }
        }
    }

    // ---------------------------------------------------------------- drawing

    public float fullStripH() { return (h.p.landscape() ? 36f : 46f) * h.dp(); }

    public void draw(Gfx g) {
        if (layout == null) ensureLayout();
        if (layout == null) return;
        Theme t = h.theme;
        float dp = g.dp();
        g.fillRect(0, 0, W, H, t.kbd);
        if (stripH > 0) drawStrip(g, t, dp);
        for (Key[] row : layout.rows) for (Key k : row) drawKey(g, t, dp, k);
        for (Key k : side) if (k != null) drawKey(g, t, dp, k);
        // previews and popup on top
        for (Ptr p : ptrs) {
            if (p.active && p.zone == 0 && p.key != null && !p.popup) drawPreview(g, t, dp, p.key);
        }
        if (popup != null) drawPopup(g, t, dp);
    }

    private boolean isDown(Key k) {
        for (Ptr p : ptrs) if (p.active && p.key == k && (p.zone == 0 || p.zone == 2)) return true;
        return false;
    }

    private void drawStrip(Gfx g, Theme t, float dp) {
        g.fillRect(0, 0, W, stripH, t.kbd);
        for (Item it : strip) {
            boolean down = false;
            for (Ptr p : ptrs) if (p.active && p.zone == 1 && p.item == it) down = true;
            if (down) g.fillRound(it.x + 2 * dp, it.y + 4 * dp, it.x + it.w - 2 * dp, it.y + it.h - 4 * dp, 10 * dp, t.keyDown);
            float cx = it.x + it.w / 2f, cy = it.y + it.h / 2f;
            switch (it.type) {
                case S_TOGGLE:
                    g.icon(it.icon, cx, cy, 22 * dp, t.muted);
                    break;
                case S_TOOL:
                    g.icon(it.icon, cx, cy, 23 * dp, t.fg);
                    break;
                case S_EMOJI:
                    g.text(it.text, cx, cy, 24 * dp, t.fg, Gfx.NORMAL, Gfx.CENTER);
                    break;
                default: {
                    if (it.text == null || it.text.length() == 0) break;
                    boolean tr = h.sug != null && it.idx == h.sug.trSlot;
                    boolean typed = it.idx == 1 && h.logic != null && h.logic.word.length() > 0;
                    int col = tr ? t.accent : (typed ? t.fg : t.fg);
                    float size = 17f * dp;
                    String s = fit(g, it.text, size, it.w - 10 * dp, tr || typed ? Gfx.BOLD : Gfx.NORMAL);
                    g.text(s, cx, cy, size, col, tr ? Gfx.BOLD : Gfx.NORMAL, Gfx.CENTER);
                    break;
                }
            }
            if (it.type == S_SUG && it.idx < 2 && !h.st.toolbar) {
                float sx = it.x + it.w;
                g.fillRect(sx - 0.5f * dp, it.y + stripH * 0.27f, sx + 0.5f * dp, it.y + stripH * 0.73f, t.line);
            }
        }
    }

    private static String fit(Gfx g, String s, float size, float maxW, int style) {
        if (g.textWidth(s, size, style) <= maxW) return s;
        int n = s.length();
        while (n > 1 && g.textWidth(s.substring(0, n) + "…", size, style) > maxW) n--;
        return s.substring(0, Math.max(1, n)) + "…";
    }

    private void drawKey(Gfx g, Theme t, float dp, Key k) {
        Cfg c = h.cfg;
        boolean down = isDown(k);
        float r = c.keyRadius * dp;
        int bg, fg = t.fg;
        switch (k.style) {
            case Key.ST_ACCENT: bg = t.accent; fg = t.accentFg; break;
            case Key.ST_FUNC: bg = t.keyAlt; break;
            default: bg = t.key;
        }
        boolean shiftOn = k.type == Key.SHIFT && h.st.shift > 0;
        if (shiftOn) { bg = t.accent; fg = t.accentFg; }
        if (down) bg = k.style == Key.ST_ACCENT || shiftOn ? Theme.mix(bg, 0xFF000000, 0.2f) : t.keyDown;
        float l = k.x, tp = k.y, rt = k.x + k.w, bt = k.y + k.h;
        if (c.keyStyle == 2) {
            g.fillRound(l, tp, rt, bt, r, down ? bg : Theme.withAlpha(bg, k.style == Key.ST_LETTER ? 0 : 60));
            g.strokeRound(l + 0.75f * dp, tp + 0.75f * dp, rt - 0.75f * dp, bt - 0.75f * dp, r, 1.5f * dp, k.style == Key.ST_ACCENT || shiftOn ? t.accent : t.line);
        } else {
            if (c.keyStyle == 0) g.fillRound(l, tp + 1.5f * dp, rt, bt + 1.5f * dp, r, t.shadow);
            g.fillRound(l, tp, rt, bt, r, bg);
        }
        float cx = k.x + k.w / 2f, cy = k.y + k.h / 2f;
        Icon ic = k.icon;
        if (k.type == Key.SHIFT) ic = h.st.shift == 2 ? Icons.CAPS : (h.st.shift == 1 ? Icons.SHIFT_ON : Icons.SHIFT);
        if (k.type == Key.ENTER) ic = Layouts.enterIcon(h.field);
        if (ic != null) {
            float is = Math.min(k.h * 0.46f, 24f * dp);
            g.icon(ic, cx, cy, is, fg);
            return;
        }
        String label = h.keyLabel(k);
        if (label.length() == 0) return;
        float scale = c.keyText / 100f;
        int style = c.font == 1 || k.type == Key.MODE ? Gfx.BOLD : Gfx.NORMAL;
        if (k.type == Key.SPACE) {
            float size = 13f * dp * scale;
            g.text(fit(g, label, size, k.w - 12 * dp, Gfx.NORMAL), cx, cy, size, t.muted, Gfx.NORMAL, Gfx.CENTER);
            return;
        }
        float size = Math.min(k.h * 0.46f, 23f * dp) * scale;
        if (k.small) size *= k.type == Key.MODE || k.type == Key.SYM2 || label.length() > 1 ? 0.62f : 0.78f;
        if (label.length() > 1 && !k.small) size *= 0.8f;
        size = Math.max(size, 9f * dp);
        float maxW = k.w - 6 * dp;
        float wdt = g.textWidth(label, size, style);
        if (wdt > maxW) size *= maxW / wdt;
        g.text(label, cx, cy, size, fg, style, Gfx.CENTER);
        if (c.hints && k.type == Key.CHAR && k.hint.length() > 0 && !k.small && k.style == Key.ST_LETTER) {
            String hn = h.hintLabel(k);
            float hs = 10.5f * dp * Math.min(1f, scale);
            g.text(hn, k.x + k.w - 4.5f * dp, k.y + 10.5f * dp, hs, t.hint, Gfx.NORMAL, Gfx.RIGHT);
        }
    }

    private void drawPreview(Gfx g, Theme t, float dp, Key k) {
        if (!h.cfg.preview || k.type != Key.CHAR) return;
        String label = h.keyLabel(k);
        if (label.length() == 0 || label.length() > 2) return;
        float bw = Math.max(k.w * 1.35f, 54f * dp), bh = k.h * 1.3f;
        float x = Math.max(2 * dp, Math.min(W - bw - 2 * dp, k.x + k.w / 2f - bw / 2f));
        float y = Math.max(0f, k.y - bh - 3 * dp);
        g.fillRound(x, y + 1.5f * dp, x + bw, y + bh + 1.5f * dp, 12 * dp, t.shadow);
        g.fillRound(x, y, x + bw, y + bh, 12 * dp, t.pop);
        g.text(label, x + bw / 2f, y + bh / 2f, Math.min(bh * 0.52f, 34f * dp), t.popFg, Gfx.NORMAL, Gfx.CENTER);
    }

    private void drawPopup(Gfx g, Theme t, float dp) {
        Popup p = popup;
        g.fillRound(p.x, p.y + 2 * dp, p.x + p.w, p.y + p.h + 2 * dp, 12 * dp, t.shadow);
        g.fillRound(p.x, p.y, p.x + p.w, p.y + p.h, 12 * dp, t.pop);
        for (int i = 0; i < p.shown.length; i++) {
            float cx = cellCenter(p, i);
            boolean sel = i == p.sel;
            if (sel) g.fillRound(cx - p.cw / 2f + 2 * dp, p.y + 4 * dp, cx + p.cw / 2f - 2 * dp, p.y + p.h - 4 * dp, 9 * dp, t.accent);
            String s = p.shown[i];
            float size = Math.min(p.h * 0.46f, 26f * dp);
            if (s.length() > 2) size *= 0.62f;
            float wdt = g.textWidth(s, size, Gfx.NORMAL);
            if (wdt > p.cw - 6 * dp) size *= (p.cw - 6 * dp) / wdt;
            g.text(s, cx, p.y + p.h / 2f, size, sel ? t.accentFg : t.popFg, Gfx.NORMAL, Gfx.CENTER);
        }
    }

    private float cellCenter(Popup p, int i) {
        return p.rev ? p.x + p.w - p.pad - (i + 0.5f) * p.cw : p.x + p.pad + (i + 0.5f) * p.cw;
    }

    // ---------------------------------------------------------------- touch

    private Ptr find(int id) {
        for (Ptr p : ptrs) if (p.active && p.id == id) return p;
        return null;
    }

    private Ptr alloc(int id) {
        for (Ptr p : ptrs) if (!p.active) {
            p.active = true; p.id = id; p.key = null; p.item = null; p.popup = false; p.swiped = false;
            p.longFired = false; p.done = false; p.shiftHeld = false; p.shiftUsed = false; p.lpToken = null; p.repToken = null; p.repN = 0;
            return p;
        }
        return null;
    }

    private Item stripHit(float x, float y) {
        Item best = null;
        for (Item it : strip) if (x >= it.x && x < it.x + it.w && y >= it.y && y < it.y + it.h) return it;
        return best;
    }

    private void cancelTimers(Ptr p) {
        if (p.lpToken != null) { h.p.cancel(p.lpToken); p.lpToken = null; }
        if (p.repToken != null) { h.p.cancel(p.repToken); p.repToken = null; }
    }

    public boolean touch(int action, int id, float x, float y) {
        if (layout == null) ensureLayout();
        if (layout == null) return false;
        switch (action) {
            case DOWN: return down(id, x, y);
            case MOVE: return move(id, x, y);
            case UP: return up(id, x, y, false);
            default: return up(id, x, y, true);
        }
    }

    private boolean down(int id, float x, float y) {
        Ptr p = alloc(id);
        if (p == null) return true;
        p.downX = x; p.downY = y; p.lastX = x; p.stepAcc = 0;
        if (y < stripH && stripH > 0) {
            p.zone = 1;
            p.item = stripHit(x, y);
            if (p.item != null) {
                h.p.feedback(0);
                if (p.item.type == S_SUG && p.item.idx != 1 || p.item.type == S_SUG && p.item.idx == 1 && h.logic.word.length() == 0) {
                    if (p.item.text != null && p.item.text.length() > 0) {
                        final Ptr fp = p;
                        p.lpToken = h.p.post(new Runnable() { public void run() { fp.lpToken = null; if (fp.active && fp.item != null) { fp.longFired = true; h.banSuggestion(fp.item.idx); } } }, 700);
                    }
                }
            }
            h.p.invalidate();
            return true;
        }
        // side keys (one-handed)
        for (Key sk : side) {
            if (sk != null && x >= sk.hx0 && x < sk.hx1 && y >= sk.hy0 && y < sk.hy1) {
                p.zone = 2; p.key = sk;
                h.p.feedback(4);
                h.p.invalidate();
                return true;
            }
        }
        p.zone = 0;
        Key k = layout.hit(x, y);
        p.key = k;
        if (k == null) { p.active = false; return true; }
        pressKey(p, k);
        h.p.invalidate();
        return true;
    }

    private void pressKey(final Ptr p, Key k) {
        switch (k.type) {
            case Key.CHAR:
                h.p.feedback(0);
                if (h.cfg.typeOnPress && k.alts.length == 0) {
                    commitChar(p, k, null);
                    p.done = true;
                } else if (k.alts.length > 0) {
                    schedulePopup(p);
                }
                break;
            case Key.SHIFT:
                h.p.feedback(4);
                p.shiftHeld = true;
                h.shiftHeld = true;
                h.shiftDown();
                p.done = true;
                break;
            case Key.BACKSPACE:
                h.p.feedback(2);
                h.backspace(false);
                p.done = true;
                p.repToken = h.p.post(new Runnable() { public void run() { p.repToken = null; p.repN = 0; repeat(p); } }, 380);
                break;
            case Key.MODE:
                h.p.feedback(4);
                h.toggleMode();
                p.done = true;
                break;
            case Key.SYM2:
                h.p.feedback(4);
                h.toggleSym2();
                p.done = true;
                break;
            case Key.SPACE:
                h.p.feedback(1);
                if (!layout.numeric) p.lpToken = h.p.post(new Runnable() { public void run() {
                    p.lpToken = null;
                    if (p.active && !p.swiped) { p.longFired = true; h.toggleLang(); }
                } }, 600);
                break;
            case Key.LANG:
                h.p.feedback(4);
                p.lpToken = h.p.post(new Runnable() { public void run() { p.lpToken = null; if (p.active) { p.longFired = true; h.showPicker(); } } }, 450);
                break;
            case Key.ENTER:
                h.p.feedback(3);
                break;
            default:
                h.p.feedback(4);
        }
    }

    private void repeat(final Ptr p) {
        if (!p.active || p.key == null || p.key.type != Key.BACKSPACE) return;
        p.repN++;
        boolean word = p.repN > 12;
        h.backspace(word);
        long delay = word ? 130 : (p.repN > 6 ? 40 : 55);
        p.repToken = h.p.post(new Runnable() { public void run() { p.repToken = null; repeat(p); } }, delay);
    }

    private void schedulePopup(final Ptr p) {
        if (p.lpToken != null) h.p.cancel(p.lpToken);
        p.lpToken = h.p.post(new Runnable() { public void run() {
            p.lpToken = null;
            if (p.active && p.key != null && p.key.type == Key.CHAR && !p.popup) openPopup(p);
        } }, h.cfg.longPress);
    }

    private void openPopup(Ptr p) {
        Key k = p.key;
        float dp = h.dp();
        int n = k.alts.length;
        Popup pp = new Popup();
        pp.key = k; pp.items = k.alts; pp.owner = p.id;
        pp.shown = new String[n];
        for (int i = 0; i < n; i++) pp.shown[i] = h.altLabel(k, k.alts[i]);
        pp.cw = Math.max(k.w * 0.92f, 40f * dp);
        pp.pad = 4f * dp;
        float maxCells = (W - 8 * dp - 2 * pp.pad) / pp.cw;
        if (n > maxCells) pp.cw = (W - 8 * dp - 2 * pp.pad) / n;
        pp.w = pp.cw * n + 2 * pp.pad;
        pp.h = Math.max(k.h * 1.1f, 48f * dp);
        pp.rev = k.x + k.w / 2f > W / 2f;
        float left = pp.rev ? k.x + k.w - pp.w : k.x;
        left = Math.max(4 * dp, Math.min(W - pp.w - 4 * dp, left));
        pp.x = left;
        pp.y = Math.max(2 * dp, k.y - pp.h - 4 * dp);
        pp.sel = 0;
        popup = pp;
        p.popup = true;
        h.p.feedback(4);
        h.p.invalidate();
    }

    private int popupIndex(Popup pp, float x) {
        int i = pp.rev ? (int) Math.floor((pp.x + pp.w - pp.pad - x) / pp.cw) : (int) Math.floor((x - pp.x - pp.pad) / pp.cw);
        return Math.max(0, Math.min(pp.shown.length - 1, i));
    }

    private boolean move(int id, float x, float y) {
        Ptr p = find(id);
        if (p == null) return true;
        if (p.zone == 1) {
            if (p.item != null && p.lpToken != null && (Math.abs(x - p.downX) > 18 * h.dp() || Math.abs(y - p.downY) > 24 * h.dp())) { h.p.cancel(p.lpToken); p.lpToken = null; p.item = null; h.p.invalidate(); }
            return true;
        }
        if (p.zone == 2 || p.key == null) return true;
        float dp = h.dp();
        if (p.popup && popup != null) {
            int i = popupIndex(popup, x);
            if (i != popup.sel) { popup.sel = i; h.p.feedback(0); h.p.invalidate(); }
            return true;
        }
        Key k = p.key;
        if (k.type == Key.SPACE && !p.longFired && h.cfg.spaceSwipe && !layout.numeric) {
            if (!p.swiped && Math.abs(x - p.downX) > 14 * dp) {
                p.swiped = true;
                if (p.lpToken != null) { h.p.cancel(p.lpToken); p.lpToken = null; }
            }
            if (p.swiped) {
                p.stepAcc += x - p.lastX;
                float step = 13f * dp;
                while (p.stepAcc >= step) { h.moveCursor(1); p.stepAcc -= step; }
                while (p.stepAcc <= -step) { h.moveCursor(-1); p.stepAcc += step; }
            }
            p.lastX = x;
            return true;
        }
        p.lastX = x;
        if (k.type == Key.CHAR && !p.done) {
            Key nk = layout.hit(x, y);
            if (nk != null && nk != k && nk.type == Key.CHAR && y > stripH) {
                if (p.lpToken != null) { h.p.cancel(p.lpToken); p.lpToken = null; }
                p.key = nk;
                h.p.feedback(0);
                if (nk.alts.length > 0) schedulePopup(p);
                h.p.invalidate();
            }
        }
        return true;
    }

    private boolean up(int id, float x, float y, boolean cancel) {
        Ptr p = find(id);
        if (p == null) return true;
        cancelTimers(p);
        p.active = false;
        if (p.zone == 1) {
            if (!cancel && !p.longFired && p.item != null) {
                Item it = stripHit(x, y);
                if (it == p.item) activateItem(it);
            }
            h.p.invalidate();
            return true;
        }
        Key k = p.key;
        if (k == null) return true;
        if (p.zone == 2) {
            if (!cancel && x >= k.hx0 && x < k.hx1 && y >= k.hy0 && y < k.hy1) {
                if (k.type == Key.HAND_EXPAND) h.setHand(0);
                else h.setHand(h.cfg.hand == 1 ? 2 : 1);
            }
            h.p.invalidate();
            return true;
        }
        if (p.popup && popup != null && popup.owner == id) {
            if (!cancel) {
                String s = popup.items[popup.sel];
                commitChar(p, k, s);
            }
            popup = null;
            h.p.invalidate();
            return true;
        }
        if (k.type == Key.SHIFT) {
            h.shiftHeld = false;
            h.shiftUp(p.shiftUsed);
        }
        if (!cancel && !p.done && !p.longFired) {
            switch (k.type) {
                case Key.CHAR: commitChar(p, k, null); break;
                case Key.SPACE: if (!p.swiped) h.space(); break;
                case Key.ENTER: if (layout.hit(x, y) == k) h.enter(); break;
                case Key.LANG: if (layout.hit(x, y) == k) h.toggleLang(); break;
                case Key.EMOJI: if (layout.hit(x, y) == k) h.openEmoji(); break;
                default: break;
            }
        }
        h.p.invalidate();
        return true;
    }

    private void commitChar(Ptr p, Key k, String alt) {
        for (Ptr q : ptrs) if (q.active && q.shiftHeld) q.shiftUsed = true;
        h.typeKey(k, alt);
    }

    private void activateItem(Item it) {
        switch (it.type) {
            case S_TOGGLE: h.toggleToolbar(); break;
            case S_TOOL: h.runTool(it.tool); break;
            case S_EMOJI: h.acceptEmojiSuggestion(it.idx); break;
            default: if (it.text != null && it.text.length() > 0) h.acceptSuggestion(it.idx);
        }
    }

    public boolean animating() { return false; }
    public void tick(long nowMs) { }

    public void onShow() { invalidateLayout(); }

    public void onHide() { cancelAll(); }

    public void cancelAll() {
        for (Ptr p : ptrs) if (p.active) { cancelTimers(p); p.active = false; }
        popup = null;
        h.shiftHeld = false;
    }
}
