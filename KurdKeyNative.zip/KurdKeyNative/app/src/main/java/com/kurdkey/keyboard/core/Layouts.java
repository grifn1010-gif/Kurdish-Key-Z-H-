package com.kurdkey.keyboard.core;

/** All keyboard pages (Kurdish, English, symbols, number pads). */
public final class Layouts {
    private Layouts() {}

    public static final String KU = "ku", EN = "en", S1 = "s1", S2 = "s2", NUM = "num", PHONE = "phone";
    private static final String AR_DIGITS = "١٢٣٤٥٦٧٨٩٠";
    private static final String[] KU_ROW1 = {"ق|١", "و|٢|ؤ", "ە|٣|ة", "ر|ڕ|٤", "ت|٥|ط|ث",
            "ی|٦", "ێ|٧", "ئ|٨|ء", "ۆ|٩", "پ|٠"};
    private static final String[] KU_ROW2 = {"ا|ع|آ|أ", "س|ش|ص", "د|'|ذ|ض", "ف|\"", "گ|غ",
            "ھ|ح|ه", "ژ|=", "ک|ك", "ل|ڵ"};
    private static final String[] KU_ROW3 = {"؛|-", "ز|_|ظ", "خ", "ج|@", "چ|(", "ڤ|ڥ", "ب|;", "ن|ں", "م|)"};
    private static final String[] EN_ROW1 = {"q", "w", "e|ê|é|è|ë", "r", "t", "y|ý", "u|û|ü|ú|ù", "i|î|í|ï|ì", "o|ö|ô|ó|ò|ø", "p"};
    private static final String[] EN_ROW2 = {"a|á|à|â|ä|å", "s|ş|ß|š", "d", "f", "g|ğ", "h", "j", "k", "l"};
    private static final String[] EN_ROW3 = {"z|ž", "x", "c|ç|ć|č", "v", "b", "n|ñ", "m"};
    private static final String[][] SY1 = {
            {"@", "#", "$", "%|٪", "&", "-|–|—", "+|±", "(", ")", "/"},
            {"*", "\"|“|”", "'|‘|’", ":", ";", "!|¡", "?|¿", "=", "_", "\\"},
            {"،", "؛", "؟", "«", "»", "…", "<", "‌"}};
    private static final String[][] SY2 = {
            {"~", "`", "|", "•", "√", "π", "÷", "×", "¶", "∆"},
            {"£", "¢", "€", "¥", "^", "°", "{", "}", "[", "]"},
            {"©", "®", "™", "✓", "§", ">", "‹", "›"}};

    public static Layout build(String id, FieldInfo fi, Cfg cfg, boolean land) {
        return build(id, fi, cfg, land, id.equals(KU));
    }

    /** @param kuLanguage true when the letters page behind the symbol pages is Kurdish (decides the back-button label). */
    public static Layout build(String id, FieldInfo fi, Cfg cfg, boolean land, boolean kuLanguage) {
        if (id.equals(NUM)) return numberPad(fi, false);
        if (id.equals(PHONE)) return numberPad(fi, true);
        boolean ku = id.equals(KU) || (!id.equals(EN) && !id.equals(S1) && !id.equals(S2));
        Layout l = new Layout(id);
        boolean showNum = land ? cfg.numRowLand : cfg.numRow;
        boolean kuLang = id.equals(KU);
        boolean digitsHint = !showNum;
        if (showNum) l.addRow(0.78f, numberRow(kuLang && cfg.kuDigits, kuLang));

        if (id.equals(KU)) {
            l.addRow(1f, row(KU_ROW1, false, digitsHint, kuLang, 0));
            l.addRow(1f, row(KU_ROW2, false, false, kuLang, 0));
            Key[] r3 = row(KU_ROW3, false, false, kuLang, 0);
            Key[] r3b = new Key[r3.length + 1];
            System.arraycopy(r3, 0, r3b, 0, r3.length);
            r3b[r3.length] = backspace(1f);
            l.addRow(1f, r3b);
        } else if (id.equals(EN)) {
            l.addRow(1f, row(EN_ROW1, true, digitsHint, false, 0));
            l.addRow(1f, row(EN_ROW2, true, false, false, 0));
            Key[] r3 = row(EN_ROW3, true, false, false, 0);
            Key[] r3b = new Key[r3.length + 2];
            Key sh = new Key(Key.SHIFT); sh.weight = 1.5f; sh.style = Key.ST_FUNC; sh.icon = Icons.SHIFT;
            r3b[0] = sh;
            System.arraycopy(r3, 0, r3b, 1, r3.length);
            r3b[r3.length + 1] = backspace(1.5f);
            l.addRow(1f, r3b);
        } else {
            String[][] src = id.equals(S1) ? SY1 : SY2;
            l.addRow(1f, row(src[0], false, false, false, 0));
            l.addRow(1f, row(src[1], false, false, false, 0));
            Key[] r3 = row(src[2], false, false, false, 0);
            for (Key k : r3) if (k.text.equals("‌")) { k.label = "ZWNJ"; k.small = true; }
            Key[] r3b = new Key[r3.length + 2];
            Key sy = new Key(Key.SYM2); sy.weight = 1f; sy.style = Key.ST_FUNC; sy.small = true; sy.label = id.equals(S1) ? "=\\<" : "1/2";
            r3b[0] = sy;
            System.arraycopy(r3, 0, r3b, 1, r3.length);
            r3b[r3.length + 1] = backspace(1f);
            l.addRow(1f, r3b);
        }
        l.addRow(1f, bottomRow(id, fi, kuLanguage));
        return l;
    }

    private static Key backspace(float w) {
        Key k = new Key(Key.BACKSPACE);
        k.weight = w; k.style = Key.ST_FUNC; k.icon = Icons.BACKSPACE;
        return k;
    }

    private static Key[] numberRow(boolean arabic, boolean ku) {
        Key[] r = new Key[10];
        String[][] enAlts = {{"¹", "½"}, {"²"}, {"³", "¾"}, {"⁴"}, {}, {}, {}, {}, {}, {"°", "⁰"}};
        for (int i = 0; i < 10; i++) {
            String la = String.valueOf((char) ('1' + (i == 9 ? -1 : i)));
            if (i == 9) la = "0";
            String ar = String.valueOf(AR_DIGITS.charAt(i));
            Key k = arabic ? Key.chr(ar, ar) : Key.chr(la, la);
            k.small = true;
            if (arabic) k.alts = new String[]{la};
            else if (ku) k.alts = new String[]{ar};
            else k.alts = enAlts[i];
            r[i] = k;
        }
        return r;
    }

    private static Key[] row(String[] specs, boolean letters, boolean digitHint, boolean ku, int rowIndex) {
        Key[] r = new Key[specs.length];
        for (int i = 0; i < specs.length; i++) {
            Key k = Key.spec(specs[i]);
            k.letter = letters && k.text.length() == 1 && Character.isLetter(k.text.charAt(0));
            r[i] = k;
        }
        if (digitHint && letters) {
            String d = "1234567890";
            for (int i = 0; i < r.length && i < 10; i++) {
                String dg = String.valueOf(d.charAt(i));
                String[] na = new String[r[i].alts.length + 1];
                na[0] = dg;
                System.arraycopy(r[i].alts, 0, na, 1, r[i].alts.length);
                r[i].alts = na;
            }
        } else if (digitHint && ku) {
            String d = "1234567890";
            for (int i = 0; i < r.length && i < 10; i++) {
                String[] na = new String[r[i].alts.length + 1];
                System.arraycopy(r[i].alts, 0, na, 0, r[i].alts.length);
                na[r[i].alts.length] = String.valueOf(d.charAt(i));
                r[i].alts = na;
            }
        }
        if (ku && !digitHint) {   // the number row already has the digits: no duplicate digit alternates
            for (Key k : r) {
                java.util.List<String> keep = new java.util.ArrayList<String>();
                for (String a : k.alts) if (!(a.length() == 1 && AR_DIGITS.indexOf(a.charAt(0)) >= 0)) keep.add(a);
                if (keep.size() != k.alts.length) k.alts = keep.toArray(new String[0]);
            }
        }
        // web keyboard shows the first alternate as a small hint on the key
        for (Key k : r) if (k.alts.length > 0 && k.hint.length() == 0) k.hint = k.alts[0];
        return r;
    }

    private static Key[] bottomRow(String id, FieldInfo fi, boolean kuLanguage) {
        boolean ku = id.equals(KU);
        boolean letters = id.equals(KU) || id.equals(EN);
        Key mode = new Key(Key.MODE);
        mode.weight = 1.3f; mode.style = Key.ST_FUNC; mode.small = true;
        mode.label = letters ? "123" : (kuLanguage ? "ئەب" : "ABC");
        Key lang = new Key(Key.LANG);
        lang.style = Key.ST_FUNC; lang.icon = Icons.GLOBE;
        Key emoji = new Key(Key.EMOJI);
        emoji.style = Key.ST_FUNC; emoji.icon = Icons.SMILE;

        Key comma;
        int kind = fi == null ? FieldInfo.K_TEXT : fi.kind;
        if (kind == FieldInfo.K_EMAIL) { comma = Key.chr("@", "@"); comma.alts = new String[]{",", "_", "-"}; }
        else if (kind == FieldInfo.K_URL) { comma = Key.chr("/", "/"); comma.alts = new String[]{",", "-", "_", "?", "&"}; }
        else if (ku) { comma = Key.chr("،", "،"); comma.alts = new String[]{"؟", "؛", ","}; }
        else { comma = Key.chr(",", ","); comma.alts = new String[]{";", ":", "،"}; }
        comma.style = Key.ST_FUNC;

        Key space = new Key(Key.SPACE);
        space.weight = 3.4f;
        space.label = ku ? "کوردی" : "English";
        if (!letters) space.label = "";

        Key period = Key.chr(".", ".");
        period.style = Key.ST_FUNC;
        if (kind == FieldInfo.K_URL) period.alts = new String[]{".com", ".net", ".org", "?", "!", ","};
        else if (kind == FieldInfo.K_EMAIL) period.alts = new String[]{".com", ".net", ".org", "_", "-"};
        else period.alts = ku ? new String[]{"؟", "!", "…", "?"} : new String[]{"?", "!", ",", "…"};

        Key enter = new Key(Key.ENTER);
        enter.weight = 1.3f; enter.style = Key.ST_ACCENT;
        enter.icon = enterIcon(fi);
        return new Key[]{mode, lang, emoji, comma, space, period, enter};
    }

    public static Icon enterIcon(FieldInfo fi) {
        int a = fi == null ? 0 : fi.imeAction;
        switch (a) {
            case FieldInfo.ACT_SEARCH: return Icons.SEARCH;
            case FieldInfo.ACT_SEND: return Icons.SEND;
            case FieldInfo.ACT_DONE: return Icons.CHECK;
            case FieldInfo.ACT_GO:
            case FieldInfo.ACT_NEXT: return Icons.ARROW_RIGHT;
            case FieldInfo.ACT_PREVIOUS: return Icons.CHEV_LEFT;
            default: return Icons.ENTER;
        }
    }

    private static Layout numberPad(FieldInfo fi, boolean phone) {
        Layout l = new Layout(phone ? PHONE : NUM);
        l.units = 4f;
        l.numeric = true;
        String[] d1 = {"1", "2", "3"}, d2 = {"4", "5", "6"}, d3 = {"7", "8", "9"};
        Key[] r0 = new Key[4], r1 = new Key[4], r2 = new Key[4], r3 = new Key[4];
        for (int i = 0; i < 3; i++) {
            r0[i] = digit(d1[i], i); r1[i] = digit(d2[i], 3 + i); r2[i] = digit(d3[i], 6 + i);
        }
        r0[3] = backspace(1f);
        if (phone) {
            r1[3] = fn("-", "(", ")", "/", "N", ";", ",");
            r2[3] = fn("+", "*", "#");
            r3[0] = fn("*", "#"); r3[1] = digit("0", 9); r3[1].alts = new String[]{"+", "٠"}; r3[2] = fn("#", "*");
        } else {
            r1[3] = fn(",", ".", "-");
            r2[3] = fn(".", ",");
            r3[0] = fn("-", "+", "*", "/", ":");
            r3[1] = digit("0", 9); r3[2] = new Key(Key.SPACE); r3[2].label = ""; r3[2].style = Key.ST_FUNC;
        }
        Key en = new Key(Key.ENTER);
        en.style = Key.ST_ACCENT; en.icon = enterIcon(fi);
        r3[3] = en;
        l.addRow(1f, r0); l.addRow(1f, r1); l.addRow(1f, r2); l.addRow(1f, r3);
        return l;
    }

    private static Key digit(String d, int idx) {
        Key k = Key.chr(d, d);
        int n = d.charAt(0) - '0';
        k.alts = new String[]{String.valueOf(AR_DIGITS.charAt(n == 0 ? 9 : n - 1))};
        k.hint = "";
        return k;
    }

    private static Key fn(String t, String... alts) {
        Key k = Key.chr(t, t);
        k.style = Key.ST_FUNC;
        k.alts = alts.length == 0 ? Key.NONE : alts;
        return k;
    }
}
