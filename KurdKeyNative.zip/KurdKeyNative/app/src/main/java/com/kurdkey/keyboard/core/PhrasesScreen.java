package com.kurdkey.keyboard.core;

import java.util.ArrayList;
import java.util.List;

/** Ready-made phrases: tap to insert. */
final class PhrasesScreen extends Panel {
    private static final int B_BACK = 1;
    private final List<String> items = new ArrayList<String>();

    PhrasesScreen(Host h) {
        super(h);
        String t = h.p.asset("phrases.txt");
        if (t != null) for (String l : t.split("\n")) if (l.trim().length() > 0) items.add(l.trim());
    }

    protected float headerH() { return 46f * dp(); }
    private float rowH() { return 54f * dp(); }
    protected float contentH() { return 8f * dp() + items.size() * rowH(); }

    protected void buildButtons() { addBtn(B_BACK, 0, 0, 92 * dp(), headerH()); }

    protected void onBtn(int id) { if (id == B_BACK) h.closePanel(); }

    protected void drawChrome(Gfx g) {
        Theme t = h.theme;
        float dp = g.dp(), hh = headerH();
        g.fillRect(0, 0, W, hh, t.kbd);
        g.fillRect(0, hh - dp, W, hh, t.line);
        Ui.button(g, 8 * dp, 5 * dp, 80 * dp, hh - 10 * dp, 12 * dp, pressed != null ? t.keyDown : t.keyAlt, null, h.st.lang == KbState.KU ? "ئەب" : "ABC", t.fg, 15f * dp, true);
        g.text("دەستەواژە", W / 2f, hh / 2f, 17f * dp, t.fg, Gfx.BOLD, Gfx.CENTER);
    }

    protected void drawBody(Gfx g, float vt, float vb) {
        Theme t = h.theme;
        float dp = g.dp(), rh = rowH();
        int i0 = Math.max(0, (int) ((vt - 8 * dp) / rh)), i1 = Math.min(items.size() - 1, (int) ((vb - 8 * dp) / rh));
        for (int i = i0; i <= i1; i++) {
            float y = 8 * dp + i * rh;
            g.fillRound(10 * dp, y + 2 * dp, W - 10 * dp, y + rh - 4 * dp, 13 * dp, t.key);
            String s = Ui.fit(g, items.get(i), 16f * dp, W - 48 * dp, Gfx.NORMAL);
            boolean ar = Ui.rtl(s);
            g.text(s, ar ? W - 22 * dp : 22 * dp, y + rh / 2f - dp, 16f * dp, t.fg, Gfx.NORMAL, ar ? Gfx.RIGHT : Gfx.LEFT);
        }
    }

    protected void onTap(float x, float cy) {
        int i = (int) ((cy - 8 * dp()) / rowH());
        if (i < 0 || i >= items.size()) return;
        h.p.feedback(0);
        h.pasteText(items.get(i));
        h.closePanel();
    }
}
