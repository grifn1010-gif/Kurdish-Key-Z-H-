package com.kurdkey.keyboard.core;

/** Text-boundary helpers: what one Backspace removes, what a "word" is. */
public final class Grapheme {
    private Grapheme() {}

    public static boolean isRI(int cp) { return cp >= 0x1F1E6 && cp <= 0x1F1FF; }
    public static boolean isModifier(int cp) { return cp >= 0x1F3FB && cp <= 0x1F3FF; }
    public static boolean isTag(int cp) { return cp >= 0xE0020 && cp <= 0xE007F; }

    public static boolean isEmojiLike(int cp) {
        return (cp >= 0x1F000 && cp <= 0x1FAFF) || (cp >= 0x2190 && cp <= 0x21FF) || (cp >= 0x2300 && cp <= 0x23FF)
                || (cp >= 0x2460 && cp <= 0x24FF) || (cp >= 0x25A0 && cp <= 0x25FF) || (cp >= 0x2600 && cp <= 0x27BF)
                || (cp >= 0x2900 && cp <= 0x297F) || (cp >= 0x2B00 && cp <= 0x2BFF)
                || cp == 0xA9 || cp == 0xAE || cp == 0x203C || cp == 0x2049 || cp == 0x2122 || cp == 0x2139
                || cp == 0x3030 || cp == 0x303D || cp == 0x3297 || cp == 0x3299 || cp == 0xFE0F || isModifier(cp);
    }

    private static int prev(CharSequence s, int idx) {
        if (idx <= 0) return 0;
        char c = s.charAt(idx - 1);
        if (Character.isLowSurrogate(c) && idx - 2 >= 0 && Character.isHighSurrogate(s.charAt(idx - 2))) return idx - 2;
        return idx - 1;
    }

    private static int cpAt(CharSequence s, int i) { return Character.codePointAt(s, i); }

    /** Number of UTF-16 units a single Backspace should remove from the end of `s` (0 if empty). */
    public static int lastLen(CharSequence s) {
        int end = s.length();
        if (end == 0) return 0;
        int i = prev(s, end);
        int cp = cpAt(s, i);

        if (isRI(cp)) {
            int n = 0, j = end;
            while (j > 0) {
                int p = prev(s, j);
                if (isRI(cpAt(s, p))) { n++; j = p; } else break;
            }
            return (n % 2 == 0) ? Math.min(4, end) : Math.min(2, end);
        }
        if (isTag(cp)) {
            int j = end;
            while (j > 0) {
                int p = prev(s, j);
                int c = cpAt(s, p);
                if (isTag(c)) { j = p; } else { if (c == 0x1F3F4) j = p; break; }
            }
            return end - j;
        }
        if (cp == 0x20E3) {
            int j = i;
            int p = prev(s, j);
            if (j > 0 && cpAt(s, p) == 0xFE0F) { j = p; p = prev(s, j); }
            if (j > 0) j = p;
            return end - j;
        }
        boolean emojiTail = isEmojiLike(cp) || (cp == 0x200D && i > 0 && isEmojiLike(cpAt(s, prev(s, i))));
        if (!emojiTail) return end - i;

        int j = end;
        while (true) {
            while (j > 0) {
                int p = prev(s, j);
                int c = cpAt(s, p);
                if (c == 0xFE0F || isModifier(c)) j = p; else break;
            }
            if (j == 0) break;
            int p = prev(s, j);
            j = p;
            if (j > 0 && cpAt(s, prev(s, j)) == 0x200D) {
                int zj = prev(s, j);
                if (zj > 0 && isEmojiLike(cpAt(s, prev(s, zj)))) { j = zj; continue; }
            }
            break;
        }
        return end - j;
    }

    /** Units to remove for "delete a whole word" (trailing spaces, then a run of the same kind). */
    public static int lastWordLen(CharSequence s) {
        int end = s.length();
        int j = end;
        while (j > 0 && Character.isWhitespace(s.charAt(j - 1))) j--;
        if (j == 0) return end;
        int p = prev(s, j);
        int cp = cpAt(s, p);
        if (isWordCp(cp)) {
            while (j > 0) {
                int q = prev(s, j);
                if (isWordCp(cpAt(s, q))) j = q; else break;
            }
            return end - j;
        }
        // punctuation / emoji: remove one grapheme (plus trailing spaces already counted)
        CharSequence head = s.subSequence(0, j);
        return end - j + lastLen(head);
    }

    /** Letters, marks, digits, ZWNJ and apostrophes count as part of a word for deletion. */
    public static boolean isWordCp(int cp) {
        if (Character.isLetterOrDigit(cp)) return true;
        int t = Character.getType(cp);
        if (t == Character.NON_SPACING_MARK || t == Character.COMBINING_SPACING_MARK || t == Character.ENCLOSING_MARK) return true;
        return cp == 0x200C || cp == '\'' || cp == 0x2019;
    }

    /** Letter-like char that may be inside a suggestion word (no digits). */
    public static boolean isLetterCp(int cp) {
        if (Character.isLetter(cp)) return true;
        int t = Character.getType(cp);
        if (t == Character.NON_SPACING_MARK || t == Character.COMBINING_SPACING_MARK) return true;
        return cp == 0x200C || cp == '\'' || cp == 0x2019;
    }

    public static boolean isArabicScript(int cp) {
        return (cp >= 0x0600 && cp <= 0x06FF) || (cp >= 0x0750 && cp <= 0x077F) || (cp >= 0xFB50 && cp <= 0xFDFF) || (cp >= 0xFE70 && cp <= 0xFEFF);
    }

    public static boolean isLatinLetter(int cp) {
        return (cp >= 'A' && cp <= 'Z') || (cp >= 'a' && cp <= 'z') || (cp >= 0xC0 && cp <= 0x24F);
    }

    /** The trailing run of letters (single script) of `before`, at most 40 units; "" if none. */
    public static String trailingWord(CharSequence before) {
        int end = before.length();
        int j = end;
        int limit = Math.max(0, end - 40);
        int script = 0; // 1 latin 2 arabic 3 other
        while (j > limit) {
            int p = prev(before, j);
            int cp = cpAt(before, p);
            if (!isLetterCp(cp)) break;
            int sc = isLatinLetter(cp) ? 1 : (isArabicScript(cp) ? 2 : (cp == 0x200C || cp == '\'' || cp == 0x2019 || Character.getType(cp) == Character.NON_SPACING_MARK ? 0 : 3));
            if (sc != 0) {
                if (script == 0) script = sc;
                else if (script != sc) break;
            }
            j = p;
        }
        // do not start a word with an apostrophe or ZWNJ
        while (j < end && (before.charAt(j) == '\'' || before.charAt(j) == 0x2019 || before.charAt(j) == 0x200C)) j++;
        return before.subSequence(j, end).toString();
    }
}
