package com.kurdkey.keyboard.core;

import java.util.ArrayList;
import java.util.List;

/** Small drawing / text helpers shared by the panels. */
final class Ui {
    private Ui() {}

    static boolean rtl(String s) {
        for (int i = 0; i < s.length(); ) {
            int cp = s.codePointAt(i);
            i += Character.charCount(cp);
            if (Grapheme.isArabicScript(cp)) return true;
            if (Character.isLetter(cp)) return false;
        }
        return false;
    }

    /** Word-wrap into at most maxLines lines; the last line ends with an ellipsis when text was cut. */
    static List<String> wrap(Gfx g, String s, float size, float maxW, int maxLines) {
        List<String> out = new ArrayList<String>();
        if (s.length() > maxLines * 160) s = s.substring(0, maxLines * 160);
        String[] paras = s.split("\n", -1);
        boolean cut = false;
        outer:
        for (int pi = 0; pi < paras.length; pi++) {
            String[] words = paras[pi].split(" ", -1);
            StringBuilder cur = new StringBuilder();
            for (String w : words) {
                String trial = cur.length() == 0 ? w : cur.toString() + " " + w;
                if (g.textWidth(trial, size, Gfx.NORMAL) <= maxW) { cur.setLength(0); cur.append(trial); continue; }
                if (cur.length() > 0) {
                    out.add(cur.toString()); cur.setLength(0);
                    if (out.size() >= maxLines) { cut = true; break outer; }
                }
                String rest = w;
                while (rest.length() > 1 && g.textWidth(rest, size, Gfx.NORMAL) > maxW) {
                    int k = rest.length();
                    while (k > 1 && g.textWidth(rest.substring(0, k), size, Gfx.NORMAL) > maxW) k--;
                    if (k < rest.length() && k > 1 && Character.isHighSurrogate(rest.charAt(k - 1))) k--;
                    out.add(rest.substring(0, k));
                    rest = rest.substring(k);
                    if (out.size() >= maxLines) { cut = true; break outer; }
                }
                cur.append(rest);
            }
            out.add(cur.toString());
            if (out.size() >= maxLines) { if (pi < paras.length - 1) cut = true; break; }
        }
        if (out.size() > maxLines) { out = new ArrayList<String>(out.subList(0, maxLines)); cut = true; }
        if (cut && !out.isEmpty()) {
            int li = out.size() - 1;
            String last = out.get(li);
            while (last.length() > 1 && g.textWidth(last + "…", size, Gfx.NORMAL) > maxW) last = last.substring(0, last.length() - 1);
            out.set(li, last + "…");
        }
        return out;
    }

    static String fit(Gfx g, String s, float size, float maxW, int style) {
        if (g.textWidth(s, size, style) <= maxW) return s;
        int n = s.length();
        while (n > 1 && g.textWidth(s.substring(0, n) + "…", size, style) > maxW) n--;
        return s.substring(0, Math.max(1, n)) + "…";
    }

    /** Largest font size in [minSize, size] at which the text fits into maxW. */
    static float shrink(Gfx g, String s, float size, float minSize, float maxW, int style) {
        float sz = size;
        float step = 0.5f * g.dp();
        while (sz > minSize && g.textWidth(s, sz, style) > maxW) sz -= step;
        return Math.max(sz, minSize);
    }

    /** Draw text that is shrunk (and finally cut with an ellipsis) so that it never leaves maxW. */
    static void drawFit(Gfx g, String s, float x, float cy, float size, float minSize, float maxW, int color, int style, int align) {
        if (s == null || s.length() == 0) return;
        float sz = shrink(g, s, size, minSize, maxW, style);
        g.text(fit(g, s, sz, maxW, style), x, cy, sz, color, style, align);
    }

    /** Rounded button with an icon or a label. */
    static void button(Gfx g, float x, float y, float w, float h, float r, int bg, Icon icon, String label, int fg, float size, boolean bold) {
        g.fillRound(x, y, x + w, y + h, r, bg);
        if (icon != null) g.icon(icon, x + w / 2f, y + h / 2f, Math.min(h * 0.5f, size), fg);
        else if (label != null) drawFit(g, label, x + w / 2f, y + h / 2f, size, size * 0.7f, w - 8 * g.dp(), fg, bold ? Gfx.BOLD : Gfx.NORMAL, Gfx.CENTER);
    }
}
