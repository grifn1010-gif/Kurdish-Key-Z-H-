package com.kurdkey.keyboard.core;

import java.util.List;

/** Translates the selected text (or the whole field) between Kurdish (Sorani) and English. Needs internet. */
final class TranslateScreen extends Panel {
    private static final int B_BACK = 1, B_DIR = 2, B_REPLACE = 3, B_INSERT = 4, B_COPY = 5;
    private static final int IDLE = 0, LOADING = 1, DONE = 2, ERR = 3;

    private String src = "", result = "", err = "";
    private boolean fromSel;
    private int dir, state, token;
    private List<String> srcLines, resLines;
    private float linesW;

    TranslateScreen(Host h) { super(h); }

    protected float headerH() { return 46f * dp(); }
    protected float footerH() { return 56f * dp(); }
    protected float contentH() { return viewH(); }

    protected void onShown() {
        Editor e = h.ed;
        src = ""; result = ""; err = ""; fromSel = false; srcLines = null; resLines = null;
        if (e != null && e.valid()) {
            String s = e.selected();
            if (s != null && s.length() > 0) { src = s; fromSel = true; }
            else src = h.logic.allText();
        }
        src = src.trim();
        if (src.length() > 3000) src = src.substring(0, 3000);
        String d = h.cfg.translateDir;
        dir = "ku-en".equals(d) ? 1 : ("en-ku".equals(d) ? 2 : 0);
        if (src.length() > 0) run(); else state = IDLE;
    }

    private void run() {
        String from, to;
        if (dir == 1) { from = "ckb"; to = "en"; }
        else if (dir == 2) { from = "en"; to = "ckb"; }
        else if (Ui.rtl(src)) { from = "ckb"; to = "en"; }
        else { from = "en"; to = "ckb"; }
        state = LOADING;
        resLines = null;
        final int my = ++token;
        h.p.translate(src, from, to, new Platform.TranslateCb() {
            public void done(String r, String e) {
                if (my != token) return;
                if (e != null || r == null || r.length() == 0) { state = ERR; err = e == null ? "" : e; }
                else { state = DONE; result = r; }
                resLines = null;
                h.p.invalidate();
            }
        });
        h.p.invalidate();
    }

    protected void buildButtons() {
        float dp = dp(), hh = headerH(), fh = footerH();
        addBtn(B_BACK, 0, 0, 92 * dp, hh);
        addBtn(B_DIR, W - 150 * dp, 0, 150 * dp, hh);
        float bw = (W - 16 * dp - 12 * dp) / 3f, by = H - fh;
        addBtn(B_REPLACE, 8 * dp, by, bw, fh);
        addBtn(B_INSERT, 8 * dp + bw + 6 * dp, by, bw, fh);
        addBtn(B_COPY, 8 * dp + 2 * (bw + 6 * dp), by, bw, fh);
    }

    protected void onBtn(int id) {
        if (id == B_BACK) { h.closePanel(); return; }
        if (id == B_DIR) {
            dir = (dir + 1) % 3;
            h.setPref("translateDir", dir == 1 ? "ku-en" : (dir == 2 ? "en-ku" : "auto"));
            if (src.length() > 0) run();
            return;
        }
        if (state != DONE) return;
        if (id == B_REPLACE) {
            if (h.ed != null && h.ed.valid()) {
                if (fromSel) h.ed.commit(result); else h.ed.setAll(result);
                h.logic.resync();
                h.refreshSuggestions();
            }
            h.closePanel();
        } else if (id == B_INSERT) {
            h.pasteText(result);
            h.closePanel();
        } else if (id == B_COPY) {
            h.p.setClipboardText(result);
            h.clips.add(result);
            h.p.toast("کۆپی کرا");
        }
    }

    private boolean isPressed(int id) { return pressed != null && pressed.id == id; }

    protected void drawChrome(Gfx g) {
        Theme t = h.theme;
        float dp = g.dp(), hh = headerH(), fh = footerH();
        g.fillRect(0, 0, W, hh, t.kbd);
        g.fillRect(0, hh - dp, W, hh, t.line);
        Ui.button(g, 8 * dp, 5 * dp, 80 * dp, hh - 10 * dp, 12 * dp, isPressed(B_BACK) ? t.keyDown : t.keyAlt, null, h.st.lang == KbState.KU ? "ئەب" : "ABC", t.fg, 15f * dp, true);
        String dl = dir == 1 ? "کوردی بۆ ئینگلیزی" : (dir == 2 ? "ئینگلیزی بۆ کوردی" : "ئاراستە: خۆکار");
        Ui.button(g, W - 146 * dp, 7 * dp, 138 * dp, hh - 14 * dp, 12 * dp, isPressed(B_DIR) ? t.keyDown : Theme.withAlpha(t.accent, 56), null, dl, t.fg, 12.5f * dp, true);
        g.text("وەرگێڕان", W / 2f - 20 * dp, hh / 2f, 16f * dp, t.fg, Gfx.BOLD, Gfx.CENTER);
        boolean ok = state == DONE;
        float bw = (W - 16 * dp - 12 * dp) / 3f, by = H - fh + 6 * dp, bh = fh - 12 * dp;
        String[] names = {"جێگرتنەوە", "دانان", "کۆپی"};
        for (int i = 0; i < 3; i++) {
            float x = 8 * dp + i * (bw + 6 * dp);
            int id = B_REPLACE + i;
            int bg = i == 0 ? (ok ? t.accent : t.keyAlt) : t.keyAlt;
            if (isPressed(id) && ok) bg = Theme.mix(bg, 0xFF000000, 0.2f);
            int fg = i == 0 && ok ? t.accentFg : (ok ? t.fg : t.muted);
            Ui.button(g, x, by, bw, bh, 13 * dp, bg, null, names[i], fg, 15f * dp, true);
        }
    }

    private void card(Gfx g, float y, float hgt, String label, List<String> lines, int fg) {
        Theme t = h.theme;
        float dp = g.dp();
        g.fillRound(10 * dp, y, W - 10 * dp, y + hgt, 14 * dp, t.key);
        g.text(label, W - 22 * dp, y + 14 * dp, 11f * dp, t.muted, Gfx.BOLD, Gfx.RIGHT);
        float lh = 21f * dp, ty = y + 34 * dp;
        for (String s : lines) {
            boolean ar = Ui.rtl(s);
            g.text(s, ar ? W - 22 * dp : 22 * dp, ty, 16f * dp, fg, Gfx.NORMAL, ar ? Gfx.RIGHT : Gfx.LEFT);
            ty += lh;
        }
    }

    protected void drawBody(Gfx g, float vt, float vb) {
        Theme t = h.theme;
        float dp = g.dp();
        float vh = viewH();
        float w = W - 44 * dp;
        if (linesW != w) { srcLines = null; resLines = null; linesW = w; }
        if (src.length() == 0) {
            g.text("هیچ دەقێک نییە", W / 2f, vh * 0.40f, 17f * dp, t.fg, Gfx.BOLD, Gfx.CENTER);
            g.text("سەرەتا شتێک بنووسە یان دەقێک هەڵبژێرە", W / 2f, vh * 0.40f + 26 * dp, 13f * dp, t.muted, Gfx.NORMAL, Gfx.CENTER);
            return;
        }
        float h1 = Math.min(vh * 0.38f, 92 * dp), gap = 8 * dp;
        float h2 = vh - h1 - gap * 3;
        int l1 = Math.max(1, (int) ((h1 - 40 * dp) / (21 * dp)));
        int l2 = Math.max(1, (int) ((h2 - 40 * dp) / (21 * dp)));
        if (srcLines == null) srcLines = Ui.wrap(g, src.replace('\n', ' '), 16f * dp, w, l1);
        card(g, gap, h1, fromSel ? "دەقی هەڵبژێردراو" : "دەقی خانەکە", srcLines, t.muted);
        float y2 = gap * 2 + h1;
        if (state == DONE) {
            if (resLines == null) resLines = Ui.wrap(g, result, 16f * dp, w, l2);
            card(g, y2, h2, "وەرگێڕان", resLines, t.fg);
        } else {
            g.fillRound(10 * dp, y2, W - 10 * dp, y2 + h2, 14 * dp, t.key);
            String msg = state == LOADING ? "وەردەگێڕێت…" : (state == ERR ? "وەرگێڕان سەرکەوتوو نەبوو. ئینتەرنێتەکەت بپشکنە، دواتر لێرە دابگرە بۆ دووبارە هەوڵدان." : "");
            if (state == ERR && Ui.rtl(msg)) {
                List<String> ls = Ui.wrap(g, msg, 14f * dp, w, 3);
                for (int i = 0; i < ls.size(); i++) g.text(ls.get(i), W / 2f, y2 + h2 / 2f + (i - (ls.size() - 1) / 2f) * 21 * dp, 14f * dp, t.muted, Gfx.NORMAL, Gfx.CENTER);
            } else g.text(msg, W / 2f, y2 + h2 / 2f, 15f * dp, t.muted, Gfx.NORMAL, Gfx.CENTER);
        }
    }

    protected void onTap(float x, float cy) {
        if (state == ERR && src.length() > 0) { h.p.feedback(4); run(); }
    }

    @Override public void onHide() {
        super.onHide();
        token++;
    }
}
