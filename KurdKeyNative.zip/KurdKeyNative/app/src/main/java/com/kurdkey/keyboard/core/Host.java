package com.kurdkey.keyboard.core;

import java.util.AbstractSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Central controller: owns all state, the keyboard screen and the panels; it is the root Screen drawn by the Android view. */
public final class Host implements Screen {
    public static final int T_EMOJI = 1, T_CLIP = 2, T_TRANSLATE = 3, T_COPY = 4, T_PASTE = 5, T_SELALL = 6, T_MORE = 7, T_CUT = 8,
            T_FIX = 9, T_PHRASES = 10, T_QUICK = 11, T_SETTINGS = 12, T_HIDE = 13, T_HAND = 14, T_KUDIG = 15;
    public static final int[] TOOLBAR = {T_EMOJI, T_CLIP, T_TRANSLATE, T_COPY, T_PASTE, T_SELALL, T_MORE};
    public static final int[] ALL_TOOLS = {T_EMOJI, T_CLIP, T_TRANSLATE, T_FIX, T_PHRASES, T_COPY, T_CUT, T_PASTE, T_SELALL, T_HAND, T_KUDIG, T_QUICK, T_SETTINGS, T_HIDE};

    public static Icon toolIcon(int t) {
        switch (t) {
            case T_EMOJI: return Icons.SMILE;
            case T_CLIP: return Icons.CLIPBOARD;
            case T_TRANSLATE: return Icons.TRANSLATE;
            case T_COPY: return Icons.COPY;
            case T_PASTE: return Icons.PASTE;
            case T_SELALL: return Icons.SELECT_ALL;
            case T_MORE: return Icons.MORE;
            case T_CUT: return Icons.CUT;
            case T_FIX: return Icons.FIX;
            case T_PHRASES: return Icons.PHRASE;
            case T_QUICK: return Icons.TEXT;
            case T_SETTINGS: return Icons.GEAR;
            case T_HIDE: return Icons.HIDE_KB;
            case T_HAND: return Icons.HAND_RIGHT;
            case T_KUDIG: return Icons.NUMBERS;
            default: return Icons.MORE;
        }
    }

    public static String toolName(int t) {
        switch (t) {
            case T_EMOJI: return "ئیمۆجی";
            case T_CLIP: return "کلیپبۆرد";
            case T_TRANSLATE: return "وەرگێڕان";
            case T_COPY: return "کۆپی";
            case T_PASTE: return "پەیست";
            case T_SELALL: return "هەموو";
            case T_MORE: return "زیاتر";
            case T_CUT: return "بڕین";
            case T_FIX: return "لاتینی بۆ کوردی";
            case T_PHRASES: return "دەستەواژە";
            case T_QUICK: return "ڕێکخستنی خێرا";
            case T_SETTINGS: return "ڕێکخستنەکان";
            case T_HIDE: return "شاردنەوە";
            case T_HAND: return "یەک دەست";
            case T_KUDIG: return "ژمارەی کوردی";
            default: return "";
        }
    }

    public final Platform p;
    public final Prefs prefs;
    public final float density;
    public final EmojiData.Glyphs glyphs;
    public Cfg cfg;
    public Theme theme;
    public final KbState st = new KbState();
    public FieldInfo field;
    public Editor ed;
    public final EmojiData emoji;
    public final Dict ku, en;
    public final Learner learner;
    public final Suggest engine;
    public final ClipStore clips;
    public final InputLogic logic;
    public final KeyboardScreen kb;
    public Suggest.Result sug = new Suggest.Result();
    public boolean shiftHeld;
    public final List<String> recents = new ArrayList<String>();
    public final StringBuilder query = new StringBuilder();
    public boolean searchMode;

    private final SearchBar sb;
    private Screen panel;
    private EmojiScreen emojiScreen;
    private float W, H;
    private long lastShiftTap;
    private boolean recentsDirty;
    private Object flushToken;
    private Gfx lastGfx;
    private final int[] owner = new int[32];

    public Host(Platform p, Prefs prefs, float density, EmojiData.Glyphs glyphs) { this(p, prefs, density, glyphs, false); }

    /** lite = no big dictionaries (used by the settings app, which only needs preferences and data files). */
    public Host(Platform p, Prefs prefs, float density, EmojiData.Glyphs glyphs, boolean lite) {
        this.p = p; this.prefs = prefs; this.density = density; this.glyphs = glyphs;
        cfg = Cfg.load(prefs);
        theme = Theme.of(cfg.theme, p.systemDark(), cfg.accent);
        emoji = EmojiData.load(p);
        ku = new Dict(lite ? null : p.asset("dict_ku.txt"));
        en = new Dict(lite ? null : p.asset("dict_en.txt"));
        learner = Learner.parse(p.readFile("learn.txt"));
        engine = new Suggest(ku, en, learner, emoji, glyphs, p.asset("next_en.txt"));
        clips = new ClipStore(p);
        clips.maxItems = cfg.clipMax;
        String r = p.readFile("recent_emoji.txt");
        if (r != null) for (String s : r.split("\n")) if (s.length() > 0 && recents.size() < 48) recents.add(s);
        logic = new InputLogic(this);
        kb = new KeyboardScreen(this);
        sb = new SearchBar(this);
        st.lang = startLang();
        st.toolbar = cfg.toolbarOpen;
    }

    public float dp() { return density; }
    public float width() { return W; }

    float chipWidth(String s, float size) {
        return (lastGfx != null ? lastGfx.textWidth(s, size, Gfx.NORMAL) : s.length() * size * 0.6f) + 22f * density;
    }

    private int startLang() {
        if ("en".equals(cfg.startLang)) return KbState.EN;
        if ("last".equals(cfg.startLang)) return "en".equals(cfg.lastLang) ? KbState.EN : KbState.KU;
        return KbState.KU;
    }

    // ------------------------------------------------------------------ lifecycle (called by the Android service)

    public void onStartInput(FieldInfo fi, Editor e, int selS, int selE, boolean restarting) {
        field = fi; ed = e;
        kb.cancelAll();
        if (searchMode) { searchMode = false; kb.stripVisible = true; query.setLength(0); }
        closePanelQuiet();
        st.layer = "l";
        st.shift = 0; st.shiftAuto = false;
        shiftHeld = false;
        if (!restarting) st.lang = startLang();
        int kind = fi == null ? FieldInfo.K_TEXT : fi.kind;
        if (!restarting && (kind == FieldInfo.K_PASSWORD || kind == FieldInfo.K_EMAIL || kind == FieldInfo.K_URL)) st.lang = KbState.EN;
        logic.reset(selS, selE);
        kb.invalidateLayout();
        maybeAutoCap();
        refreshSuggestions();
        p.requestResize();
        p.invalidate();
    }

    public void onFinishInput() {
        kb.cancelAll();
        flush();
        ed = null;
    }

    public void onSelection(int newS, int newE) {
        if (searchMode || ed == null) return;
        if (logic.onSelection(newS, newE)) {
            maybeAutoCap();
            refreshSuggestions();
        }
    }

    public void onClipboardChanged(String text) {
        if (!cfg.clipHistory) return;
        if (text == null || text.length() == 0) return;
        if (clips.add(text) != null && panel instanceof ClipScreen) { panel.layout(W, H); p.invalidate(); }
    }

    /** Settings changed (from the settings screen or the quick panel). */
    public void reloadPrefs() {
        cfg = Cfg.load(prefs);
        theme = Theme.of(cfg.theme, p.systemDark(), cfg.accent);
        clips.maxItems = cfg.clipMax;
        kb.invalidateLayout();
        refreshSuggestions();
        p.requestResize();
        p.invalidate();
    }

    public void onThemeChanged() {
        theme = Theme.of(cfg.theme, p.systemDark(), cfg.accent);
        p.invalidate();
    }

    public void onConfigurationChanged() {
        kb.invalidateLayout();
        if (panel != null) panel.layout(W, normalH(W));
        p.requestResize();
        p.invalidate();
    }

    /** The clip list changed (edited in the clip editor or settings). */
    public void clipsChanged() {
        if (panel instanceof ClipScreen) { panel.layout(W, normalH(W)); p.invalidate(); }
    }

    public void clearLearnedNow() { learner.clearLearned(); learner.dirty = false; p.writeFile("learn.txt", learner.serialize()); refreshSuggestions(); }

    public void unbanAllNow() { learner.unbanAll(); learner.dirty = false; p.writeFile("learn.txt", learner.serialize()); refreshSuggestions(); }

    public void flush() {
        if (learner.dirty) { learner.dirty = false; p.writeFile("learn.txt", learner.serialize()); }
        if (recentsDirty) { recentsDirty = false; StringBuilder b = new StringBuilder(); for (String s : recents) b.append(s).append('\n'); p.writeFile("recent_emoji.txt", b.toString()); }
        clips.flush();
    }

    private void scheduleFlush() {
        if (flushToken != null) return;
        flushToken = p.post(new Runnable() { public void run() { flushToken = null; flush(); } }, 30000);
    }

    // ------------------------------------------------------------------ preferences

    public void setPref(String key, Object v) {
        if (v instanceof Boolean) prefs.putBool(key, (Boolean) v);
        else if (v instanceof Integer) prefs.putInt(key, (Integer) v);
        else prefs.putString(key, String.valueOf(v));
        reloadPrefs();
        if (panel != null) { panel.layout(W, normalH(W)); }
    }

    public boolean canLearn() { return field != null && !field.noSuggest; }

    // ------------------------------------------------------------------ labels

    public String keyLabel(Key k) {
        String s = k.label;
        if (k.type == Key.CHAR && k.letter && st.shift > 0 && st.lang == KbState.EN) {
            String u = s.toUpperCase(Locale.ROOT);
            if (u.length() == s.length()) return u;
        }
        return s;
    }

    public String hintLabel(Key k) { return upperIf(k, k.hint); }

    public String altLabel(Key k, String alt) { return upperIf(k, alt); }

    private String upperIf(Key k, String s) {
        if (k.letter && st.shift > 0 && st.lang == KbState.EN && s.length() > 0 && Character.isLetter(s.codePointAt(0))) {
            String u = s.toUpperCase(Locale.ROOT);
            if (u.length() == s.length()) return u;
        }
        return s;
    }

    // ------------------------------------------------------------------ typing actions

    public void typeKey(Key k, String alt) {
        String t = alt != null ? alt : k.text;
        if (k.letter) t = upperIf(k, t);
        lastShiftTap = 0;
        if (searchMode) { searchAppend(t); afterTypeShift(); return; }
        logic.type(t);
        afterTypeShift();
        int cp = t.length() > 0 ? t.codePointAt(0) : 0;
        if (!(t.length() == Character.charCount(cp) && Character.isLetter(cp))) maybeAutoCap();
        refreshSuggestions();
        scheduleFlush();
    }

    private void afterTypeShift() {
        if (st.shift == 1 && !shiftHeld) { st.shift = 0; st.shiftAuto = false; }
    }

    public void backspace(boolean word) {
        lastShiftTap = 0;
        if (searchMode) { searchBackspace(word); return; }
        logic.backspace(word);
        maybeAutoCap();
        refreshSuggestions();
    }

    public void space() {
        lastShiftTap = 0;
        if (searchMode) { searchAppend(" "); return; }
        logic.space();
        afterTypeShift();
        maybeAutoCap();
        refreshSuggestions();
    }

    public void enter() {
        if (searchMode) { closeSearch(true); return; }
        logic.enter();
        maybeAutoCap();
        refreshSuggestions();
    }

    public void shiftDown() {
        long now = p.now();
        boolean quick = lastShiftTap > 0 && now - lastShiftTap < 300;
        int prev = st.shift;
        if (prev == 0) st.shift = quick ? 2 : 1;
        else if (prev == 1) st.shift = (quick && !st.shiftAuto) ? 2 : 0;
        else st.shift = 0;
        st.shiftAuto = false;
        lastShiftTap = (prev == 2 || st.shift == 2) ? 0 : now;
        p.invalidate();
    }

    public void shiftUp(boolean used) {
        if (used && st.shift == 1) { st.shift = 0; st.shiftAuto = false; }
        p.invalidate();
    }

    public void toggleMode() {
        st.layer = st.layer.equals("l") ? "s1" : "l";
        st.shift = 0; st.shiftAuto = false;
        kb.invalidateLayout();
        if (st.layer.equals("l")) maybeAutoCap();
        p.invalidate();
    }

    public void toggleSym2() {
        st.layer = st.layer.equals("s1") ? "s2" : "s1";
        kb.invalidateLayout();
        p.invalidate();
    }

    public void toggleLang() {
        st.lang = st.lang == KbState.KU ? KbState.EN : KbState.KU;
        st.layer = "l"; st.shift = 0; st.shiftAuto = false;
        cfg.lastLang = st.lang == KbState.KU ? "ku" : "en";
        prefs.putString("lastLang", cfg.lastLang);
        kb.invalidateLayout();
        maybeAutoCap();
        refreshSuggestions();
        p.invalidate();
    }

    public void showPicker() { p.showImePicker(); }

    public void moveCursor(int dir) { logic.moveCursor(dir); }

    public void setHand(int v) { setPref("hand", v); }

    public void toggleToolbar() {
        st.toolbar = !st.toolbar;
        cfg.toolbarOpen = st.toolbar;
        prefs.putBool("toolbarOpen", st.toolbar);
        kb.rebuildStrip();
        p.invalidate();
    }

    public void maybeAutoCap() {
        if (!cfg.autoCap || st.lang != KbState.EN || !st.layer.equals("l") || st.shift == 2 || field == null || ed == null) return;
        if ((field.inputType & 0x7000) == 0 || field.noSuggest && field.kind != FieldInfo.K_TEXT) {
            if (st.shift == 1 && st.shiftAuto) { st.shift = 0; st.shiftAuto = false; }
            return;
        }
        boolean want = ed.capsMode(field.inputType) != 0;
        if (want && st.shift == 0) { st.shift = 1; st.shiftAuto = true; }
        else if (!want && st.shift == 1 && st.shiftAuto) { st.shift = 0; st.shiftAuto = false; }
    }

    // ------------------------------------------------------------------ suggestions

    public void refreshSuggestions() {
        String w = logic.word;
        boolean kurdish = w.length() > 0 ? Grapheme.isArabicScript(w.codePointAt(0)) : st.lang == KbState.KU;
        if (field != null && field.noSuggest) sug = new Suggest.Result();
        else {
            try { sug = engine.compute(kurdish, w, logic.prev, cfg); }
            catch (RuntimeException e) { p.log("suggest", e); sug = new Suggest.Result(); }
        }
        kb.rebuildStrip();
        p.invalidate();
    }

    public void acceptSuggestion(int idx) {
        String s = sug.slot[idx];
        if (s == null || s.length() == 0) return;
        logic.replaceWord(s, true);
        afterTypeShift();
        maybeAutoCap();
        refreshSuggestions();
    }

    public void banSuggestion(int idx) {
        String s = sug.slot[idx];
        if (s == null || s.length() == 0 || idx == sug.trSlot) return;
        learner.ban(s);
        p.feedback(4);
        p.toast("وشەکە لابرا");
        refreshSuggestions();
    }

    public void acceptEmojiSuggestion(int idx) {
        if (idx < 0 || idx >= sug.emoji.length) return;
        commitEmoji(sug.emoji[idx]);
    }

    public void commitEmoji(String e) {
        String out = EmojiData.withTone(e, cfg.tone);
        if (!ensureEditor()) return;
        logic.insert(out);
        addRecent(out);
        if (!searchMode) refreshSuggestions();
    }

    private boolean ensureEditor() { return ed != null && ed.valid(); }

    public void addRecent(String e) {
        recents.remove(e);
        recents.add(0, e);
        while (recents.size() > 48) recents.remove(recents.size() - 1);
        recentsDirty = true;
        scheduleFlush();
    }

    // ------------------------------------------------------------------ tools

    public void runTool(int id) {
        switch (id) {
            case T_EMOJI: openEmoji(); return;
            case T_CLIP: openPanel(new ClipScreen(this)); return;
            case T_TRANSLATE: openPanel(new TranslateScreen(this)); return;
            case T_PHRASES: openPanel(new PhrasesScreen(this)); return;
            case T_QUICK: openPanel(new QuickScreen(this)); return;
            case T_MORE: openPanel(new ToolsScreen(this)); return;
            default: break;
        }
        closePanel();
        switch (id) {
            case T_COPY: copyText(false); break;
            case T_CUT: copyText(true); break;
            case T_PASTE: pasteClip(); break;
            case T_SELALL: if (ensureEditor()) ed.selectAll(); break;
            case T_FIX: fixLatin(); break;
            case T_SETTINGS: p.openSettings(); break;
            case T_HIDE: p.hideKeyboard(); break;
            case T_HAND: setHand(cfg.hand == 0 ? 1 : (cfg.hand == 1 ? 2 : 0)); break;
            case T_KUDIG: setPref("kuDigits", !cfg.kuDigits); p.toast(cfg.kuDigits ? "ژمارەی کوردی چالاک بوو" : "ژمارەی ئینگلیزی چالاک بوو"); break;
            default: break;
        }
    }

    private void copyText(boolean cut) {
        if (!ensureEditor()) return;
        String sel = ed.selected();
        if (sel == null || sel.length() == 0) {
            if (cfg.copyAll) {
                String all = logic.allText();
                if (all.length() == 0) { p.toast("هیچ دەقێک نییە"); return; }
                p.setClipboardText(all);
                clips.add(all);
                p.toast("هەموو دەقەکە کۆپی کرا");
                if (cut) ed.setAll("");
            } else p.toast("سەرەتا دەقێک هەڵبژێرە");
            return;
        }
        p.setClipboardText(sel);
        clips.add(sel);
        p.toast("کۆپی کرا");
        if (cut) ed.commit("");
    }

    public void pasteClip() {
        if (!ensureEditor()) return;
        String t = p.clipboardText();
        if (t == null || t.length() == 0) { p.toast("کلیپبۆرد بەتاڵە"); return; }
        logic.insert(t);
        refreshSuggestions();
    }

    public void pasteText(String t) {
        if (!ensureEditor() || t == null || t.length() == 0) return;
        logic.insert(t);
        refreshSuggestions();
    }

    private Set<String> keepEnglish() {
        return new AbstractSet<String>() {
            public boolean contains(Object o) { return o instanceof String && en.isCommon((String) o); }
            public Iterator<String> iterator() { return Collections.<String>emptyList().iterator(); }
            public int size() { return 0; }
        };
    }

    private void fixLatin() {
        if (!ensureEditor()) return;
        String sel = ed.selected();
        boolean all = sel == null || sel.length() == 0;
        String src = all ? logic.allText() : sel;
        if (src.length() == 0) { p.toast("هیچ دەقێک نییە"); return; }
        String out = Translit.convText(src, keepEnglish());
        if (out.equals(src)) { p.toast("هیچ شتێک نەگۆڕدرا"); return; }
        if (all) ed.setAll(out); else ed.commit(out);
        logic.resync();
        refreshSuggestions();
        p.toast("گۆڕدرا");
    }

    // ------------------------------------------------------------------ panels

    private float normalH(float w) {
        boolean sv = kb.stripVisible;
        kb.stripVisible = true;
        float v = kb.desiredHeight(w);
        kb.stripVisible = sv;
        return v;
    }

    public float panelHeight() { return normalH(W > 0 ? W : 360f * density); }

    public void openEmoji() {
        if (emojiScreen == null) emojiScreen = new EmojiScreen(this);
        openPanel(emojiScreen);
    }

    public void openPanel(Screen s) {
        if (searchMode) { searchMode = false; kb.stripVisible = true; query.setLength(0); kb.invalidateLayout(); }
        if (panel != null) panel.onHide();
        kb.cancelAll();
        panel = s;
        s.layout(W, normalH(W));
        s.onShow();
        p.requestResize();
        p.invalidate();
    }

    private void closePanelQuiet() {
        if (panel != null) { panel.onHide(); panel = null; }
    }

    public void closePanel() {
        if (panel != null) { panel.onHide(); panel = null; }
        kb.invalidateLayout();
        kb.layout(W, searchMode ? H - sb.height() : H);
        p.requestResize();
        p.invalidate();
    }

    public boolean panelOpen() { return panel != null; }

    public boolean back() {
        if (searchMode) { closeSearch(false); return true; }
        if (panel != null) { closePanel(); return true; }
        return false;
    }

    // ------------------------------------------------------------------ emoji search

    public void openSearch() {
        closePanelQuiet();
        searchMode = true;
        query.setLength(0);
        sb.update("");
        st.layer = "l";
        kb.stripVisible = false;
        kb.invalidateLayout();
        p.requestResize();
        p.invalidate();
    }

    public void closeSearch(boolean toEmoji) {
        if (!searchMode) return;
        searchMode = false;
        query.setLength(0);
        kb.stripVisible = true;
        kb.invalidateLayout();
        if (toEmoji) openEmoji();
        else { kb.layout(W, H); p.requestResize(); p.invalidate(); }
    }

    void searchAppend(String t) { query.append(t); sb.update(query.toString()); p.invalidate(); }

    void searchBackspace(boolean word) {
        if (query.length() == 0) return;
        int n = word ? Grapheme.lastWordLen(query) : Grapheme.lastLen(query);
        query.setLength(Math.max(0, query.length() - Math.max(1, n)));
        sb.update(query.toString());
        p.invalidate();
    }

    void searchClear() { query.setLength(0); sb.update(""); p.invalidate(); }

    void searchSet(String q) { query.setLength(0); query.append(q); sb.update(q); p.invalidate(); }

    // ------------------------------------------------------------------ Screen (root)

    public float desiredHeight(float w) {
        if (panel != null) return normalH(w);
        if (searchMode) return normalH(w) - kb.fullStripH() + sb.height();
        return kb.desiredHeight(w);
    }

    public void layout(float w, float hh) {
        W = w; H = hh;
        kb.layout(w, searchMode ? Math.max(1f, hh - sb.height()) : hh);
        if (panel != null) panel.layout(w, hh);
    }

    public void draw(Gfx g) {
        lastGfx = g;
        if (panel != null) { panel.draw(g); return; }
        if (searchMode) {
            g.fillRect(0, 0, W, H, theme.kbd);
            sb.draw(g, W);
            g.save();
            g.translate(0, sb.height());
            kb.draw(g);
            g.restore();
            return;
        }
        kb.draw(g);
    }

    public boolean touch(int action, int id, float x, float y) {
        int slot = id & 31;
        if (action == DOWN) owner[slot] = panel != null ? 2 : (searchMode && y < sb.height() ? 3 : 1);
        switch (owner[slot]) {
            case 2: if (panel != null) panel.touch(action, id, x, y); break;
            case 3: sb.touch(action, id, x, y); break;
            case 1: kb.touch(action, id, x, y - (searchMode ? sb.height() : 0f)); break;
            default: break;
        }
        if (action == UP || action == CANCEL) owner[slot] = 0;
        return true;
    }

    public boolean animating() { return panel != null && panel.animating(); }

    public void tick(long nowMs) { if (panel != null) panel.tick(nowMs); }

    public void onShow() { kb.onShow(); }

    public void onHide() { kb.onHide(); if (panel != null) panel.onHide(); flush(); }
}
