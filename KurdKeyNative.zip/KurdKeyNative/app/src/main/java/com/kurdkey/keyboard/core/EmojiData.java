package com.kurdkey.keyboard.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Emoji groups, names, keyword search and word->emoji suggestions (port of the web keyboard search). */
public final class EmojiData {
    public interface Glyphs { boolean has(String s); }

    public static final String TONE_SLOT = "\uE000";
    public static final String[] TONES = {"🏻", "🏼", "🏽", "🏾", "🏿"};

    public final List<List<String>> groups = new ArrayList<List<String>>();
    private final List<List<String>> names = new ArrayList<List<String>>();
    public String[] tabs = new String[0];
    public String[] groupNames = new String[0];
    public String[] chips = new String[0];

    private final Map<String, String> ali = new HashMap<String, String>();
    private final Map<String, List<String>> kwi = new HashMap<String, List<String>>();
    private final Set<String> stop = new HashSet<String>();
    private final Map<String, String[]> efCache = new HashMap<String, String[]>();
    private final Map<Integer, List<String>> listCache = new HashMap<Integer, List<String>>();

    private static final class Item { String e; String[] w; int n; }
    private List<Item> sidx;

    public static EmojiData load(Platform p) {
        EmojiData d = new EmojiData();
        String emoji = p.asset("emoji.txt");
        if (emoji != null) {
            for (String line : emoji.split("\n")) {
                String[] t = line.split("\t", 3);
                if (t.length < 2) continue;
                int g;
                try { g = Integer.parseInt(t[0]); } catch (NumberFormatException e) { continue; }
                while (d.groups.size() <= g) { d.groups.add(new ArrayList<String>()); d.names.add(new ArrayList<String>()); }
                d.groups.get(g).add(t[1]);
                d.names.get(g).add(t.length > 2 ? t[2] : "");
            }
        }
        String kw = p.asset("emoji_kw.txt");
        if (kw != null) for (String line : kw.split("\n")) {
            String[] t = line.split("\t");
            if (t.length < 2) continue;
            List<String> l = java.util.Arrays.asList(t[1].trim().split(" "));
            for (String k : t[0].trim().split(" ")) {
                if (k.length() == 0) continue;
                List<String> cur = d.kwi.get(k);
                if (cur == null) { cur = new ArrayList<String>(); d.kwi.put(k, cur); }
                cur.addAll(l);
            }
        }
        String al = p.asset("emoji_ali.txt");
        if (al != null) for (String line : al.split("\n")) {
            String[] t = line.split("\t");
            if (t.length >= 2 && t[0].length() > 0 && t[1].length() > 0) d.ali.put(t[0], t[1]);
        }
        String meta = p.asset("emoji_meta.txt");
        if (meta != null) for (String line : meta.split("\n")) {
            String[] t = line.split("\t", 2);
            if (t.length < 2) continue;
            if (t[0].equals("tabs")) d.tabs = t[1].trim().split(" ");
            else if (t[0].equals("names")) d.groupNames = t[1].trim().split("\\|");
            else if (t[0].equals("chips")) d.chips = t[1].trim().split(" ");
            else if (t[0].equals("stop")) Collections.addAll(d.stop, t[1].trim().split(" "));
        }
        return d;
    }

    public static boolean hasTone(String e) { return e.indexOf('\uE000') >= 0; }

    public static String base(String e) {
        return e.replaceAll("([\\u261d\\u26f9\\u270c\\u270d\\x{1f3cb}\\x{1f3cc}\\x{1f574}\\x{1f575}\\x{1f590}])\\uE000", "$1️").replace("\uE000", "");
    }

    public static String withTone(String e, int tone) {
        if (tone >= 1 && tone <= 5 && hasTone(e)) return e.replace("\uE000", TONES[tone - 1]);
        return base(e);
    }

    /** Emoji of a group that the device can draw (cached). */
    public List<String> list(int group, Glyphs g) {
        List<String> c = listCache.get(group);
        if (c != null) return c;
        List<String> out = new ArrayList<String>();
        if (group >= 0 && group < groups.size()) {
            for (String e : groups.get(group)) if (g == null || g.has(base(e))) out.add(e);
        }
        listCache.put(group, out);
        return out;
    }

    private void buildIdx() {
        if (sidx != null) return;
        sidx = new ArrayList<Item>();
        for (int gi = 0; gi < groups.size(); gi++) {
            List<String> arr = groups.get(gi), nm = names.get(gi);
            for (int i = 0; i < arr.size(); i++) {
                Item it = new Item();
                it.e = arr.get(i);
                String t = i < nm.size() ? nm.get(i) : "";
                it.w = t.split(" ");
                it.n = it.w.length;
                sidx.add(it);
            }
        }
    }

    private static String stem(String s) { return s.length() > 4 ? s.replaceAll("(ing|ed|es|s|y)$", "") : s; }

    public List<String> search(String q, int lim, boolean strict, Glyphs g) {
        buildIdx();
        List<String> toks = new ArrayList<String>();
        for (String t : q.toLowerCase(Locale.ROOT).trim().split("\\s+")) if (t.length() > 0) toks.add(t);
        List<String> out = new ArrayList<String>();
        if (toks.isEmpty()) return out;
        List<List<String[]>> alts = new ArrayList<List<String[]>>();
        for (String t : toks) {
            List<String[]> l = new ArrayList<String[]>();
            String a = ali.get(t);
            if (a == null) l.add(new String[]{t});
            else for (String p : a.split("\\|")) l.add(p.split(" "));
            alts.add(l);
        }
        List<double[]> res = new ArrayList<double[]>();
        List<String> kwl = toks.size() == 1 ? kwi.get(toks.get(0)) : null;
        for (int k = 0; k < sidx.size(); k++) {
            Item it = sidx.get(k);
            double total = 0;
            boolean ok = true;
            for (int a = 0; a < alts.size() && ok; a++) {
                double best = 0;
                List<String[]> alt = alts.get(a);
                for (int p = 0; p < alt.size(); p++) {
                    String[] ph = alt.get(p);
                    double sc = 99;
                    for (int x = 0; x < ph.length; x++) {
                        String tk = ph[x];
                        int b = 0;
                        if (!(strict && tk.length() < 3 && !ali.containsKey(tk) && !kwi.containsKey(tk))) {
                            for (int y = 0; y < it.w.length; y++) {
                                String w = it.w[y];
                                if (w.equals(tk)) { b = 3; break; }
                                if (!strict && (stem(w).equals(stem(tk)) || (tk.length() >= 2 && w.startsWith(tk)))) b = Math.max(b, 2);
                                else if (!strict && tk.length() >= 3 && w.indexOf(tk) > 0) b = Math.max(b, 1);
                            }
                        }
                        if (b == 0) { sc = 0; break; }
                        if (b < sc) sc = b;
                    }
                    if (sc != 0 && ali.containsKey(toks.get(a))) sc = sc - 0.2 * p;
                    if (sc > best) best = sc;
                }
                if (best == 0) ok = false; else total += best;
            }
            if (ok) res.add(new double[]{total - it.n * 0.01, k});
        }
        Collections.sort(res, new Comparator<double[]>() {
            public int compare(double[] a, double[] b) {
                if (b[0] != a[0]) return b[0] > a[0] ? 1 : -1;
                return Double.compare(a[1], b[1]);
            }
        });
        if (kwl != null) for (String e : kwl) if (out.size() < lim && !out.contains(e) && (g == null || g.has(base(e)))) out.add(e);
        for (int r = 0; r < res.size() && out.size() < lim; r++) {
            String e = sidx.get((int) res.get(r)[1]).e;
            if (!out.contains(e) && (g == null || g.has(base(e)))) out.add(e);
        }
        return out;
    }

    /** Up to two emoji matching a typed word (used in the suggestion strip). */
    public String[] emojiFor(String w, Glyphs g) {
        String[] c = efCache.get(w);
        if (c != null) return c;
        String[] r = new String[0];
        if (!stop.contains(w) && (ali.containsKey(w) || kwi.containsKey(w) || w.length() >= 3)) {
            List<String> l = search(w, 2, true, g);
            r = new String[l.size()];
            for (int i = 0; i < r.length; i++) r[i] = base(l.get(i));
        }
        efCache.put(w, r);
        return r;
    }
}
