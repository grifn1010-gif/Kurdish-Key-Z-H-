package com.kurdkey.keyboard.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

/** Builds the three suggestion slots (+ emoji) for the strip. */
public final class Suggest {
    public static final class Result {
        public final String[] slot = {"", "", ""};
        public int trSlot = -1;       // slot holding the Latin->Kurdish conversion (-1 = none)
        public String[] emoji = new String[0];
    }

    private static final Pattern LATIN_ONLY = Pattern.compile("^[A-Za-z\\u015F\\u00E7\\u00EA\\u00EE\\u00FB\\u00C7\\u015E\\u00CA\\u00CE\\u00DB']{2,}$");

    private final Dict ku, en;
    private final Learner learner;
    private final EmojiData emoji;
    private final EmojiData.Glyphs glyphs;
    private final Map<String, String[]> nextEn = new HashMap<String, String[]>();

    public Suggest(Dict ku, Dict en, Learner learner, EmojiData emoji, EmojiData.Glyphs glyphs, String nextText) {
        this.ku = ku; this.en = en; this.learner = learner; this.emoji = emoji; this.glyphs = glyphs;
        if (nextText != null) for (String line : nextText.split("\n")) {
            String[] t = line.split("\t");
            if (t.length >= 2) nextEn.put(t[0], t[1].trim().split(" "));
        }
    }

    public boolean isEnglishWord(String w) { return en.contains(w); }

    public Result compute(boolean kurdish, String word, String prev, Cfg cfg) {
        Result r = new Result();
        if (!cfg.suggest) return r;
        String ew = "";
        if (word != null && word.length() > 0) {
            String lw = word.toLowerCase(Locale.ROOT);
            String tr = "";
            if (!kurdish && cfg.translit && LATIN_ONLY.matcher(word).matches()) tr = Translit.conv(word);
            boolean common = en.isCommon(lw);
            List<String> c = new ArrayList<String>();
            learner.prefix(lw, 6, c, learner.bannedSet());
            (kurdish ? ku : en).prefix(lw, 8, c, learner.bannedSet());
            // keep distinct and different from tr
            List<String> d = new ArrayList<String>();
            for (String s : c) if (!d.contains(s) && !s.equals(tr) && !s.equalsIgnoreCase(word)) d.add(s);
            for (int i = 0; i < d.size(); i++) d.set(i, matchCase(word, d.get(i)));
            String a, b;
            if (tr.length() > 0 && !common) {          // Kurdish in Latin letters: conversion first
                a = tr; b = d.size() > 0 ? d.remove(0) : "";
                r.trSlot = 0;
            } else if (tr.length() > 0) {              // a common English word: keep English first, conversion last
                a = d.size() > 0 ? d.remove(0) : ""; b = tr;
                r.trSlot = 2;
            } else {
                a = d.size() > 0 ? d.remove(0) : ""; b = d.size() > 0 ? d.remove(0) : "";
            }
            r.slot[0] = a; r.slot[1] = word; r.slot[2] = b;
            ew = word.length() >= 2 ? lw : "";
        } else {
            List<String> nx = new ArrayList<String>();
            String p = prev == null ? "" : prev;
            for (String s : learner.next(p, 6)) addNext(nx, s, p);
            if (p.length() > 0) {
                String[] n = nextEn.get(p.toLowerCase(Locale.ROOT));
                if (n != null) for (String s : n) addNext(nx, s, p);
            }
            String[] def = kurdish ? new String[]{"سڵاو", "و", "لە", "بۆ", "من"} : new String[]{"I", "the", "you", "and", "to"};
            for (String s : def) addNext(nx, s, p);
            for (int i = 0; i < 3 && i < nx.size(); i++) r.slot[i] = nx.get(i);
            ew = p.toLowerCase(Locale.ROOT);
        }
        if (cfg.emojiSuggest && ew.length() > 0) {
            try { r.emoji = emoji.emojiFor(ew, glyphs); } catch (RuntimeException e) { r.emoji = new String[0]; }
        }
        return r;
    }

    private void addNext(List<String> nx, String s, String p) {
        if (s == null || s.length() == 0 || learner.isBanned(s) || s.equalsIgnoreCase(p) || nx.contains(s) || nx.size() >= 12) return;
        nx.add(s);
    }

    /** Make a lower-case dictionary word follow the capitalisation the user typed. */
    static String matchCase(String typed, String cand) {
        if (typed.length() == 0 || cand.length() == 0) return cand;
        boolean allUp = typed.length() > 1, firstUp = Character.isUpperCase(typed.charAt(0));
        for (int i = 0; i < typed.length(); i++) if (Character.isLetter(typed.charAt(i)) && !Character.isUpperCase(typed.charAt(i))) { allUp = false; break; }
        if (allUp) return cand.toUpperCase(Locale.ROOT);
        if (firstUp) return cand.substring(0, 1).toUpperCase(Locale.ROOT) + cand.substring(1);
        return cand;
    }
}
