package com.kurdkey.keyboard.core;

import java.util.ArrayList;
import java.util.List;

/** Emoji search UI: query field + a row of results, shown above the normal keys. */
final class SearchBar {
    private final Host h;
    private List<String> results = new ArrayList<String>();
    private float scroll, downX, startScroll;
    private int pid = -1, zone;
    private boolean moved;

    SearchBar(Host h) { this.h = h; }

    float row1() { return h.kb.fullStripH() * 0.9f; }
    float row2() { return h.kb.fullStripH(); }
    float height() { return row1() + row2(); }

    void update(String q) {
        scroll = 0;
        results = q.trim().length() == 0 ? new ArrayList<String>() : h.emoji.search(q, 80, false, h.glyphs);
    }

    private float cell() { return 46f * h.dp(); }

    private List<String> chips() {
        List<String> l = new ArrayList<String>();
        if (h.query.length() > 0) return l;
        for (String c : h.emoji.chips) l.add(c);
        return l;
    }

    private float chipW(Gfx g, String s) { return g.textWidth(s, 15f * g.dp(), Gfx.NORMAL) + 22f * g.dp(); }

    private float contentW(Gfx g) {
        if (h.query.length() == 0) {
            float w = 0;
            for (String c : chips()) w += chipW(g, c) + 6f * g.dp();
            return w + 8f * g.dp();
        }
        return results.size() * cell() + 8f * g.dp();
    }

    void draw(Gfx g, float W) {
        Theme t = h.theme;
        float dp = g.dp(), r1 = row1(), r2 = row2();
        g.fillRect(0, 0, W, r1 + r2, t.kbd);
        // field
        float fx = 8 * dp, fy = 5 * dp, fw = W - 16 * dp, fh = r1 - 8 * dp;
        g.fillRound(fx, fy, fx + fw, fy + fh, fh / 2f, t.key);
        g.strokeRound(fx + 0.5f * dp, fy + 0.5f * dp, fx + fw - 0.5f * dp, fy + fh - 0.5f * dp, fh / 2f, 1.5f * dp, t.accent);
        g.icon(Icons.CHEV_LEFT, fx + 22 * dp, fy + fh / 2f, 20 * dp, t.muted);
        String q = h.query.toString();
        float size = 16f * dp;
        float tx0 = fx + 44 * dp, tx1 = fx + fw - 44 * dp;
        if (q.length() == 0) {
            g.text("گەڕان بۆ ئیمۆجی…", (tx0 + tx1) / 2f, fy + fh / 2f, size, t.muted, Gfx.NORMAL, Gfx.CENTER);
        } else {
            String s = q;
            while (s.length() > 1 && g.textWidth(s, size, Gfx.NORMAL) > tx1 - tx0) s = s.substring(1);
            boolean ar = Ui.rtl(s);
            g.text(s, ar ? tx1 : tx0, fy + fh / 2f, size, t.fg, Gfx.NORMAL, ar ? Gfx.RIGHT : Gfx.LEFT);
            g.icon(Icons.CLOSE, fx + fw - 22 * dp, fy + fh / 2f, 18 * dp, t.muted);
        }
        // results / chips
        g.save();
        g.clip(0, r1, W, r1 + r2);
        float cy = r1 + r2 / 2f;
        if (q.length() == 0) {
            float x = 8 * dp - scroll;
            for (String c : chips()) {
                float w = chipW(g, c);
                if (x + w > 0 && x < W) {
                    g.fillRound(x, r1 + 6 * dp, x + w, r1 + r2 - 6 * dp, (r2 - 12 * dp) / 2f, t.keyAlt);
                    g.text(c, x + w / 2f, cy, 15f * dp, t.fg, Gfx.NORMAL, Gfx.CENTER);
                }
                x += w + 6 * dp;
            }
        } else if (results.isEmpty()) {
            g.text("هیچ ئەنجامێک نەدۆزرایەوە", W / 2f, cy, 14f * dp, t.muted, Gfx.NORMAL, Gfx.CENTER);
        } else {
            float c = cell();
            int first = Math.max(0, (int) ((scroll - 8 * dp) / c));
            for (int i = first; i < results.size(); i++) {
                float x = 8 * dp + i * c - scroll;
                if (x > W) break;
                g.text(EmojiData.withTone(results.get(i), h.cfg.tone), x + c / 2f, cy, 27f * dp, t.fg, Gfx.NORMAL, Gfx.CENTER);
            }
        }
        g.restore();
    }

    boolean touch(int action, int id, float x, float y) {
        float dp = h.dp(), r1 = row1();
        float W = h.width();
        if (action == Screen.DOWN) {
            if (pid != -1) return true;
            pid = id; downX = x; startScroll = scroll; moved = false;
            if (y < r1) zone = x < 52 * dp ? 1 : (x > W - 52 * dp ? 2 : 0); else zone = 3;
            return true;
        }
        if (id != pid) return true;
        if (action == Screen.MOVE) {
            if (zone == 3) {
                if (Math.abs(x - downX) > 10 * dp) moved = true;
                if (moved) {
                    float max = Math.max(0f, contentWidth() - W);
                    scroll = Math.max(0, Math.min(max, startScroll + (downX - x)));
                    h.p.invalidate();
                }
            }
            return true;
        }
        pid = -1;
        if (action == Screen.CANCEL) return true;
        if (zone == 1 && x < 52 * dp && y < r1) { h.p.feedback(4); h.closeSearch(true); }
        else if (zone == 2 && x > W - 52 * dp && y < r1) { h.p.feedback(4); h.searchClear(); }
        else if (zone == 3 && !moved) tapRow(x);
        return true;
    }

    private float contentWidth() {
        if (h.query.length() == 0) {
            float w = 8 * h.dp();
            for (String c : chips()) w += h.chipWidth(c, 15f * h.dp()) + 6 * h.dp();
            return w;
        }
        return results.size() * cell() + 8 * h.dp();
    }

    private void tapRow(float x) {
        float dp = h.dp();
        if (h.query.length() == 0) {
            float cx = 8 * dp - scroll;
            for (String c : chips()) {
                float w = h.chipWidth(c, 15f * dp);
                if (x >= cx && x < cx + w) { h.p.feedback(0); h.searchSet(c); return; }
                cx += w + 6 * dp;
            }
            return;
        }
        int i = (int) ((x + scroll - 8 * dp) / cell());
        if (i >= 0 && i < results.size()) { h.p.feedback(0); h.commitEmoji(results.get(i)); }
    }
}
