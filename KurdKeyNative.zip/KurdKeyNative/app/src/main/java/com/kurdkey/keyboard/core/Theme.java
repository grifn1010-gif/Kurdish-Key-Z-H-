package com.kurdkey.keyboard.core;

/** Colour set for the keyboard (ARGB ints). */
public final class Theme {
    public int bg, kbd, key, keyAlt, keyDown, fg, muted, line, accent, accentFg, shadow, hint, pop, popFg, sel;
    public boolean dark;

    private static int c(int rgb) { return 0xFF000000 | rgb; }

    public static Theme of(String mode, boolean systemDark, String accent) {
        boolean dark = "dark".equals(mode) || "black".equals(mode) || ("auto".equals(mode) && systemDark);
        Theme t = new Theme();
        t.dark = dark;
        if ("black".equals(mode)) {
            t.bg = c(0x000000); t.kbd = c(0x0A0A0A); t.key = c(0x1D1D1F); t.keyAlt = c(0x2A2A2D); t.keyDown = c(0x3C3C41);
            t.fg = c(0xF2F2F4); t.muted = c(0x8E8E96); t.line = c(0x222222); t.shadow = c(0x000000); t.pop = c(0x2E2E32);
        } else if (dark) {
            t.bg = c(0x0D0F10); t.kbd = c(0x17191B); t.key = c(0x2D3033); t.keyAlt = c(0x3A3E42); t.keyDown = c(0x4B5056);
            t.fg = c(0xE8ECEE); t.muted = c(0x96A0A6); t.line = c(0x2A2E31); t.shadow = c(0x000000); t.pop = c(0x3D4246);
        } else {
            t.bg = c(0xEEF1F0); t.kbd = c(0xE2E7E5); t.key = c(0xFFFFFF); t.keyAlt = c(0xCDD6D3); t.keyDown = c(0xB6C2BE);
            t.fg = c(0x151D1F); t.muted = c(0x5B6A6E); t.line = c(0xC6CECC); t.shadow = c(0xAAB6B2); t.pop = c(0xFFFFFF);
        }
        t.popFg = t.fg;
        t.hint = t.muted;
        // accent
        int a, af = c(0xFFFFFF);
        String k = accent == null ? "green" : accent;
        if ("blue".equals(k)) a = c(0x2F7DE1);
        else if ("rose".equals(k)) a = c(0xD6336C);
        else if ("violet".equals(k)) a = c(0x7C4DFF);
        else if ("orange".equals(k)) a = c(0xD9730D);
        else if ("teal".equals(k)) a = c(0x0F9D9A);
        else if ("red".equals(k)) a = c(0xE03131);
        else if ("gold".equals(k)) { a = c(0xE0A100); af = c(0x1C1500); }
        else if ("graphite".equals(k)) a = c(0x5C6B73);
        else if (dark) { a = c(0x5FD199); af = c(0x06160D); }
        else a = c(0x17794B);
        t.accent = a; t.accentFg = af;
        t.sel = (a & 0x00FFFFFF) | 0x33000000;
        return t;
    }

    public static int accentSwatch(String k) {
        if ("blue".equals(k)) return c(0x2F7DE1);
        if ("rose".equals(k)) return c(0xD6336C);
        if ("violet".equals(k)) return c(0x7C4DFF);
        if ("orange".equals(k)) return c(0xD9730D);
        if ("teal".equals(k)) return c(0x0F9D9A);
        if ("red".equals(k)) return c(0xE03131);
        if ("gold".equals(k)) return c(0xE0A100);
        if ("graphite".equals(k)) return c(0x5C6B73);
        return c(0x17794B);
    }

    public static int withAlpha(int argb, int alpha) { return (argb & 0x00FFFFFF) | (alpha << 24); }

    public static int mix(int a, int b, float t) {
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return 0xFF000000 | ((int) (ar + (br - ar) * t) << 16) | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
    }
}
