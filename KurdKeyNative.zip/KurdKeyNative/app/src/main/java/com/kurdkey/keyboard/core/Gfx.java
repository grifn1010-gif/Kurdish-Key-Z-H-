package com.kurdkey.keyboard.core;

/** Minimal drawing surface. Implemented by Android Canvas (device) and Java2D (desktop tests/previews). */
public interface Gfx {
    int CENTER = 0, LEFT = -1, RIGHT = 1;
    int NORMAL = 0, BOLD = 1;

    /** Pixels per dp. */
    float dp();

    void save();
    void restore();
    void clip(float l, float t, float r, float b);
    void translate(float dx, float dy);

    void fillRect(float l, float t, float r, float b, int argb);
    void fillRound(float l, float t, float r, float b, float rad, int argb);
    void strokeRound(float l, float t, float r, float b, float rad, float strokeW, int argb);
    void fillCircle(float cx, float cy, float r, int argb);
    void line(float x1, float y1, float x2, float y2, float strokeW, int argb);

    /** Draw text; (x,cy): x is the centre / left / right edge (see align), cy is the visual vertical centre. */
    void text(String s, float x, float cy, float size, int argb, int style, int align);

    float textWidth(String s, float size, int style);

    /** Draw an icon centred at (cx,cy) fitted into a square of the given pixel size. */
    void icon(Icon icon, float cx, float cy, float size, int argb);
}
