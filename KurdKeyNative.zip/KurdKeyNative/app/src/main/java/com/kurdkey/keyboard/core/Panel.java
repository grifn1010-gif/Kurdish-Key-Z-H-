package com.kurdkey.keyboard.core;

import java.util.ArrayList;

/**
 * Base for full-size panels (emoji, clipboard, tools...): fixed header/footer buttons, a scrolling body with
 * drag + fling, tap and long-press on body items, optional repeating buttons.
 */
abstract class Panel implements Screen {
    protected static final class Btn {
        float x, y, w, h;
        int id;
        boolean repeat;
        Btn(int id, float x, float y, float w, float h, boolean repeat) { this.id = id; this.x = x; this.y = y; this.w = w; this.h = h; this.repeat = repeat; }
        boolean hit(float px, float py) { return px >= x && px < x + w && py >= y && py < y + h; }
    }

    protected final Host h;
    protected float W, H;
    protected float scroll, vel;
    protected final ArrayList<Btn> btns = new ArrayList<Btn>();
    protected Btn pressed;

    private int pid = -1;
    private float sx, sy, ly;
    private long lt, lastTick;
    private boolean drag, inBody, longFired;
    private Object lpToken, repToken;
    private int repN;

    Panel(Host h) { this.h = h; }

    protected float dp() { return h.dp(); }

    // ---- subclass API
    protected abstract float headerH();
    protected float footerH() { return 0f; }
    protected abstract float contentH();
    protected abstract void drawChrome(Gfx g);
    protected abstract void drawBody(Gfx g, float viewTop, float viewBottom);   // content coordinates
    protected abstract void buildButtons();
    protected void onBtn(int id) {}
    protected void onTap(float x, float cy) {}
    protected void onLong(float x, float cy) {}
    protected void onShown() {}
    protected boolean wantsLong(float x, float cy) { return false; }
    protected void drawOverlay(Gfx g) {}

    protected final float viewH() { return Math.max(0f, H - headerH() - footerH()); }
    protected final float maxScroll() { return Math.max(0f, contentH() - viewH()); }

    protected final void addBtn(int id, float x, float y, float w, float hh) { btns.add(new Btn(id, x, y, w, hh, false)); }
    protected final void addRepeatBtn(int id, float x, float y, float w, float hh) { btns.add(new Btn(id, x, y, w, hh, true)); }

    // ---- Screen
    public void layout(float w, float hh) {
        W = w; H = hh;
        btns.clear();
        buildButtons();
        scroll = Math.min(scroll, maxScroll());
    }

    public float desiredHeight(float w) { return H; }

    public void draw(Gfx g) {
        g.fillRect(0, 0, W, H, h.theme.kbd);
        float top = headerH();
        g.save();
        g.clip(0, top, W, H - footerH());
        g.translate(0, top - scroll);
        drawBody(g, scroll, scroll + viewH());
        g.restore();
        drawChrome(g);
        drawOverlay(g);
    }

    private Btn hitBtn(float x, float y) {
        for (int i = btns.size() - 1; i >= 0; i--) if (btns.get(i).hit(x, y)) return btns.get(i);
        return null;
    }

    public boolean touch(int action, int id, float x, float y) {
        switch (action) {
            case DOWN: {
                if (pid != -1) return true;
                pid = id; sx = x; sy = y; ly = y; lt = h.p.now(); drag = false; longFired = false; vel = 0; repN = 0;
                pressed = hitBtn(x, y);
                inBody = pressed == null && y >= headerH() && y < H - footerH();
                if (pressed != null) {
                    h.p.feedback(4);
                    if (pressed.repeat) {
                        onBtn(pressed.id);
                        final Btn b = pressed;
                        repToken = h.p.post(new Runnable() { public void run() { repeatFire(b); } }, 380);
                    }
                } else if (inBody) {
                    final float cx = x, cy = y - headerH() + scroll;
                    if (wantsLong(cx, cy)) lpToken = h.p.post(new Runnable() { public void run() {
                        lpToken = null;
                        if (pid != -1 && !drag) { longFired = true; onLong(cx, cy); h.p.invalidate(); }
                    } }, 380);
                }
                h.p.invalidate();
                return true;
            }
            case MOVE: {
                if (id != pid) return true;
                if (inBody) {
                    float dy = y - ly;
                    if (!drag && Math.abs(y - sy) > 10 * dp()) {
                        drag = true;
                        if (lpToken != null) { h.p.cancel(lpToken); lpToken = null; }
                    }
                    if (drag && !longFired) {
                        long now = h.p.now();
                        long dt = Math.max(1, now - lt);
                        scroll = clamp(scroll - dy);
                        vel = 0.6f * vel + 0.4f * (-dy / dt);
                        lt = now;
                        h.p.invalidate();
                    }
                    ly = y;
                } else if (pressed != null && !pressed.hit(x, y) && !pressed.repeat) {
                    pressed = null;
                    h.p.invalidate();
                }
                return true;
            }
            default: {
                if (id != pid) return true;
                if (lpToken != null) { h.p.cancel(lpToken); lpToken = null; }
                if (repToken != null) { h.p.cancel(repToken); repToken = null; }
                boolean cancel = action == CANCEL;
                Btn b = pressed;
                pressed = null;
                pid = -1;
                if (!cancel) {
                    if (b != null && !b.repeat && b.hit(x, y)) onBtn(b.id);
                    else if (inBody && !drag && !longFired) onTap(x, y - headerH() + scroll);
                    else if (inBody && drag && Math.abs(vel) > 0.05f) { lastTick = 0; }
                }
                if (!(inBody && drag)) vel = 0;
                if (longFired) vel = 0;
                h.p.invalidate();
                return true;
            }
        }
    }

    private void repeatFire(final Btn b) {
        repToken = null;
        if (pid == -1 || pressed != b) return;
        repN++;
        onBtn(b.id);
        repToken = h.p.post(new Runnable() { public void run() { repeatFire(b); } }, repN > 8 ? 40 : 55);
    }

    protected final float clamp(float v) { return v < 0 ? 0 : Math.min(v, maxScroll()); }

    public boolean animating() { return pid == -1 && Math.abs(vel) > 0.02f; }

    public void tick(long now) {
        if (lastTick == 0) { lastTick = now; return; }
        float dt = Math.min(34, now - lastTick);
        lastTick = now;
        if (pid != -1 || Math.abs(vel) <= 0.02f) return;
        float ns = scroll + vel * dt;
        float cl = clamp(ns);
        scroll = cl;
        if (cl != ns) vel = 0;
        vel *= (float) Math.exp(-dt / 325.0);
    }

    public void onShow() { vel = 0; lastTick = 0; pid = -1; pressed = null; onShown(); }

    public void onHide() {
        if (lpToken != null) { h.p.cancel(lpToken); lpToken = null; }
        if (repToken != null) { h.p.cancel(repToken); repToken = null; }
        pid = -1; pressed = null; vel = 0;
    }
}
