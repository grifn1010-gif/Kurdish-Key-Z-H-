package com.kurdkey.keyboard.droid;

import android.content.Context;
import android.content.SharedPreferences;

import com.kurdkey.keyboard.core.Prefs;

final class PrefsImpl implements Prefs {
    static final String NAME = "kurdkey";
    private final SharedPreferences sp;

    PrefsImpl(Context c) { sp = c.getSharedPreferences(NAME, Context.MODE_PRIVATE); }

    SharedPreferences raw() { return sp; }

    public String getString(String k, String d) { try { return sp.getString(k, d); } catch (ClassCastException e) { return d; } }
    public int getInt(String k, int d) { try { return sp.getInt(k, d); } catch (ClassCastException e) { return d; } }
    public boolean getBool(String k, boolean d) { try { return sp.getBoolean(k, d); } catch (ClassCastException e) { return d; } }
    public void putString(String k, String v) { sp.edit().putString(k, v).apply(); }
    public void putInt(String k, int v) { sp.edit().putInt(k, v).apply(); }
    public void putBool(String k, boolean v) { sp.edit().putBoolean(k, v).apply(); }
    public void remove(String k) { sp.edit().remove(k).apply(); }
}
