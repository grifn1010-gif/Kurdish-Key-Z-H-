package com.kurdkey.keyboard.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Words and word pairs learned from the user. Plain text storage, never leaves the phone. */
public final class Learner {
    private final Map<String, Integer> uni = new HashMap<String, Integer>();
    private final Map<String, Map<String, Integer>> bi = new HashMap<String, Map<String, Integer>>();
    private final Set<String> banned = new HashSet<String>();
    public boolean dirty;

    private static final int MAX_UNI = 5000, MAX_BI_PREV = 2500;

    public synchronized void learn(String word, String prev) {
        if (word == null || word.length() < 2) return;
        String w = Dict.norm(word);
        if (banned.contains(w)) return;
        Integer c = uni.get(w);
        uni.put(w, c == null ? 1 : c + 1);
        if (prev != null && prev.length() > 0) {
            String p = Dict.norm(prev);
            if (!p.equals(w)) {
                Map<String, Integer> m = bi.get(p);
                if (m == null) { m = new HashMap<String, Integer>(); bi.put(p, m); }
                Integer bc = m.get(w);
                m.put(w, bc == null ? 1 : bc + 1);
            }
        }
        if (uni.size() > MAX_UNI) trimUni();
        if (bi.size() > MAX_BI_PREV) trimBi();
        dirty = true;
    }

    public synchronized void bump(String word) {
        if (word == null || word.length() < 2) return;
        String w = Dict.norm(word);
        if (banned.contains(w)) return;
        Integer c = uni.get(w);
        uni.put(w, c == null ? 1 : c + 1);
        dirty = true;
    }

    private void trimUni() {
        List<Map.Entry<String, Integer>> l = new ArrayList<Map.Entry<String, Integer>>(uni.entrySet());
        Collections.sort(l, new Comparator<Map.Entry<String, Integer>>() {
            public int compare(Map.Entry<String, Integer> a, Map.Entry<String, Integer> b) { return a.getValue() - b.getValue(); }
        });
        for (int i = 0; i < 400 && i < l.size(); i++) uni.remove(l.get(i).getKey());
    }

    private void trimBi() {
        List<String> ks = new ArrayList<String>(bi.keySet());
        for (int i = 0; i < 300 && i < ks.size(); i++) bi.remove(ks.get(i));
    }

    /** Learned words starting with prefix (strictly longer), most used first. Only the same script as the prefix. */
    public synchronized void prefix(String prefix, int limit, List<String> out, Set<String> skip) {
        final String p = Dict.norm(prefix);
        if (p.length() == 0) return;
        boolean arabic = Grapheme.isArabicScript(p.codePointAt(0));
        List<String> hits = new ArrayList<String>();
        for (String k : uni.keySet()) {
            if (k.length() > p.length() && k.startsWith(p) && !banned.contains(k) && (skip == null || !skip.contains(k))
                    && Grapheme.isArabicScript(k.codePointAt(0)) == arabic) hits.add(k);
        }
        Collections.sort(hits, new Comparator<String>() {
            public int compare(String a, String b) { int d = uni.get(b) - uni.get(a); return d != 0 ? d : a.compareTo(b); }
        });
        for (int i = 0; i < hits.size() && i < limit; i++) if (!out.contains(hits.get(i))) out.add(hits.get(i));
    }

    /** Words that often follow `prev` (seen at least twice). */
    public synchronized List<String> next(String prev, int limit) {
        List<String> r = new ArrayList<String>();
        if (prev == null || prev.length() == 0) return r;
        final Map<String, Integer> m = bi.get(Dict.norm(prev));
        if (m == null) return r;
        List<String> ks = new ArrayList<String>();
        for (Map.Entry<String, Integer> e : m.entrySet()) if (e.getValue() > 1 && !banned.contains(e.getKey())) ks.add(e.getKey());
        Collections.sort(ks, new Comparator<String>() {
            public int compare(String a, String b) { int d = m.get(b) - m.get(a); return d != 0 ? d : a.compareTo(b); }
        });
        for (int i = 0; i < ks.size() && i < limit; i++) r.add(ks.get(i));
        return r;
    }

    public synchronized void ban(String word) {
        String w = Dict.norm(word);
        banned.add(w);
        uni.remove(w);
        for (Map<String, Integer> m : bi.values()) m.remove(w);
        bi.remove(w);
        dirty = true;
    }

    public synchronized boolean isBanned(String word) { return banned.contains(Dict.norm(word)); }
    public synchronized Set<String> bannedSet() { return new HashSet<String>(banned); }
    public synchronized void unbanAll() { banned.clear(); dirty = true; }
    public synchronized void clearLearned() { uni.clear(); bi.clear(); dirty = true; }
    public synchronized int wordCount() { return uni.size(); }
    public synchronized int bannedCount() { return banned.size(); }

    public synchronized String serialize() {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Integer> e : uni.entrySet()) sb.append("U\t").append(e.getKey()).append('\t').append(e.getValue()).append('\n');
        for (Map.Entry<String, Map<String, Integer>> e : bi.entrySet())
            for (Map.Entry<String, Integer> f : e.getValue().entrySet())
                sb.append("B\t").append(e.getKey()).append('\t').append(f.getKey()).append('\t').append(f.getValue()).append('\n');
        for (String b : banned) sb.append("X\t").append(b).append('\n');
        return sb.toString();
    }

    /** Replace the contents with a serialized copy (used when the settings app changed the data file). */
    public synchronized void loadFrom(String text) {
        Learner n = parse(text);
        uni.clear(); uni.putAll(n.uni);
        bi.clear(); bi.putAll(n.bi);
        banned.clear(); banned.addAll(n.banned);
        dirty = false;
    }

    public static Learner parse(String text) {
        Learner l = new Learner();
        if (text == null) return l;
        for (String line : text.split("\n")) {
            String[] t = line.split("\t");
            try {
                if (t.length >= 3 && t[0].equals("U")) l.uni.put(t[1], Integer.parseInt(t[2].trim()));
                else if (t.length >= 4 && t[0].equals("B")) {
                    Map<String, Integer> m = l.bi.get(t[1]);
                    if (m == null) { m = new HashMap<String, Integer>(); l.bi.put(t[1], m); }
                    m.put(t[2], Integer.parseInt(t[3].trim()));
                } else if (t.length >= 2 && t[0].equals("X")) l.banned.add(t[1]);
            } catch (NumberFormatException ignore) { }
        }
        return l;
    }
}
