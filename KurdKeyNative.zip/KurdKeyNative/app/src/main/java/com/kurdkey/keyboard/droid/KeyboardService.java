package com.kurdkey.keyboard.droid;

import android.content.ClipData;
import android.content.ClipDescription;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.inputmethodservice.InputMethodService;
import android.os.Build;
import android.os.PersistableBundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.ExtractedText;
import android.view.inputmethod.ExtractedTextRequest;
import android.view.inputmethod.InputConnection;
import android.widget.TextView;

import com.kurdkey.keyboard.core.Editor;
import com.kurdkey.keyboard.core.FieldInfo;
import com.kurdkey.keyboard.core.Host;

/** The system keyboard. All behaviour is in core.Host; this class only connects it to Android. */
public class KeyboardService extends InputMethodService {
    static volatile KeyboardService instance;

    Host host;
    AndroidPlatform plat;
    private GfxView view;
    private PrefsImpl prefs;
    private ClipboardManager cm;
    private int selS = -1, selE = -1;
    private final EditorImpl editor = new EditorImpl();
    private SharedPreferences.OnSharedPreferenceChangeListener prefListener;
    private ClipboardManager.OnPrimaryClipChangedListener clipListener;
    private final Runnable reloadRun = new Runnable() {
        public void run() {
            try {
                if (host != null) { host.reloadPrefs(); syncBg(); }
            } catch (Throwable t) { plat.log("reload", t); }
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        instance = this;
        try {
            float density = getResources().getDisplayMetrics().density;
            prefs = new PrefsImpl(this);
            plat = new AndroidPlatform(this) {
                @Override public void hideKeyboard() { requestHideSelf(0); }
            };
            host = new Host(plat, prefs, density, new GlyphCheck());
            plat.host = host;
            prefListener = new SharedPreferences.OnSharedPreferenceChangeListener() {
                public void onSharedPreferenceChanged(SharedPreferences sp, String key) {
                    if (key == null || key.equals("lastLang") || key.equals("toolbarOpen")) return;
                    plat.handler.removeCallbacks(reloadRun);
                    plat.handler.postDelayed(reloadRun, 40);
                }
            };
            prefs.raw().registerOnSharedPreferenceChangeListener(prefListener);
            cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            clipListener = new ClipboardManager.OnPrimaryClipChangedListener() {
                public void onPrimaryClipChanged() { onClip(); }
            };
            if (cm != null) cm.addPrimaryClipChangedListener(clipListener);
        } catch (Throwable t) {
            Log.e("KurdKey", "create failed", t);
            if (plat != null) plat.log("create", t);
        }
    }

    private void onClip() {
        try {
            if (host == null || cm == null || !host.cfg.clipHistory) return;
            ClipData cd = cm.getPrimaryClip();
            if (cd == null || cd.getItemCount() == 0) return;
            ClipDescription desc = cm.getPrimaryClipDescription();
            if (desc != null && Build.VERSION.SDK_INT >= 33) {
                PersistableBundle ex = desc.getExtras();
                if (ex != null && ex.getBoolean("android.content.extra.IS_SENSITIVE", false)) return;
            }
            CharSequence cs = cd.getItemAt(0).coerceToText(this);
            host.onClipboardChanged(cs == null ? null : cs.toString());
        } catch (Throwable t) {
            plat.log("clip", t);
        }
    }

    @Override public View onCreateInputView() {
        if (host == null) {
            TextView tv = new TextView(this);
            tv.setText("Keyboard failed to start. Open the app for details.");
            tv.setPadding(40, 40, 40, 40);
            return tv;
        }
        view = new GfxView(this, host, host.dp(), plat);
        plat.view = view;
        syncBg();
        return view;
    }

    private void syncBg() {
        try {
            if (view != null && host != null) view.setBackgroundColor(host.theme.kbd);
            if (Build.VERSION.SDK_INT >= 21 && host != null && getWindow() != null) {
                Window w = getWindow().getWindow();
                if (w != null) w.setNavigationBarColor(host.theme.kbd);
            }
        } catch (Throwable t) {
            plat.log("bg", t);
        }
    }

    @Override public boolean onEvaluateFullscreenMode() { return false; }

    @Override public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        try {
            if (host == null) return;
            selS = info.initialSelStart;
            selE = info.initialSelEnd;
            CharSequence al = info.actionLabel;
            FieldInfo fi = FieldInfo.from(info.inputType, info.imeOptions, al == null ? null : al.toString(), info.packageName);
            host.onStartInput(fi, editor, selS, selE, restarting);
            syncBg();
        } catch (Throwable t) {
            plat.log("startInput", t);
        }
    }

    @Override public void onFinishInputView(boolean finishingInput) {
        super.onFinishInputView(finishingInput);
        try { if (host != null) host.onFinishInput(); } catch (Throwable t) { plat.log("finishInput", t); }
    }

    @Override public void onUpdateSelection(int oldSelStart, int oldSelEnd, int newSelStart, int newSelEnd, int candStart, int candEnd) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candStart, candEnd);
        selS = newSelStart;
        selE = newSelEnd;
        try { if (host != null) host.onSelection(newSelStart, newSelEnd); } catch (Throwable t) { plat.log("selection", t); }
    }

    @Override public void onWindowShown() {
        super.onWindowShown();
        try { if (host != null) host.onShow(); } catch (Throwable t) { plat.log("shown", t); }
    }

    @Override public void onWindowHidden() {
        super.onWindowHidden();
        try { if (host != null) host.onHide(); } catch (Throwable t) { plat.log("hidden", t); }
    }

    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        try {
            if (host != null) { host.onThemeChanged(); host.onConfigurationChanged(); syncBg(); }
        } catch (Throwable t) { plat.log("config", t); }
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        try {
            if (keyCode == KeyEvent.KEYCODE_BACK && host != null && event.getRepeatCount() == 0 && host.back()) return true;
        } catch (Throwable t) { plat.log("back", t); }
        return super.onKeyDown(keyCode, event);
    }

    @Override public void onDestroy() {
        try {
            if (host != null) host.flush();
            if (cm != null && clipListener != null) cm.removePrimaryClipChangedListener(clipListener);
            if (prefs != null && prefListener != null) prefs.raw().unregisterOnSharedPreferenceChangeListener(prefListener);
        } catch (Throwable t) {
            Log.e("KurdKey", "destroy", t);
        }
        instance = null;
        super.onDestroy();
    }

    /** InputConnection wrapper used by the core. The connection can change at any time, so it is fetched on every call. */
    private final class EditorImpl implements Editor {
        private InputConnection ic() { return getCurrentInputConnection(); }

        public boolean valid() { return ic() != null; }

        public void commit(String t) { InputConnection c = ic(); if (c != null) c.commitText(t, 1); }

        public void deleteBefore(int n) { InputConnection c = ic(); if (c != null && n > 0) c.deleteSurroundingText(n, 0); }

        public void deleteAfter(int n) { InputConnection c = ic(); if (c != null && n > 0) c.deleteSurroundingText(0, n); }

        public String before(int n) {
            InputConnection c = ic();
            if (c == null) return "";
            CharSequence s = c.getTextBeforeCursor(n, 0);
            return s == null ? "" : s.toString();
        }

        public String after(int n) {
            InputConnection c = ic();
            if (c == null) return "";
            CharSequence s = c.getTextAfterCursor(n, 0);
            return s == null ? "" : s.toString();
        }

        public String selected() {
            InputConnection c = ic();
            if (c == null) return "";
            CharSequence s = c.getSelectedText(0);
            return s == null ? "" : s.toString();
        }

        public void sendKey(int keyCode, int meta) { sendDownUpKeyEvents(keyCode); }

        public void action(int a) { InputConnection c = ic(); if (c != null) c.performEditorAction(a); }

        public int capsMode(int inputType) {
            InputConnection c = ic();
            return c == null ? 0 : c.getCursorCapsMode(inputType);
        }

        public void selectAll() { InputConnection c = ic(); if (c != null) c.performContextMenuAction(android.R.id.selectAll); }
        public void copy() { InputConnection c = ic(); if (c != null) c.performContextMenuAction(android.R.id.copy); }
        public void cut() { InputConnection c = ic(); if (c != null) c.performContextMenuAction(android.R.id.cut); }
        public void paste() { InputConnection c = ic(); if (c != null) c.performContextMenuAction(android.R.id.paste); }

        public void setAll(String text) {
            InputConnection c = ic();
            if (c == null) return;
            c.beginBatchEdit();
            try {
                ExtractedText et = c.getExtractedText(new ExtractedTextRequest(), 0);
                if (et != null && et.text != null) c.setSelection(0, et.text.length());
                else c.performContextMenuAction(android.R.id.selectAll);
                c.commitText(text, 1);
            } finally {
                c.endBatchEdit();
            }
        }

        public int selStart() { return selS; }
        public int selEnd() { return selE; }
        public void setSelection(int s, int e) { InputConnection c = ic(); if (c != null) c.setSelection(s, e); }
    }
}
