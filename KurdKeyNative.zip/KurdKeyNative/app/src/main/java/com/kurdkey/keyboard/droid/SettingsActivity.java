package com.kurdkey.keyboard.droid;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;

import com.kurdkey.keyboard.core.Host;
import com.kurdkey.keyboard.core.SettingsScreen;
import com.kurdkey.keyboard.core.Theme;

import java.util.List;

/** Setup wizard + all settings. The page itself is drawn by core.SettingsScreen; only the test field is a real Android widget. */
public class SettingsActivity extends Activity implements SettingsScreen.Env {
    private Host host;
    private AndroidPlatform plat;
    private SettingsScreen screen;
    private GfxView view;
    private EditText test;
    private LinearLayout root;
    private PrefsImpl prefs;
    private float density;
    private SharedPreferences.OnSharedPreferenceChangeListener prefListener;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        density = getResources().getDisplayMetrics().density;
        prefs = new PrefsImpl(this);
        plat = new AndroidPlatform(this);
        host = new Host(plat, prefs, density, new GlyphCheck(), true);
        plat.host = host;
        screen = new SettingsScreen(host, this);
        view = new GfxView(this, screen, density, plat);
        plat.view = view;

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        if (Build.VERSION.SDK_INT >= 17) root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.addView(view, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        test = new EditText(this);
        test.setHint("لێرە بنووسە بۆ تاقیکردنەوەی کیبۆرد…");
        test.setMinLines(2);
        test.setMaxLines(4);
        test.setGravity(Gravity.TOP | Gravity.START);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        int m = Math.round(10 * density);
        lp.setMargins(m, Math.round(6 * density), m, m);
        root.addView(test, lp);
        setContentView(root);
        applyTheme();
        prefListener = new SharedPreferences.OnSharedPreferenceChangeListener() {
            public void onSharedPreferenceChanged(SharedPreferences sp, String key) { applyTheme(); }
        };
    }

    private void applyTheme() {
        Theme t = host.theme;
        root.setBackgroundColor(t.kbd);
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(t.key);
        gd.setCornerRadius(14 * density);
        gd.setStroke(Math.round(density), t.line);
        test.setBackground(gd);
        test.setTextColor(t.fg);
        test.setHintTextColor(t.muted);
        int p = Math.round(12 * density);
        test.setPadding(p, p, p, p);
        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(t.kbd);
            getWindow().setNavigationBarColor(t.kbd);
        }
        if (Build.VERSION.SDK_INT >= 23) {
            getWindow().getDecorView().setSystemUiVisibility(t.dark ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
    }

    @Override protected void onResume() {
        super.onResume();
        prefs.raw().registerOnSharedPreferenceChangeListener(prefListener);
        screen.refresh();
        view.invalidate();
    }

    @Override protected void onPause() {
        prefs.raw().unregisterOnSharedPreferenceChangeListener(prefListener);
        host.flush();
        super.onPause();
    }

    // ---- SettingsScreen.Env
    private InputMethodManager imm() { return (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE); }

    public boolean imeEnabled() {
        try {
            InputMethodManager m = imm();
            if (m == null) return false;
            List<InputMethodInfo> l = m.getEnabledInputMethodList();
            for (InputMethodInfo i : l) if (getPackageName().equals(i.getPackageName())) return true;
        } catch (RuntimeException e) {
            plat.log("imeEnabled", e);
        }
        return false;
    }

    public boolean imeSelected() {
        try {
            String cur = Settings.Secure.getString(getContentResolver(), Settings.Secure.DEFAULT_INPUT_METHOD);
            return cur != null && cur.startsWith(getPackageName() + "/");
        } catch (RuntimeException e) {
            return false;
        }
    }

    public void openImeSettings() {
        try { startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)); } catch (RuntimeException e) { plat.log("imeSettings", e); }
    }

    public void pickIme() {
        InputMethodManager m = imm();
        if (m != null) m.showInputMethodPicker();
    }

    private Host target() {
        KeyboardService s = KeyboardService.instance;
        return s != null && s.host != null ? s.host : host;
    }

    public void clearLearned() { target().clearLearnedNow(); }

    public void unbanAll() { target().unbanAllNow(); }

    public void clearClips() {
        Host t = target();
        t.clips.clearUnpinned();
        t.clips.flush();
        t.clipsChanged();
    }

    public String errorLog() {
        String s = plat.readFile("errors.log");
        return s == null ? "" : s;
    }

    public void clearErrorLog() { plat.deleteFile("errors.log"); }

    public String version() {
        try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Exception e) { return ""; }
    }
}
