package com.kurdkey.keyboard.core;

import java.util.ArrayList;
import java.util.List;

/** A keyboard page: rows of keys with relative widths, placed into pixel rectangles by place(). */
public final class Layout {
    public final String id;
    public final List<Key[]> rows = new ArrayList<Key[]>();
    public final List<Float> rowH = new ArrayList<Float>();   // relative row heights
    public float units = 10f;
    public boolean numeric;       // number pad: 4 columns

    public Layout(String id) { this.id = id; }

    public void addRow(float relHeight, Key... keys) {
        for (Key k : keys) k.row = rows.size();
        rows.add(keys);
        rowH.add(relHeight);
    }

    public int keyCount() { int n = 0; for (Key[] r : rows) n += r.length; return n; }

    public float totalRel() { float s = 0; for (float f : rowH) s += f; return s; }

    /**
     * Place keys inside the rectangle (left, top, width, height) with the given gaps.
     * Hit rectangles extend to half the gap and to the outer edges so there are no dead zones.
     */
    public void place(float left, float top, float width, float height, float gapX, float gapY,
                      float outerL, float outerT, float outerR, float outerB) {
        int n = rows.size();
        float rel = totalRel();
        float avail = height - gapY * (n - 1);
        float unitH = avail / rel;
        float unitW = (width - gapX * (units - 1)) / units;
        float y = top;
        for (int r = 0; r < n; r++) {
            Key[] row = rows.get(r);
            float h = unitH * rowH.get(r);
            float sum = 0;
            for (Key k : row) sum += k.weight;
            float lead = Math.max(0f, (units - sum) / 2f) * (unitW + gapX);
            float x = left + lead;
            for (int i = 0; i < row.length; i++) {
                Key k = row[i];
                float w = k.weight * (unitW + gapX) - gapX;
                k.x = x; k.y = y; k.w = w; k.h = h;
                k.hx0 = (i == 0) ? outerL : x - gapX / 2f;
                k.hx1 = (i == row.length - 1) ? outerR : x + w + gapX / 2f;
                k.hy0 = (r == 0) ? outerT : y - gapY / 2f;
                k.hy1 = (r == n - 1) ? outerB : y + h + gapY / 2f;
                x += w + gapX;
            }
            y += h + gapY;
        }
    }

    /** Key whose hit rectangle contains the point; nearest key as fallback. */
    public Key hit(float px, float py) {
        Key best = null;
        float bd = Float.MAX_VALUE;
        for (Key[] row : rows) {
            for (Key k : row) {
                if (px >= k.hx0 && px < k.hx1 && py >= k.hy0 && py < k.hy1) return k;
                float cx = k.x + k.w / 2f, cy = k.y + k.h / 2f;
                float d = (cx - px) * (cx - px) + (cy - py) * (cy - py);
                if (d < bd) { bd = d; best = k; }
            }
        }
        return best;
    }
}
