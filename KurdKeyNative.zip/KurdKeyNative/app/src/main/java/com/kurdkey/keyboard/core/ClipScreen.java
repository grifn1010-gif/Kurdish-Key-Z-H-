package com.kurdkey.keyboard.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Clipboard history: tap to paste, pin / edit / delete per item, add, clear. */
final class ClipScreen extends Panel {
    private static final int B_BACK = 1, B_ADD = 2, B_CLEAR = 3;
    private List<ClipStore.Clip> list = new ArrayList<ClipStore.Clip>();
    private boolean confirm;
    private Object confirmToken;
    private final Map<Integer, Object[]> cache = new HashMap<Integer, Object[]>();

    ClipScreen(Host h) { super(h); }

    protected float headerH() { return 46f * dp(); }
    private float cardH() { return 66f * dp(); }
    private float gap() { return 8f * dp(); }
    protected float contentH() { return list.isEmpty() ? 0f : gap() + list.size() * (cardH() + gap()); }

    protected void onShown() { reload(); }

    @Override public void layout(float w, float hh) {
        super.layout(w, hh);
        reload();
    }

    private void reload() {
        list = h.clips.list();
        scroll = Math.min(scroll, maxScroll());
        h.p.invalidate();
    }

    protected void buildButtons() {
        float dp = dp(), hh = headerH();
        addBtn(B_BACK, 0, 0, 92 * dp, hh);
        addBtn(B_CLEAR, W - 52 * dp, 0, 52 * dp, hh);
        addBtn(B_ADD, W - 104 * dp, 0, 52 * dp, hh);
    }

    protected void onBtn(int id) {
        if (id == B_BACK) { h.closePanel(); return; }
        if (id == B_ADD) { h.p.openClipEditor(0); return; }
        if (id == B_CLEAR) {
            if (list.isEmpty()) return;
            if (!confirm) {
                confirm = true;
                h.p.toast("دووبارە دابگرە بۆ سڕینەوەی هەموو (جگە لە سنجکراوەکان)");
                if (confirmToken != null) h.p.cancel(confirmToken);
                confirmToken = h.p.post(new Runnable() { public void run() { confirm = false; confirmToken = null; h.p.invalidate(); } }, 3000);
            } else {
                confirm = false;
                h.clips.clearUnpinned();
                reload();
            }
            h.p.invalidate();
        }
    }

    private boolean isPressed(int id) { return pressed != null && pressed.id == id; }

    protected void drawChrome(Gfx g) {
        Theme t = h.theme;
        float dp = g.dp(), hh = headerH();
        g.fillRect(0, 0, W, hh, t.kbd);
        g.fillRect(0, hh - dp, W, hh, t.line);
        Ui.button(g, 8 * dp, 5 * dp, 80 * dp, hh - 10 * dp, 12 * dp, isPressed(B_BACK) ? t.keyDown : t.keyAlt, null,
                h.st.lang == KbState.KU ? "ئەب" : "ABC", t.fg, 15f * dp, true);
        g.text("کلیپبۆرد", W / 2f, hh / 2f, 17f * dp, t.fg, Gfx.BOLD, Gfx.CENTER);
        Ui.button(g, W - 98 * dp, 5 * dp, 42 * dp, hh - 10 * dp, 12 * dp, isPressed(B_ADD) ? t.keyDown : t.keyAlt, Icons.PLUS, null, t.accent, 22f * dp, false);
        int clearBg = confirm ? 0xFFD64545 : (isPressed(B_CLEAR) ? t.keyDown : t.keyAlt);
        Ui.button(g, W - 50 * dp, 5 * dp, 42 * dp, hh - 10 * dp, 12 * dp, clearBg, Icons.TRASH, null, confirm ? 0xFFFFFFFF : t.fg, 22f * dp, false);
    }

    @SuppressWarnings("unchecked")
    private List<String> lines(Gfx g, ClipStore.Clip c, float maxW, float size) {
        Object[] e = cache.get(c.id);
        if (e != null && e[0] == c.text && ((Float) e[1]) == maxW) return (List<String>) e[2];
        List<String> l = Ui.wrap(g, c.text.replace('\t', ' ').replace('\r', ' '), size, maxW, 2);
        cache.put(c.id, new Object[]{c.text, maxW, l});
        if (cache.size() > 400) cache.clear();
        return l;
    }

    protected void drawBody(Gfx g, float vt, float vb) {
        Theme t = h.theme;
        float dp = g.dp(), ch = cardH(), gp = gap();
        if (list.isEmpty()) {
            g.text("کلیپبۆرد بەتاڵە", W / 2f, vt + viewH() * 0.40f, 17f * dp, t.fg, Gfx.BOLD, Gfx.CENTER);
            g.text("هەر شتێک کۆپی بکەیت لێرە دەمێنێتەوە", W / 2f, vt + viewH() * 0.40f + 26 * dp, 13f * dp, t.muted, Gfx.NORMAL, Gfx.CENTER);
            return;
        }
        int i0 = Math.max(0, (int) ((vt - gp) / (ch + gp)));
        int i1 = Math.min(list.size() - 1, (int) ((vb - gp) / (ch + gp)));
        float textL = 10 * dp + 116 * dp, textR = W - 10 * dp - 12 * dp, size = 15f * dp;
        for (int i = i0; i <= i1; i++) {
            ClipStore.Clip c = list.get(i);
            float y = gp + i * (ch + gp);
            if (h.cfg.keyStyle == 0) g.fillRound(10 * dp, y + 1.5f * dp, W - 10 * dp, y + ch + 1.5f * dp, 14 * dp, t.shadow);
            g.fillRound(10 * dp, y, W - 10 * dp, y + ch, 14 * dp, t.key);
            if (c.pinned) g.fillRound(W - 14 * dp, y + 10 * dp, W - 10 * dp, y + ch - 10 * dp, 2 * dp, t.accent);
            float cy = y + ch / 2f;
            g.icon(c.pinned ? Icons.PIN_ON : Icons.PIN, 10 * dp + 20 * dp, cy, 20 * dp, c.pinned ? t.accent : t.muted);
            g.icon(Icons.EDIT, 10 * dp + 56 * dp, cy, 19 * dp, t.muted);
            g.icon(Icons.TRASH, 10 * dp + 92 * dp, cy, 19 * dp, t.muted);
            g.fillRect(10 * dp + 112 * dp, y + 12 * dp, 10 * dp + 112 * dp + dp, y + ch - 12 * dp, t.line);
            List<String> ls = lines(g, c, textR - textL, size);
            boolean ar = Ui.rtl(c.text);
            float lh = 20f * dp;
            float ty = cy - (ls.size() - 1) * lh / 2f;
            for (int k = 0; k < ls.size(); k++) g.text(ls.get(k), ar ? textR : textL, ty + k * lh, size, t.fg, Gfx.NORMAL, ar ? Gfx.RIGHT : Gfx.LEFT);
            if (c.text.length() > 120) g.text(c.text.length() + " ‏پیت", ar ? textL : textR, y + ch - 8 * dp, 10f * dp, t.muted, Gfx.NORMAL, ar ? Gfx.LEFT : Gfx.RIGHT);
        }
    }

    protected void onTap(float x, float cy) {
        float ch = cardH(), gp = gap(), dp = dp();
        int i = (int) ((cy - gp) / (ch + gp));
        if (i < 0 || i >= list.size()) return;
        if ((cy - gp) - i * (ch + gp) > ch) return;
        ClipStore.Clip c = list.get(i);
        float ax = x - 10 * dp;
        if (ax >= 0 && ax < 114 * dp) {
            int k = (int) (ax / (38 * dp));
            h.p.feedback(4);
            if (k == 0) { h.clips.setPinned(c.id, !c.pinned); reload(); }
            else if (k == 1) h.p.openClipEditor(c.id);
            else { h.clips.remove(c.id); reload(); }
        } else {
            h.p.feedback(0);
            h.pasteText(c.text);
            h.closePanel();
        }
    }

    @Override public void onHide() {
        super.onHide();
        confirm = false;
        if (confirmToken != null) { h.p.cancel(confirmToken); confirmToken = null; }
    }
}
