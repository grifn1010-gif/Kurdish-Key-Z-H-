plugins {
    id("com.android.application")
}

android {
    namespace = "com.kurdkey.keyboard"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.kurdkey.keyboard"
        minSdk = 21
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    signingConfigs {
        create("kk") {
            storeFile = file("kurdkey.keystore")
            storeType = "pkcs12"
            storePassword = "kurdkey123"
            keyAlias = "kurdkey"
            keyPassword = "kurdkey123"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("kk")
        }
        debug {
            signingConfig = signingConfigs.getByName("kk")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}
