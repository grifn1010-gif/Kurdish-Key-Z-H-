# Kurdish Keyboard — Sorani + English (keyboardi kurdi)
Real Android keyboard (WebView-based). Enable it in Settings > Languages & input > On-screen keyboard.
Translate (needs Claude) works only on the web page, not in the APK.
