package com.kurdkey.web;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.inputmethodservice.InputMethodService;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import org.json.JSONObject;

public class KurdKeyService extends InputMethodService {
    private WebView web;
    private boolean ready = false;
    private int heightPx = 0;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private int selStart = 0;
    private int lastBase = 0;

    @Override
    public View onCreateInputView() {
        web = new WebView(this);
        web.setBackgroundColor(Color.TRANSPARENT);
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setVerticalScrollBarEnabled(false);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.addJavascriptInterface(new Bridge(), "AndroidIME");
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView v, String url) { ready = true; pushState(true); }
        });
        web.loadUrl("file:///android_asset/keyboard.html");
        int h = (int) (getResources().getDisplayMetrics().density * 330);
        web.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h));
        return web;
    }

    @Override public boolean onEvaluateFullscreenMode() { return false; }

    @Override public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        pushState(true, info);
    }

    @Override public void onUpdateSelection(int os, int oe, int ns, int ne, int cs, int ce) {
        super.onUpdateSelection(os, oe, ns, ne, cs, ce);
        selStart = Math.min(ns, ne);
        ui.removeCallbacks(sync);
        ui.postDelayed(sync, 60);
    }

    private final Runnable sync = new Runnable() { public void run() { pushState(false); } };

    private void pushState(boolean start) { pushState(start, getCurrentInputEditorInfo()); }

    private void pushState(boolean start, EditorInfo info) {
        if (!ready || web == null) return;
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        CharSequence b = ic.getTextBeforeCursor(3000, 0);
        CharSequence a = ic.getTextAfterCursor(3000, 0);
        CharSequence sl = ic.getSelectedText(0);
        String bs = b == null ? "" : b.toString();
        String as = a == null ? "" : a.toString();
        String ss = sl == null ? "" : sl.toString();
        int base = Math.max(0, selStart - bs.length());
        if (start) {
            boolean pw = false;
            if (info != null) {
                int t = info.inputType & InputType.TYPE_MASK_CLASS;
                int v = info.inputType & InputType.TYPE_MASK_VARIATION;
                pw = (v == InputType.TYPE_TEXT_VARIATION_PASSWORD || v == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                        || v == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD || t == InputType.TYPE_CLASS_NUMBER && (info.inputType & InputType.TYPE_NUMBER_VARIATION_PASSWORD) != 0);
            }
            js("kkStart(" + pw + "," + base + ")");
        }
        js("kkSync(" + JSONObject.quote(bs) + "," + JSONObject.quote(as) + "," + JSONObject.quote(ss) + "," + base + ")");
    }

    private void js(String code) {
        if (web != null) web.evaluateJavascript(code, null);
    }

    public class Bridge {
        @android.webkit.JavascriptInterface public void edit(final int caret, final int del, final String text) {
            ui.post(new Runnable() { public void run() {
                InputConnection ic = getCurrentInputConnection();
                if (ic == null) return;
                ic.beginBatchEdit();
                ic.setSelection(caret, caret);
                if (del > 0) ic.deleteSurroundingText(del, 0);
                if (text != null && text.length() > 0) ic.commitText(text, 1);
                ic.endBatchEdit();
            } });
        }
        @android.webkit.JavascriptInterface public void sel(final int a, final int b) {
            ui.post(new Runnable() { public void run() {
                InputConnection ic = getCurrentInputConnection();
                if (ic != null) ic.setSelection(Math.max(0, a), Math.max(0, b));
            } });
        }
        @android.webkit.JavascriptInterface public void selectAll() {
            ui.post(new Runnable() { public void run() {
                InputConnection ic = getCurrentInputConnection();
                if (ic != null) ic.performContextMenuAction(android.R.id.selectAll);
            } });
        }
        @android.webkit.JavascriptInterface public void enter() {
            ui.post(new Runnable() { public void run() {
                InputConnection ic = getCurrentInputConnection();
                EditorInfo ei = getCurrentInputEditorInfo();
                if (ic == null) return;
                int act = ei == null ? 0 : (ei.imeOptions & EditorInfo.IME_MASK_ACTION);
                boolean multi = ei != null && (ei.inputType & InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0;
                boolean noEnter = ei != null && (ei.imeOptions & EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0;
                if (act != EditorInfo.IME_ACTION_NONE && act != EditorInfo.IME_ACTION_UNSPECIFIED && !(multi && noEnter)) {
                    ic.performEditorAction(act);
                } else {
                    ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER));
                    ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER));
                }
            } });
        }
        @android.webkit.JavascriptInterface public void hide() {
            ui.post(new Runnable() { public void run() { requestHideSelf(0); } });
        }
        @android.webkit.JavascriptInterface public void vibrate(final int ms) {
            try {
                Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                if (v == null) return;
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(Math.max(1, ms), VibrationEffect.DEFAULT_AMPLITUDE));
                else v.vibrate(ms);
            } catch (Throwable t) { }
        }
        @android.webkit.JavascriptInterface public void setClip(final String t) {
            ui.post(new Runnable() { public void run() {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("text", t));
            } });
        }
        @android.webkit.JavascriptInterface public String getClip() {
            try {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount() > 0) {
                    CharSequence c = cm.getPrimaryClip().getItemAt(0).coerceToText(KurdKeyService.this);
                    return c == null ? "" : c.toString();
                }
            } catch (Throwable t) { }
            return "";
        }
        @android.webkit.JavascriptInterface public void resize(final int cssH) {
            ui.post(new Runnable() { public void run() {
                if (web == null) return;
                int px = (int) (cssH * getResources().getDisplayMetrics().density);
                if (px == heightPx || px < 50) return;
                heightPx = px;
                ViewGroup.LayoutParams lp = web.getLayoutParams();
                if (lp == null) return;
                lp.height = px;
                web.setLayoutParams(lp);
            } });
        }
    }
}
