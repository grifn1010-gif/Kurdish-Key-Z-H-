package com.kurdkey.web;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class SettingsActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        int p = (int) (getResources().getDisplayMetrics().density * 20);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(p, p, p, p);
        root.setBackgroundColor(Color.parseColor("#F3F6F4"));
        TextView t = new TextView(this);
        t.setText("Kurdish Keyboard  کێیبۆردی کوردی");
        t.setTextSize(22); t.setTypeface(Typeface.DEFAULT_BOLD); t.setTextColor(Color.parseColor("#0F2A1C"));
        root.addView(t);
        TextView d = new TextView(this);
        d.setText("\n1) Enable the keyboard   (چاکی بکە)\n2) Choose it as your current keyboard   (هەڵیبژێرە)\n3) Test below\n");
        d.setTextSize(16); d.setTextColor(Color.parseColor("#2B3A32"));
        root.addView(d);
        Button b1 = new Button(this); b1.setText("1. Enable keyboard");
        b1.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
            startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS));
        } });
        Button b2 = new Button(this); b2.setText("2. Choose keyboard");
        b2.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
            ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).showInputMethodPicker();
        } });
        EditText test = new EditText(this);
        test.setHint("Test here / لێرە تەست بکە");
        test.setMinLines(3); test.setGravity(Gravity.TOP);
        root.addView(b1); root.addView(b2); root.addView(test);
        ScrollView sv = new ScrollView(this); sv.addView(root);
        setContentView(sv);
    }
}
